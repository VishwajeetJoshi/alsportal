﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using System.IO;
using MyDataAccess;

/// <summary>
/// Summary description for CommonClass
/// </summary>
/// 
namespace CommonFunction
{
    public class CommonClass
    {
        MailSender oMailSender = new MailSender();
        public CommonClass()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public static string Encrypt(string strText)
        {
            string strEncryptText = "**Sandy**";
            byte[] byKey = new byte[20];
            byte[] dv = { 0x12, 0x34, 0x56, 0x78, 0x90, 0xAB, 0xCD, 0xEF };
            try
            {
                byKey = System.Text.Encoding.UTF8.GetBytes(strEncryptText.Substring(0, 8));
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                byte[] inputArray = System.Text.Encoding.UTF8.GetBytes(strText);
                MemoryStream ms = new MemoryStream();
                CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(byKey, dv), CryptoStreamMode.Write);
                cs.Write(inputArray, 0, inputArray.Length);
                cs.FlushFinalBlock();
                return Convert.ToBase64String(ms.ToArray());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string Decrypt(string strText)
        {
            string strEncryptText = "**Sandy**";
            byte[] byKey = new byte[20];
            byte[] dv = { 0x12, 0x34, 0x56, 0x78, 0x90, 0xAB, 0xCD, 0xEF };
            try
            {
                byKey = System.Text.Encoding.UTF8.GetBytes(strEncryptText.Substring(0, 8));
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                byte[] inputArray = Convert.FromBase64String(strText);
                MemoryStream ms = new MemoryStream();
                CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(byKey, dv), CryptoStreamMode.Write);
                cs.Write(inputArray, 0, inputArray.Length);
                cs.FlushFinalBlock();
                System.Text.Encoding encoding = System.Text.Encoding.UTF8;
                return encoding.GetString(ms.ToArray());
            }
            catch (Exception e)
            {
                return "";
            }
        }

        public DataTable DecodeDataTable(DataTable odt, string fieldName)
        {
            if (odt.Rows.Count > 0)
            {
                bool isColumnExist = false;
                foreach (DataColumn column in odt.Columns)
                {
                    if (column.ColumnName == fieldName)
                    {
                        isColumnExist = true;
                    }
                }
                if (isColumnExist == true)
                {
                    for (int i = 0; i < odt.Rows.Count; i++)
                    {
                        odt.Rows[i][fieldName] = HttpContext.Current.Server.HtmlDecode(odt.Rows[i][fieldName].ToString());
                    }
                }
            }
            odt.AcceptChanges();
            return odt;
        }

        public static void AddErrorTrail(string pagename, string functionname, string error)
        {
            SqlConnection con = SqlHelper.GetConnection();
            con.Open();
            try
            {
                SqlParameter[] sqlParams = new SqlParameter[] {
                                               new SqlParameter("@PageName", pagename) ,
                                               new SqlParameter("@FunctionName", functionname),
                                               new SqlParameter("@ErrorText", error),
                                               new SqlParameter("@UserName", HttpContext.Current.Session["UserName"]),};
                SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddErrorDetail", sqlParams);
            }
            catch (Exception ex)
            {
            }
        }

        public bool GetDetailsValidity(string query)
        {
            bool mode = false;
            SqlConnection con = SqlHelper.GetConnection();
            con.Open();
            try
            {
                mode = (bool)SqlHelper.ExecuteScalar(con, CommandType.Text, query);
                return mode;
            }
            catch (Exception ex)
            {
                CommonClass.AddErrorTrail("CommonClass", "GetDetailsValidity", ex.Message);
                return mode;
            }
            finally { con.Close(); }
        }

        public string checkdate(DateTime dt)
        {
            if (dt != Convert.ToDateTime("01/01/1900") && dt != Convert.ToDateTime("01/01/0001"))
            { return dt.ToString("MM/dd/yyyy"); }
            else
            { return ""; }
        }

        public string CheckBoxValue(CheckBox cb)
        {
            if (cb.Checked == true)
            {
                return "1";
            }
            else
            {
                return null;
            }
        }

        public string DDLValue(string value)
        {
            if (value.ToLower() == "true")
                return "1";
            else if (value.ToLower() == "false")
                return "2";            
            else
                return "0";
        }

        public string CheckDDLValue(string value)
        {
            if (value.ToLower() == "true")
                return "1";
            else if (value.ToLower() == "false")
                return "2";
            else if (value.ToLower() == "1")
                return "1";
            else if (value.ToLower() == "0")
                return "2";
            else
                return "0";
        }

        public string DDLValueYesNo(DropDownList value)
        {
            if (value.SelectedItem.ToString().ToLower() == "yes")
                return "1";
            else if (value.SelectedItem.ToString().ToLower() == "no")
                return "0";
            else
                return null;
        }

        public string InsertDDLValue(DropDownList ddl)
        {
            if (ddl.SelectedIndex != 0)
            {
                if (ddl.SelectedItem.ToString().ToLower() == "yes")
                    return "1";
                else
                    return "0";
            }
            else
            {
                return null;
            }
        }

        public bool IfNullThenZero(string value)
        {
            if (value == null)
            {
                return false;
            }
            else if (value == "")
            {
                return false;
            }
            else if (value.ToLower() == "false")
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public string IfNullThenBlank(string value)
        {
            if (value == null)
            {
                return "";
            }
            else if (value == "")
            {
                return "";
            }
            else
            {
                return HttpContext.Current.Server.HtmlDecode(value);
            }
        }

        public Boolean AuthenticateUser()
        {
            if (System.Web.HttpContext.Current.Session["UserName"] != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public DataTable AllCountry()
        {
            DataTable dtcountry = new DataTable();
            dtcountry.Columns.Add("CountryName");

            dtcountry.Rows.Add("Alabama");
            dtcountry.Rows.Add("Afghanistan");
            dtcountry.Rows.Add("Albania");
            dtcountry.Rows.Add("Algeria");
            dtcountry.Rows.Add("American Samoa");
            dtcountry.Rows.Add("Angola");
            dtcountry.Rows.Add("Anguilla");
            dtcountry.Rows.Add("Antartica");
            dtcountry.Rows.Add("Antigua and Barbuda");
            dtcountry.Rows.Add("Argentina");
            dtcountry.Rows.Add("Armenia");
            dtcountry.Rows.Add("Aruba");
            dtcountry.Rows.Add("Ashmore and Cartier Island");
            dtcountry.Rows.Add("Australia");
            dtcountry.Rows.Add("Austria");
            dtcountry.Rows.Add("Azerbaijan");
            dtcountry.Rows.Add("Bahamas");
            dtcountry.Rows.Add("Bahrain");
            dtcountry.Rows.Add("Bangladesh");
            dtcountry.Rows.Add("Barbados");
            dtcountry.Rows.Add("Belarus");
            dtcountry.Rows.Add("Belgium");
            dtcountry.Rows.Add("Belize");
            dtcountry.Rows.Add("Benin");
            dtcountry.Rows.Add("Bermuda");
            dtcountry.Rows.Add("Bhutan");
            dtcountry.Rows.Add("Bolivia");
            dtcountry.Rows.Add("Bosnia and Herzegovina");
            dtcountry.Rows.Add("Botswana");
            dtcountry.Rows.Add("Brazil");
            dtcountry.Rows.Add("British Virgin Islands");
            dtcountry.Rows.Add("Brunei");
            dtcountry.Rows.Add("Bulgaria");
            dtcountry.Rows.Add("Burkina Faso");
            dtcountry.Rows.Add("Burma");
            dtcountry.Rows.Add("Burundi");
            dtcountry.Rows.Add("Cambodia");
            dtcountry.Rows.Add("Cameroon");
            dtcountry.Rows.Add("Canada");
            dtcountry.Rows.Add("Cape Verde");
            dtcountry.Rows.Add("Cayman Islands");
            dtcountry.Rows.Add("Central African Republic");
            dtcountry.Rows.Add("Chad");
            dtcountry.Rows.Add("Chile");
            dtcountry.Rows.Add("China");
            dtcountry.Rows.Add("Christmas Island");
            dtcountry.Rows.Add("Clipperton Island");
            dtcountry.Rows.Add("Cocos (Keeling) Islands");
            dtcountry.Rows.Add("Colombia");
            dtcountry.Rows.Add("Comoros");
            dtcountry.Rows.Add("Congo, Democratic Republic of the");
            dtcountry.Rows.Add("Congo, Republic of the");
            dtcountry.Rows.Add("Cook Islands");
            dtcountry.Rows.Add("Costa Rica");
            dtcountry.Rows.Add("Cote d'Ivoire");
            dtcountry.Rows.Add("Croatia");
            dtcountry.Rows.Add("Cuba");
            dtcountry.Rows.Add("Cyprus");
            dtcountry.Rows.Add("Czeck Republic");
            dtcountry.Rows.Add("Denmark");
            dtcountry.Rows.Add("Djibouti");
            dtcountry.Rows.Add("Dominica");
            dtcountry.Rows.Add("Dominican Republic");
            dtcountry.Rows.Add("Ecuador");
            dtcountry.Rows.Add("Egypt");
            dtcountry.Rows.Add("El Salvador");
            dtcountry.Rows.Add("Equatorial Guinea");
            dtcountry.Rows.Add("Eritrea");
            dtcountry.Rows.Add("Estonia");
            dtcountry.Rows.Add("Ethiopia");
            dtcountry.Rows.Add("Europa Island");
            dtcountry.Rows.Add("Falkland Islands (Islas Malvinas)");
            dtcountry.Rows.Add("Faroe Islands");
            dtcountry.Rows.Add("Fiji");
            dtcountry.Rows.Add("Finland");
            dtcountry.Rows.Add("France");
            dtcountry.Rows.Add("French Guiana");
            dtcountry.Rows.Add("French Polynesia");
            dtcountry.Rows.Add("French Southern and Antarctic Lands");
            dtcountry.Rows.Add("Gabon");
            dtcountry.Rows.Add("Gambia, The");
            dtcountry.Rows.Add("Gaza Strip");
            dtcountry.Rows.Add("Georgia");
            dtcountry.Rows.Add("Germany");
            dtcountry.Rows.Add("Ghana");
            dtcountry.Rows.Add("Gibraltar");
            dtcountry.Rows.Add("Glorioso Islands");
            dtcountry.Rows.Add("Greece");
            dtcountry.Rows.Add("Greenland");
            dtcountry.Rows.Add("Grenada");
            dtcountry.Rows.Add("Guadeloupe");
            dtcountry.Rows.Add("Guam");
            dtcountry.Rows.Add("Guatemala");
            dtcountry.Rows.Add("Guernsey");
            dtcountry.Rows.Add("Guinea");
            dtcountry.Rows.Add("Guinea-Bissau");
            dtcountry.Rows.Add("Guyana");
            dtcountry.Rows.Add("Haiti");
            dtcountry.Rows.Add("Heard Island and McDonald Islands");
            dtcountry.Rows.Add("Holy See (Vatican City)");
            dtcountry.Rows.Add("Honduras");
            dtcountry.Rows.Add("Hong Kong");
            dtcountry.Rows.Add("Howland Island");
            dtcountry.Rows.Add("Hungary");
            dtcountry.Rows.Add("Iceland");
            dtcountry.Rows.Add("India");
            dtcountry.Rows.Add("Indonesia");
            dtcountry.Rows.Add("Iran");
            dtcountry.Rows.Add("Iraq");
            dtcountry.Rows.Add("Ireland");
            dtcountry.Rows.Add("Ireland, Northern");
            dtcountry.Rows.Add("Israel");
            dtcountry.Rows.Add("Italy");
            dtcountry.Rows.Add("Jamaica");
            dtcountry.Rows.Add("Jan Mayen");
            dtcountry.Rows.Add("Japan");
            dtcountry.Rows.Add("Jarvis Island");
            dtcountry.Rows.Add("Jersey");
            dtcountry.Rows.Add("Johnston Atoll");
            dtcountry.Rows.Add("Jordan");
            dtcountry.Rows.Add("Juan de Nova Island");
            dtcountry.Rows.Add("Kazakhstan");
            dtcountry.Rows.Add("Kenya");
            dtcountry.Rows.Add("Kiribati");
            dtcountry.Rows.Add("Korea, North");
            dtcountry.Rows.Add("Korea, South");
            dtcountry.Rows.Add("Kuwait");
            dtcountry.Rows.Add("Kyrgyzstan");
            dtcountry.Rows.Add("Laos");
            dtcountry.Rows.Add("Latvia");
            dtcountry.Rows.Add("Lebanon");
            dtcountry.Rows.Add("Lesotho");
            dtcountry.Rows.Add("Liberia");
            dtcountry.Rows.Add("Libya");
            dtcountry.Rows.Add("Liechtenstein");
            dtcountry.Rows.Add("Lithuania");
            dtcountry.Rows.Add("Luxembourg");
            dtcountry.Rows.Add("Macau");
            dtcountry.Rows.Add("Macedonia, Former Yugoslav Republic of");
            dtcountry.Rows.Add("Madagascar");
            dtcountry.Rows.Add("Malawi");
            dtcountry.Rows.Add("Malaysia");
            dtcountry.Rows.Add("Maldives");
            dtcountry.Rows.Add("Mali");
            dtcountry.Rows.Add("Malta");
            dtcountry.Rows.Add("Man, Isle of");
            dtcountry.Rows.Add("Marshall Islands");
            dtcountry.Rows.Add("Martinique");
            dtcountry.Rows.Add("Mauritania");
            dtcountry.Rows.Add("Mauritius");
            dtcountry.Rows.Add("Mayotte");
            dtcountry.Rows.Add("Mexico");
            dtcountry.Rows.Add("Micronesia, Federated States of");
            dtcountry.Rows.Add("Midway Islands");
            dtcountry.Rows.Add("Moldova");
            dtcountry.Rows.Add("Monaco");
            dtcountry.Rows.Add("Mongolia");
            dtcountry.Rows.Add("Montserrat");
            dtcountry.Rows.Add("Morocco");
            dtcountry.Rows.Add("Mozambique");
            dtcountry.Rows.Add("Namibia");
            dtcountry.Rows.Add("Nauru");
            dtcountry.Rows.Add("Nepal");
            dtcountry.Rows.Add("Netherlands");
            dtcountry.Rows.Add("Netherlands Antilles");
            dtcountry.Rows.Add("New Caledonia");
            dtcountry.Rows.Add("New Zealand");
            dtcountry.Rows.Add("Nicaragua");
            dtcountry.Rows.Add("Niger");
            dtcountry.Rows.Add("Nigeria");
            dtcountry.Rows.Add("Niue");
            dtcountry.Rows.Add("Norfolk Island");
            dtcountry.Rows.Add("Northern Mariana Islands");
            dtcountry.Rows.Add("Norway");
            dtcountry.Rows.Add("Oman");
            dtcountry.Rows.Add("Pakistan");
            dtcountry.Rows.Add("Palau");
            dtcountry.Rows.Add("Panama");
            dtcountry.Rows.Add("Papua New Guinea");
            dtcountry.Rows.Add("Paraguay");
            dtcountry.Rows.Add("Peru");
            dtcountry.Rows.Add("Philippines");
            dtcountry.Rows.Add("Pitcaim Islands");
            dtcountry.Rows.Add("Poland");
            dtcountry.Rows.Add("Portugal");
            dtcountry.Rows.Add("Puerto Rico");
            dtcountry.Rows.Add("Qatar");
            dtcountry.Rows.Add("Reunion");
            dtcountry.Rows.Add("Romainia");
            dtcountry.Rows.Add("Russia");
            dtcountry.Rows.Add("Rwanda");
            dtcountry.Rows.Add("Saint Helena");
            dtcountry.Rows.Add("Saint Kitts and Nevis");
            dtcountry.Rows.Add("Saint Lucia");
            dtcountry.Rows.Add("Saint Pierre and Miquelon");
            dtcountry.Rows.Add("Saint Vincent and the Grenadines");
            dtcountry.Rows.Add("Samoa");
            dtcountry.Rows.Add("San Marino");
            dtcountry.Rows.Add("Sao Tome and Principe");
            dtcountry.Rows.Add("Saudi Arabia");
            dtcountry.Rows.Add("Scotland");
            dtcountry.Rows.Add("Senegal");
            dtcountry.Rows.Add("Seychelles");
            dtcountry.Rows.Add("Sierra Leone");
            dtcountry.Rows.Add("Singapore");
            dtcountry.Rows.Add("Slovakia");
            dtcountry.Rows.Add("Slovenia");
            dtcountry.Rows.Add("Solomon Islands");
            dtcountry.Rows.Add("Somalia");
            dtcountry.Rows.Add("South Africa");
            dtcountry.Rows.Add("South Georgia and South Sandwich Islands");
            dtcountry.Rows.Add("Spain");
            dtcountry.Rows.Add("Spratly Islands");
            dtcountry.Rows.Add("Sri Lanka");
            dtcountry.Rows.Add("Sudan");
            dtcountry.Rows.Add("Suriname");
            dtcountry.Rows.Add("Svalbard");
            dtcountry.Rows.Add("Swaziland");
            dtcountry.Rows.Add("Sweden");
            dtcountry.Rows.Add("Switzerland");
            dtcountry.Rows.Add("Syria");
            dtcountry.Rows.Add("Taiwan");
            dtcountry.Rows.Add("Tajikistan");
            dtcountry.Rows.Add("Tanzania");
            dtcountry.Rows.Add("Thailand");
            dtcountry.Rows.Add("Tobago");
            dtcountry.Rows.Add("Toga");
            dtcountry.Rows.Add("Tokelau");
            dtcountry.Rows.Add("Tonga");
            dtcountry.Rows.Add("Trinidad");
            dtcountry.Rows.Add("Tunisia");
            dtcountry.Rows.Add("Turkey");
            dtcountry.Rows.Add("Turkmenistan");
            dtcountry.Rows.Add("Tuvalu");
            dtcountry.Rows.Add("Uganda");
            dtcountry.Rows.Add("Ukraine");
            dtcountry.Rows.Add("United Arab Emirates");
            dtcountry.Rows.Add("United Kingdom");
            dtcountry.Rows.Add("Uruguay");
            dtcountry.Rows.Add("USA");
            dtcountry.Rows.Add("Uzbekistan");
            dtcountry.Rows.Add("Vanuatu");
            dtcountry.Rows.Add("Venezuela");
            dtcountry.Rows.Add("Vietnam");
            dtcountry.Rows.Add("Virgin Islands");
            dtcountry.Rows.Add("Wales");
            dtcountry.Rows.Add("Wallis and Futuna");
            dtcountry.Rows.Add("West Bank");
            dtcountry.Rows.Add("Western Sahara");
            dtcountry.Rows.Add("Yemen");
            dtcountry.Rows.Add("Yugoslavia");
            dtcountry.Rows.Add("Zambia");
            dtcountry.Rows.Add("Zimbabwe");

            return dtcountry;
        }

        public DataTable USState()
        {
            DataTable dtstate = new DataTable();
            dtstate.Columns.Add("StateID");
            dtstate.Columns.Add("StateName");

            dtstate.Rows.Add("AL", "Alabama");
            dtstate.Rows.Add("AK", "Alaska");
            dtstate.Rows.Add("AZ", "Arizona");
            dtstate.Rows.Add("AR", "Arkansas");
            dtstate.Rows.Add("CA", "California");
            dtstate.Rows.Add("CO", "Colorado");
            dtstate.Rows.Add("CT", "Connecticut");
            dtstate.Rows.Add("DE", "Delaware");
            dtstate.Rows.Add("DC", "District of Columbia");
            dtstate.Rows.Add("FL", "Florida");

            dtstate.Rows.Add("GA", "Georgia");
            dtstate.Rows.Add("HI", "Hawaii");
            dtstate.Rows.Add("ID", "Idaho");
            dtstate.Rows.Add("IL", "Illinois");
            dtstate.Rows.Add("IN", "Indiana");
            dtstate.Rows.Add("IA", "Iowa");
            dtstate.Rows.Add("KS", "Kansas");
            dtstate.Rows.Add("KY", "Kentucky");
            dtstate.Rows.Add("LA", "Louisiana");
            dtstate.Rows.Add("ME", "Maine");

            dtstate.Rows.Add("MD", "Maryland");
            dtstate.Rows.Add("MA", "Massachusetts");
            dtstate.Rows.Add("MI", "Michigan");
            dtstate.Rows.Add("MN", "Minnesota");
            dtstate.Rows.Add("MS", "Mississippi");
            dtstate.Rows.Add("MO", "Missouri");
            dtstate.Rows.Add("MT", "Montana");
            dtstate.Rows.Add("NE", "Nebraska");
            dtstate.Rows.Add("NV", "Nevada");
            dtstate.Rows.Add("NH", "New Hampshire");

            dtstate.Rows.Add("NJ", "New Jersey");
            dtstate.Rows.Add("NM", "New Mexico");
            dtstate.Rows.Add("NY", "New York");
            dtstate.Rows.Add("NC", "North Carolina");
            dtstate.Rows.Add("ND", "North Dakota");
            dtstate.Rows.Add("OH", "Ohio");
            dtstate.Rows.Add("OK", "Oklahoma");
            dtstate.Rows.Add("OR", "Oregon");
            dtstate.Rows.Add("PA", "Pennsylvania");
            dtstate.Rows.Add("RI", "Rhode Island");

            dtstate.Rows.Add("SC", "South Carolina");
            dtstate.Rows.Add("SD", "South Dakota");
            dtstate.Rows.Add("TN", "Tennessee");
            dtstate.Rows.Add("TX", "Texas");
            dtstate.Rows.Add("UT", "Utah");
            dtstate.Rows.Add("VT", "Vermont");
            dtstate.Rows.Add("VA", "Virginia");
            dtstate.Rows.Add("WA", "Washington");
            dtstate.Rows.Add("WV", "West Virginia");
            dtstate.Rows.Add("WI", "Wisconsin");

            dtstate.Rows.Add("WY", "Wyoming");

            return dtstate;
        }

        public void SendMailToHrIfAllSectionComplete(int employeeID, string EmployeeName)
        {
            DataTable odt = new DataTable();
            DataTable odthruser = new DataTable();
            SqlConnection con = SqlHelper.GetConnection();
            con.Open();
            try
            {
                SqlParameter sqlparam = new SqlParameter("@EmployeeID", employeeID);
                odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetFixModeValueAllSection", sqlparam).Tables[0];
                if (odt.Rows.Count > 0)
                {
                    if (odt.Rows[0]["status"].ToString().ToLower() == "true" && odt.Rows[0]["FixMode"].ToString().ToLower() != "true")
                    {
                        string query = string.Empty;
                        query = "Select * from Users where Role = 'hr'";
                        odthruser = SqlHelper.ExecuteDataset(con, CommandType.Text, query).Tables[0];
                        if (odthruser.Rows.Count > 0)
                        {
                            for (int i = 0; i < odthruser.Rows.Count; i++)
                            {
                                oMailSender.SendFinalMailToHR(odthruser.Rows[i]["UserName"].ToString(), odthruser.Rows[i]["Role"].ToString(), odthruser.Rows[i]["FirstName"].ToString() + " " + odthruser.Rows[i]["LastName"].ToString(), EmployeeName);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                CommonClass.AddErrorTrail("CommonClass", "SendMailToHrIfAllSectionComplete", ex.Message);
            }
            finally
            { con.Close(); }
        }
    }
}