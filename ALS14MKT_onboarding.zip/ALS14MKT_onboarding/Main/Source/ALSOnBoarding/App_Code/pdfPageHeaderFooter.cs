﻿using System;
using System.Web;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Collections.Generic;

namespace myApp.ns.pages
{
    public class pdfPageHeaderFooter : PdfPageEventHelper
    {
        private string _ReportHeader;

        public string ReportHeader
        {
            get { return _ReportHeader; }
            set { _ReportHeader = value; }
        }

        private string _EmployeeName;

        public string EmployeeName
        {
            get { return _EmployeeName; }
            set { _EmployeeName = value; }
        }

        private string _EmployementType;

        public string EmployementType
        {
            get { return _EmployementType; }
            set { _EmployementType = value; }
        }

        private string _Address;

        public string Address
        {
            get { return _Address; }
            set { _Address = value; }
        }

        private string _City;

        public string City
        {
            get { return _City; }
            set { _City = value; }
        }

        private string _State;

        public string State
        {
            get { return _State; }
            set { _State = value; }
        }

        private string _Home;

        public string Home
        {
            get { return _Home; }
            set { _Home = value; }
        }

        private string _Cell;

        public string Cell
        {
            get { return _Cell; }
            set { _Cell = value; }
        }

        private string _BusinessCard;

        public string BusinessCard
        {
            get { return _BusinessCard; }
            set { _BusinessCard = value; }
        }

        private string _EmailName;

        public string EmailName
        {
            get { return _EmailName; }
            set { _EmailName = value; }
        }

        private string _PersonalEmail;

        public string PersonalEmail
        {
            get { return _PersonalEmail; }
            set { _PersonalEmail = value; }
        }


        private int _pageCount;

        public int PageCount
        {
            get { return _pageCount; }
            set { _pageCount = value; }
        }
        //I create a font object to use within my footer
        protected Font footer
        {
            get
            {
                // create a basecolor to use for the footer font, if needed.
                //BaseColor grey = new BaseColor(128, 128, 128);
                Font font = FontFactory.GetFont("Arial", 9, Font.NORMAL, new Color(128, 128, 128));
                return font;
            }
        }

        BaseFont f_cb = BaseFont.CreateFont("c:\\windows\\fonts\\calibrib.ttf", BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
        BaseFont f_cb1 = BaseFont.CreateFont("c:\\windows\\fonts\\calibrib.ttf", BaseFont.CP1257, BaseFont.NOT_EMBEDDED);
        //BaseFont f_cn = BaseFont.CreateFont("c:\\windows\\fonts\\arial.ttf", BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
        BaseFont f_cn = BaseFont.CreateFont("c:\\windows\\fonts\\calibri.ttf", BaseFont.CP1252, BaseFont.NOT_EMBEDDED);

        private void writeText(PdfContentByte cb, string Text, int X, int Y, BaseFont font, int Size)
        {
            cb.SetFontAndSize(font, Size);
            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, Text, X, Y, 0);
        }

        //override the OnStartPage event handler to add our header
        public override void OnStartPage(PdfWriter writer, Document doc)
        {
            //PdfPTable headerTbl = new PdfPTable(1);
            PdfContentByte cb = writer.DirectContent;

            iTextSharp.text.Image png = iTextSharp.text.Image.GetInstance(HttpContext.Current.Server.MapPath("images/alsbridge logo.png"));
            png.ScalePercent(55f);
            png.SetAbsolutePosition(15, 790);

            cb.AddImage(png);
            // First we must activate writing
            cb.BeginText();
            // First we write out the header information
            // Start with the invoice type header
            // HEader details; invoice number, invoice date, due date and customer Id
            cb.SetFontAndSize(f_cb1, 14);
            cb.ShowTextAligned(PdfContentByte.ALIGN_RIGHT, ReportHeader, 580, 800, 0);
            cb.SetFontAndSize(f_cb1, 12);
            cb.ShowTextAligned(PdfContentByte.ALIGN_RIGHT, EmployementType, 580, 780, 0);

            cb.SetFontAndSize(f_cn, 10);
            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, EmployeeName, 15, 770, 0);
            cb.SetFontAndSize(f_cn, 10);
            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Home:  " + Home, 350, 770, 0);

            cb.SetFontAndSize(f_cn, 8);
            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, Address, 15, 760, 0);
            cb.SetFontAndSize(f_cn, 10);
            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Cell:  " + Cell, 350, 760, 0);

            cb.SetFontAndSize(f_cn, 8);
            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, City, 15, 750, 0);
            cb.SetFontAndSize(f_cn, 10);
            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Business Card Name:  " + BusinessCard, 350, 750, 0);

            cb.SetFontAndSize(f_cn, 8);
            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, State, 15, 740, 0);
            cb.SetFontAndSize(f_cn, 10);
            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email Name:  " + EmailName, 350, 740, 0);
                        
            cb.SetFontAndSize(f_cn, 10);
            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Personal Email:  " + PersonalEmail, 350, 730, 0);

            cb.SetLineWidth(2f);
            cb.MoveTo(10, 720);
            cb.LineTo(585, 720);
            cb.Stroke();           
            cb.EndText();
        }

        //override the OnPageEnd event handler to add our footer
        int endpagecount = 1;
        public override void OnEndPage(PdfWriter writer, Document doc)
        {
            PdfContentByte cb = writer.DirectContent;
            cb.BeginText();
          
            cb.SetLineWidth(0f);
            cb.MoveTo(10, 50);
            cb.LineTo(585, 50);
            cb.Stroke();

            cb.SetFontAndSize(f_cn, 9);
            cb.ShowTextAligned(PdfContentByte.ALIGN_RIGHT, "Printed On:  " + DateTime.Now.ToString(), 585, 25, 0);
            cb.SetFontAndSize(f_cn, 9);
            cb.ShowTextAligned(PdfContentByte.ALIGN_RIGHT, "Page No:  " + writer.PageNumber, 585, 15, 0);
            
            cb.EndText();
        }

        private int _TotcountPage;

        public int TotcountPage
        {
            get { return _TotcountPage; }
            set { _TotcountPage = value; }
        }
        public override void OnCloseDocument(PdfWriter writer, Document doc)
        {
            PdfContentByte cb = writer.DirectContent;
            cb.BeginText();
            TotcountPage = writer.PageNumber - 1;

            cb.EndText();
            //MessageBox.Show(p.ToString());        
        }
    }
}