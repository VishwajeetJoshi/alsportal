﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net.Mail;
using System.Collections.Specialized;

/// <summary>
/// Summary description for MailSender
/// </summary>
public class MailSender
{
    public void SendMailToHR(string UserID, string Role, string URLPath, string name, string emplyeename, string department)
    {
        string subject = string.Empty;
        string body = string.Empty;
        //<deparment/role> info completed for <employee name>
        //subject = "<p style='font-size:10pt;font-family:Arial;'>" + department + " info completed for " + emplyeename + "</p>";
        subject = department + " info completed for " + emplyeename;
        //This is to confirm that the <department/role> information for <employee name> has been completed and verified by me. 
        body = "<p style='font-size:10pt;font-family:Arial;'>";
        body += "This is to confirm that the " + department + " information for " + emplyeename + " has been completed and verified by me.<br />";
        body += "<br />";
        //<User first, last>
        body += HttpContext.Current.Session["UserFirstLastName"] + "<br />";
        //oMailSender.SendMailMessage("from", "to", "bcc", "cc", "subject", "body");
        body += "</p>";
        SendMailMessage(HttpContext.Current.Session["UserName"].ToString(), UserID, "", "", subject, body);
    }

    public void SendOffBdMailToHR(string UserID, string Role, string URLPath, string name, string emplyeename, string department)
    {
        string subject = string.Empty;
        string body = string.Empty;
        //<deparment/role> info completed for <employee name>
        //subject = "<p style='font-size:10pt;font-family:Arial;'>" + department + " info completed for " + emplyeename + "</p>";
        subject = department + " Offboarding info completed for " + emplyeename;
        //This is to confirm that the <department/role> information for <employee name> has been completed and verified by me. 
        body = "<p style='font-size:10pt;font-family:Arial;'>";
        body += "This is to confirm that the " + department + " information for " + emplyeename + " has been completed and verified by me.<br />";
        body += "<br />";
        //<User first, last>
        body += HttpContext.Current.Session["UserFirstLastName"] + "<br />";
        //oMailSender.SendMailMessage("from", "to", "bcc", "cc", "subject", "body");
        body += "</p>";
        SendMailMessage(HttpContext.Current.Session["UserName"].ToString(), UserID, "", "", subject, body);
    }

    public void SendFinalMailToHR(string UserID, string Role, string name, string emplyeename)
    {
        string subject = string.Empty;
        string body = string.Empty;

        subject = "New employee " + emplyeename + " OnBoarding";
        body = "Hi " + name + ",<br />";
        body += "<br />";
        body += "All sections have been completed by their respective users.<br />";
        body += "Please proceed to complete onboarding process.<br />";

        body += "<br />";
        body += "Thanks<br />";
        body += "<br />";
        body += "Admin<br />";
        body += "ALSBRIDGE<br />";
        body += "OnBoarding Team<br />";
        //oMailSender.SendMailMessage("from", "to", "bcc", "cc", "subject", "body");
        //SendMailMessage("admin@alsbridge.com", UserID, "", "", subject, body);
    }

    public void SendMailMessage(string from, string to, string bcc, string cc, string subject, string body)
    {
        MailMessage mMailMessage = new MailMessage();
        mMailMessage.From = new MailAddress("onboarding@alsbridge.net");
        mMailMessage.To.Add(new MailAddress(to));
        if (!string.IsNullOrEmpty(bcc))
        {
            mMailMessage.Bcc.Add(new MailAddress(bcc));
        }

        if (!string.IsNullOrEmpty(cc))
        {
            mMailMessage.CC.Add(new MailAddress(cc));
        }

        mMailMessage.Subject = subject;
        mMailMessage.Body = body;
        mMailMessage.IsBodyHtml = true;
        mMailMessage.Priority = MailPriority.Normal;

        SmtpClient mSmtpClient = new SmtpClient();
        System.Net.NetworkCredential myCredential = new System.Net.NetworkCredential("onboarding@alsbridge.net", "obAL76#2");
        mSmtpClient.Host = "smtp.emailsrvr.com";
        mSmtpClient.Port = 8025;
        mSmtpClient.UseDefaultCredentials = false;
        mSmtpClient.Credentials = myCredential;
        //mSmtpClient.EnableSsl = true;
        mSmtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
        mSmtpClient.ServicePoint.MaxIdleTime = 1;

        mSmtpClient.Send(mMailMessage);
    }

    public void SendMailAttach(string from, string to, string bcc, string cc, string subject, string body, string attachpath)
    {
        MailMessage mMailMessage = new MailMessage();
        mMailMessage.From = new MailAddress("onboarding@alsbridge.net");
        mMailMessage.To.Add(new MailAddress(to));
        if (!string.IsNullOrEmpty(bcc))
        {
            mMailMessage.Bcc.Add(new MailAddress(bcc));
        }

        if (!string.IsNullOrEmpty(cc))
        {
            mMailMessage.CC.Add(new MailAddress(cc));
        }

        Attachment Attachement1 = new Attachment(HttpContext.Current.Server.MapPath(attachpath));

        mMailMessage.Attachments.Add(Attachement1);

        mMailMessage.Subject = subject;
        mMailMessage.Body = body;
        mMailMessage.IsBodyHtml = true;
        mMailMessage.Priority = MailPriority.Normal;

        SmtpClient mSmtpClient = new SmtpClient();
        System.Net.NetworkCredential myCredential = new System.Net.NetworkCredential("onboarding@alsbridge.net", "obAL76#2");
        mSmtpClient.Host = "smtp.emailsrvr.com";
        mSmtpClient.Port = 8025;
        mSmtpClient.UseDefaultCredentials = false;
        mSmtpClient.Credentials = myCredential;
        //mSmtpClient.EnableSsl = true;
        mSmtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
        mSmtpClient.ServicePoint.MaxIdleTime = 1;

        mSmtpClient.Send(mMailMessage);
    }

    //public void SendMailMessage(string from, string to, string bcc, string cc, string subject, string body)
    //{
    //    MailMessage mMailMessage = new MailMessage();
    //    mMailMessage.From = new MailAddress("onboarding_app@alsbridge.com");
    //    mMailMessage.To.Add(new MailAddress(to));
    //    if (!string.IsNullOrEmpty(bcc))
    //    {
    //        mMailMessage.Bcc.Add(new MailAddress(bcc));
    //    }

    //    if (!string.IsNullOrEmpty(cc))
    //    {
    //        mMailMessage.CC.Add(new MailAddress(cc));
    //    }

    //    mMailMessage.Subject = subject;
    //    mMailMessage.Body = body;
    //    mMailMessage.IsBodyHtml = true;
    //    mMailMessage.Priority = MailPriority.Normal;

    //    SmtpClient mSmtpClient = new SmtpClient();
    //    System.Net.NetworkCredential myCredential = new System.Net.NetworkCredential("onboarding_app@alsbridge.com", "alssup99&");
    //    mSmtpClient.Host = "smtp.office365.com";
    //    mSmtpClient.Port = 587;
    //    mSmtpClient.UseDefaultCredentials = false;
    //    mSmtpClient.Credentials = myCredential;
    //    mSmtpClient.EnableSsl = true;
    //    mSmtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
    //    //mSmtpClient.ServicePoint.MaxIdleTime = 1;

    //    mSmtpClient.Send(mMailMessage);
    //}

    //public void SendMailAttach(string from, string to, string bcc, string cc, string subject, string body, string attachpath)
    //{
    //    MailMessage mMailMessage = new MailMessage();
    //    mMailMessage.From = new MailAddress("onboarding_app@alsbridge.com");
    //    mMailMessage.To.Add(new MailAddress(to));
    //    if (!string.IsNullOrEmpty(bcc))
    //    {
    //        mMailMessage.Bcc.Add(new MailAddress(bcc));
    //    }

    //    if (!string.IsNullOrEmpty(cc))
    //    {
    //        mMailMessage.CC.Add(new MailAddress(cc));
    //    }

    //    Attachment Attachement1 = new Attachment(HttpContext.Current.Server.MapPath(attachpath));

    //    mMailMessage.Attachments.Add(Attachement1);

    //    mMailMessage.Subject = subject;
    //    mMailMessage.Body = body;
    //    mMailMessage.IsBodyHtml = true;
    //    mMailMessage.Priority = MailPriority.Normal;

    //    SmtpClient mSmtpClient = new SmtpClient();
    //    System.Net.NetworkCredential myCredential = new System.Net.NetworkCredential("onboarding_app@alsbridge.com", "alssup99&");
    //    mSmtpClient.Host = "smtp.office365.com";
    //    mSmtpClient.Port = 587;
    //    mSmtpClient.UseDefaultCredentials = false;
    //    mSmtpClient.Credentials = myCredential;
    //    mSmtpClient.EnableSsl = true;
    //    mSmtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
    //    mSmtpClient.ServicePoint.MaxIdleTime = 1;

    //    mSmtpClient.Send(mMailMessage);
    //}

    //public void SendMailMessage(string from, string to, string bcc, string cc, string subject, string body)
    //{
    //    MailMessage mMailMessage = new MailMessage();
    //    mMailMessage.From = new MailAddress("support@alsbridge.com");
    //    mMailMessage.To.Add(new MailAddress(to));
    //    if (!string.IsNullOrEmpty(bcc))
    //    {
    //        mMailMessage.Bcc.Add(new MailAddress(bcc));
    //    }

    //    if (!string.IsNullOrEmpty(cc))
    //    {
    //        mMailMessage.CC.Add(new MailAddress(cc));
    //    }

    //    mMailMessage.Subject = subject;
    //    mMailMessage.Body = body;
    //    mMailMessage.IsBodyHtml = true;
    //    mMailMessage.Priority = MailPriority.Normal;

    //    //SmtpClient mSmtpClient = new SmtpClient("localhost", 25);
    //    //mSmtpClient.Send(mMailMessage);       


    //    //SmtpClient mSmtpClient = new SmtpClient("smtp.emailsrvr.com");

    //    //mSmtpClient.Credentials = new System.Net.NetworkCredential("support@alsbridge.com", "alssup99$#");

    //    SmtpClient mSmtpClient = new SmtpClient();
    //    System.Net.NetworkCredential myCredential = new System.Net.NetworkCredential("support@alsbridge.com", "alssup99$#");
    //    mSmtpClient.Host = "smtp.emailsrvr.com";
    //    mSmtpClient.UseDefaultCredentials = false;
    //    mSmtpClient.Credentials = myCredential;
    //    mSmtpClient.ServicePoint.MaxIdleTime = 1;

    //    mSmtpClient.Send(mMailMessage);
    //}

    //public void SendMailAttach(string from, string to, string bcc, string cc, string subject, string body, string attachpath)
    //{
    //    MailMessage mMailMessage = new MailMessage();
    //    mMailMessage.From = new MailAddress("support@alsbridge.com");
    //    mMailMessage.To.Add(new MailAddress(to));
    //    if (!string.IsNullOrEmpty(bcc))
    //    {
    //        mMailMessage.Bcc.Add(new MailAddress(bcc));
    //    }

    //    if (!string.IsNullOrEmpty(cc))
    //    {
    //        mMailMessage.CC.Add(new MailAddress(cc));
    //    }

    //    Attachment Attachement1 = new Attachment(HttpContext.Current.Server.MapPath(attachpath));

    //    mMailMessage.Attachments.Add(Attachement1);

    //    mMailMessage.Subject = subject;
    //    mMailMessage.Body = body;
    //    mMailMessage.IsBodyHtml = true;
    //    mMailMessage.Priority = MailPriority.Normal;
    //    //SmtpClient mSmtpClient = new SmtpClient("localhost");

    //    //SmtpClient mSmtpClient = new SmtpClient("smtp.emailsrvr.com");

    //    //mSmtpClient.Credentials = new System.Net.NetworkCredential("support@alsbridge.com", "alssup99$#");

    //    SmtpClient mSmtpClient = new SmtpClient();
    //    System.Net.NetworkCredential myCredential = new System.Net.NetworkCredential("support@alsbridge.com", "alssup99$#");
    //    mSmtpClient.Host = "smtp.emailsrvr.com";
    //    mSmtpClient.UseDefaultCredentials = false;
    //    mSmtpClient.Credentials = myCredential;
    //    mSmtpClient.ServicePoint.MaxIdleTime = 1;

    //    mSmtpClient.Send(mMailMessage);
    //}
}