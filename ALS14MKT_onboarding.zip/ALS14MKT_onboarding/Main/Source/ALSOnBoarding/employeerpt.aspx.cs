﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using iTextSharp;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Collections.Generic;
using System.IO;
using myApp.ns.pages;
using MyDataAccess;

public partial class employeerpt : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        GeneratePDF(GetEmployeeDetails(1));
    }

    protected DataTable GetEmployeeDetails(int employeeID)
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@EmployeeID", employeeID);
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetEmployeeDetails4Report", sqlparam).Tables[0];
            return odt;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void GeneratePDF(DataTable ods)
    {

        //ods.Columns.Remove("Employee_Id");
        pdfPageHeaderFooter page = new pdfPageHeaderFooter();

        int EmployeeID = 1;
        string EmployementType = string.Empty;
        DataTable odtEmpDetails = new DataTable("empdetails");
        DataTable odtEmergencyContact = new DataTable("emergencycontact");
        DataTable odtEmpClassification = new DataTable("empclassification");
        DataTable odtEmpIT = new DataTable("empit");
        DataTable odtEmpAdmin = new DataTable("empadmin");
        DataTable odtEmpSecurity = new DataTable("empsecurity");
        DataTable odtEmpPayroll = new DataTable("emppayroll");
        DataTable odtEmpHRProcess = new DataTable("emphrprocess");

        odtEmpDetails = GetEmpDetails(EmployeeID, odtEmpDetails);
        odtEmergencyContact = GetEmpEmergencyDetails(EmployeeID, odtEmergencyContact);
        odtEmpClassification = GetEmpClassificationDetails(EmployeeID, odtEmpClassification);
        odtEmpIT = GetEmpITDetails(EmployeeID, odtEmpIT);
        odtEmpAdmin = GetEmpAdminDetails(EmployeeID, odtEmpAdmin);
        odtEmpSecurity = GetEmpSecurityDetails(EmployeeID, odtEmpSecurity);
        odtEmpPayroll = GetEmpPayrollDetails(EmployeeID, odtEmpPayroll);
        odtEmpHRProcess = GetEmpHRProcessDetails(EmployeeID, odtEmpHRProcess);

        if (odtEmpClassification.Rows.Count > 0)
        {
            EmployementType = odtEmpClassification.Rows[0]["EmploymentType"].ToString();
        }
        if (odtEmpDetails.Rows.Count > 0)
        {
            //page.EmployeeName = "Alen Smith Wang";
            //page.EmployementType = "W/99";
            //page.Address = "A-99 Beetal House";
            //page.City = "New York";
            //page.State = "Dalla 1100445";

            //page.Home = "031245780";
            //page.Cell = "044121457";
            //page.BusinessCard = "Business card dffsfs sfsdfs created";
            //page.EmailName = "alensmith.wang@alsbridge.com.fjufbfg";
            //page.PersonalEmail = "alen.smith@gmail.com.diiifhyuffifuhfjf";

            page.EmployeeName = odtEmpDetails.Rows[0]["FirstName"].ToString() + " " + odtEmpDetails.Rows[0]["MiddleInitial"].ToString() + " " + odtEmpDetails.Rows[0]["LastName"].ToString();
            page.EmployementType = EmployementType;
            page.Address = odtEmpDetails.Rows[0]["StreetAddress"].ToString() + " " + odtEmpDetails.Rows[0]["AptUnit"].ToString();
            page.City = odtEmpDetails.Rows[0]["City"].ToString();
            page.State = odtEmpDetails.Rows[0]["State"].ToString() + " " + odtEmpDetails.Rows[0]["PostalCode"].ToString();

            page.Home = odtEmpDetails.Rows[0]["HomePhone"].ToString();
            page.Cell = odtEmpDetails.Rows[0]["CellPhone"].ToString();
            page.BusinessCard = odtEmpDetails.Rows[0]["BusinessCardName"].ToString();
            page.EmailName = odtEmpDetails.Rows[0]["CompanyEmailID"].ToString();
            page.PersonalEmail = odtEmpDetails.Rows[0]["PerEmailID"].ToString();
        }

        try
        {
            string filename = "Commission Details by person.pdf";


            //modified for open direct without saving on server used memory stream insted of filestream start

            using (var ms = new MemoryStream())
            {
                Document document = new Document(PageSize.A4, 10, 10, 110, 110);
                PdfWriter writer = PdfWriter.GetInstance(document, ms);


                writer.PageEvent = page;
                // Open the document to enable you to write to the document
                document.Open();
                // Makes it possible to add text to a specific place in the document using 
                // a X & Y placement syntax.
                PdfContentByte cb = writer.DirectContent;

                cb.BeginText();
                cb.MoveTo(25, 735);
                Font arial = FontFactory.GetFont("Arial", 7, Font.NORMAL, new Color(0, 0, 0));
                Font arial1 = FontFactory.GetFont("Arial", 7, Font.BOLD, new Color(0, 0, 0));

                int row_height = 700;
                //========Code of Print Emergency Contacts Start
                if (odtEmergencyContact.Rows.Count > 0)
                {
                    string name = odtEmergencyContact.Rows[0]["ConFirstName"].ToString() + " " + odtEmergencyContact.Rows[0]["ConMiddleInitials"].ToString() + " " + odtEmergencyContact.Rows[0]["ConLastName"].ToString();
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Emergency Contact", 15, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, name, 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Primary Phone:  " + odtEmergencyContact.Rows[0]["PrimaryPhone"].ToString(), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, odtEmergencyContact.Rows[0]["ConStreetAddress"].ToString() + " " + odtEmergencyContact.Rows[0]["ConAptUnit"].ToString(), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Alternate Phone:  " + odtEmergencyContact.Rows[0]["AlternatePhone"].ToString(), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, odtEmergencyContact.Rows[0]["ConCity"].ToString(), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Relationship:  " + odtEmergencyContact.Rows[0]["Relationship"].ToString(), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, odtEmergencyContact.Rows[0]["ConState"].ToString() + " " + odtEmergencyContact.Rows[0]["ConZip"].ToString(), 15, row_height, 0);
                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                else
                {

                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Emergency Contact", 15, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Primary Phone: ", 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Alternate Phone: ", 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Relationship: ", 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "", 15, row_height, 0);
                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                //========Code of Print Emergency Contacts End

                //========Code of Print Employee Classification Start
                if (odtEmpClassification.Rows.Count > 0)
                {
                    row_height -= 15;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Employment Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Title:  " + odtEmpClassification.Rows[0]["Title"].ToString(), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Start Date:  " + ConvertToStringDate(odtEmpClassification.Rows[0]["StartDate"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Department:  " + odtEmpClassification.Rows[0]["DepartmentName"].ToString(), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Counsel/Direct Report:  " + odtEmpClassification.Rows[0]["CounselDirectRpt"].ToString(), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Consulting Project:  " + odtEmpClassification.Rows[0]["ProposedConsProject"].ToString(), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Location:  " + odtEmpClassification.Rows[0]["Location"].ToString(), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "PC Equipment: " + ConvertToYesNo(odtEmpClassification.Rows[0]["PCEquipment"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Special Software needs:  " + odtEmpClassification.Rows[0]["SpecialSoftware"].ToString(), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Additional Access:  " + odtEmpClassification.Rows[0]["AdditionalAccess"].ToString(), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Ship Laptop: " + ConvertToYesNo(odtEmpClassification.Rows[0]["LaptopShipAddress"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Other Location:  " + odtEmpClassification.Rows[0]["OtherLocation"].ToString(), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Salesforce login: " + ConvertToYesNo(odtEmpClassification.Rows[0]["SalesforceLogin"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "GTM: " + ConvertToYesNo(odtEmpClassification.Rows[0]["GTM"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Pre-pipeline call: " + ConvertToYesNo(odtEmpClassification.Rows[0]["PPsalesCall"].ToString()), 350, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Network Calls ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Operations: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpClassification.Rows[0]["NC_Operation"].ToString()), 125, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sales: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpClassification.Rows[0]["NC_Sales"].ToString()), 125, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "HSG: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpClassification.Rows[0]["NC_HSG"].ToString()), 125, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                else
                {
                    row_height -= 10;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Employment Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Title: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Start Date: ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Department: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Counsel/Direct Report: ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Consulting Project: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Location: ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "PC Equipment: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Special Software needs: ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Additional Access: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Ship Laptop: ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Other Location: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Salesforce login: ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "GTM: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Pre-pipeline call: ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Network Calls: ", 15, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Operations: ", 20, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sales: ", 20, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "HSG: ", 20, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                //========Code of Print Employee Classification End

                //========Code of Print Employee IT Details Start
                if (odtEmpIT.Rows.Count > 0)
                {
                    row_height -= 15;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "IT Information", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email:  " + odtEmpIT.Rows[0]["EmailAddress"].ToString(), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "AIM ID:  " + odtEmpIT.Rows[0]["AIMID"].ToString(), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Skype ID:  " + odtEmpIT.Rows[0]["SkypeID"].ToString(), 15, row_height, 0);
                    ////////////////////////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email/Sign ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Mail Exchange ", 350, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Alsbridge: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["EmailSign_Alsbridge"].ToString()), 125, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Alsbridge: ", 375, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["MainExchange_Alsbridge"].ToString()), 475, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Probenchmark: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["EmailSign_Probenchmark"].ToString()), 125, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Probenchmark: ", 375, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["MainExchange_Probenchmark"].ToString()), 475, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "NSG: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["EmailSign_NSG"].ToString()), 125, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "OC: ", 375, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["MainExchange_OC"].ToString()), 475, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "OC: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["EmailSign_OC"].ToString()), 125, row_height, 0);
                    ////////////////////////////////

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "POP Required ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Alsbridge: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["POP_Alsbridge"].ToString()), 125, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Probenchmark: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["Pop_Probenchmark"].ToString()), 125, row_height, 0);
                    ////////////////////////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Added to team list: " + ConvertToYesNo(odtEmpIT.Rows[0]["TeamList"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Other list:  " + odtEmpIT.Rows[0]["TeamList_Other"].ToString(), 350, row_height, 0);
                    ////////////////////////////////

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Phone and Laptop ", 15, row_height, 0);

                    //////////////////////////////// chages required for dallas and remote locatioin///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Office Location ", 15, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Dallas Office: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["OfficeLocation_Dallas"].ToString()), 100, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Remote: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["OfficeLocation_Remote"].ToString()), 100, row_height, 0);
                    ////////////////////////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "IF DALLAS OFFICE ", 15, row_height, 0);
                    ////////////////////////////////
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Physical Extension:  " + odtEmpIT.Rows[0]["Dallas_PhyExtention"].ToString(), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Direct No:  " + odtEmpIT.Rows[0]["Dallas_DirectNo"].ToString(), 350, row_height, 0);
                    ////////////////////////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Worksatation ", 15, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Docking Station: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["WS_DockingStation"].ToString()), 125, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Stand: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["WS_Stand"].ToString()), 125, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Monitor: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["WS_Monitor"].ToString()), 125, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Keyboard: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["WS_Keyboard"].ToString()), 125, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Mouse: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["WS_Mouse"].ToString()), 125, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Phone: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["WS_Phone"].ToString()), 125, row_height, 0);
                    ////////////////////////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "IF REMOTE OFFICE ", 15, row_height, 0);
                    ////////////////////////////////
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Virtual Extension:  " + odtEmpIT.Rows[0]["Remote_VirtExtention"].ToString(), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Redirect No:  " + odtEmpIT.Rows[0]["Remote_RedirectNo"].ToString(), 350, row_height, 0);
                    ////////////////////////////////
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Direct Dial No:  " + odtEmpIT.Rows[0]["DirectDialNo"].ToString(), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Laptop Asset Id:  " + odtEmpIT.Rows[0]["LaptopAssest"].ToString(), 350, row_height, 0);

                    /////////////IT CheckList//////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "IT Checklist ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    ////out of two///
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Instant Messengers ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Import Contacts ", 350, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "AIM: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["Messenger_AIM"].ToString()), 100, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "AIM: ", 375, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["Messenger_Skype"].ToString()), 475, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Skype: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ImportContacts_AIM"].ToString()), 100, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Skype: ", 375, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ImportContacts_Skype"].ToString()), 475, row_height, 0);

                    cb.SetFontAndSize(f_cn, 10);
                    /////out of two///

                    ////////////////////////////////
                    cb.EndText();
                    document.NewPage();

                    row_height = 700;
                    cb.BeginText();
                    ////////////////////////////////

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Mandatory Software/Access list ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes/No ", 300, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Adobe Reader: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["AdobeReader"].ToString()), 300, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "MS Office: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["MSOffice"].ToString()), 300, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Wiki: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["Wiki"].ToString()), 300, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "GTM Meeting Loader: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["GTMmeeting"].ToString()), 300, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "AVG: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["AVG"].ToString()), 300, row_height, 0);
                    
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Printers: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["Printers"].ToString()), 300, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Jungle Dist: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["JungleDisk"].ToString()), 300, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "PDF Creator: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["PDFCreator"].ToString()), 300, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Add all shortcuts: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["AddShortcuts"].ToString()), 300, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Map JD my docs and desktop: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["MapJDdocsdesktop"].ToString()), 300, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email snapshot and keys to support@alsbridge.com: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["SupportMail"].ToString()), 300, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Install encrypted SD card and local script: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["SDcard"].ToString()), 300, row_height, 0);
                    ////////////////////////////////
                    ///////////////// yes and Confirm ///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Optional Software/Access confirm list ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirm ", 350, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "GTM License: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesGTMLicense"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmGTMLicense"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "PGI Conference: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesPGIConference"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmPGIConference"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Webex License: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesWebexLicense"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmWebexLicense"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "MS Project: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesMSProject"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmMSProject"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "MS Vision: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesMSVisio"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmMSVisio"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "VPN: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesVPN"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmVPN"].ToString()), 350, row_height, 0);
                    ////////////////////////////////
                    ///////////////// yes and Confirm ///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sales confirm list ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirm ", 350, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Salesforce: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesSalesforce"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmSalesforce"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Inside View: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesInsideView"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmInsideView"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Leadlander: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesLeadlander"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmLeadlander"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "PowerDialer: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesPowerDialer"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmPowerDialer"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Radar Report US: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesRRUS"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmRRUS"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Radar Report EU: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesRREU"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmRREU"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Discover Org: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesDiscoverOrg"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmDiscoverOrg"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Auto Emails: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesAutoEmail"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmAutoEmail"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "alsbridgesales@alsbridge.com: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesAlsbridgesalesMail"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmAlsbridgesalesMail"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "pbsales@alsbridge.com: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesPbsalesMail"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmPbsalesMail"].ToString()), 350, row_height, 0);
                    ////////////////////////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Additional comment:  " + odtEmpIT.Rows[0]["AdditionalComment"].ToString(), 15, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                else
                {
                    row_height -= 15;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "IT Information", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "AIM ID: ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Skype ID: ", 15, row_height, 0);
                    ////////////////////////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email/Sign ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Mail Exchange ", 350, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Alsbridge: ", 25, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Alsbridge: ", 375, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Probenchmark: ", 25, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Probenchmark: ", 375, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "NSG: ", 25, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "OC: ", 375, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "OC: ", 25, row_height, 0);
                    ////////////////////////////////

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "POP Required ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Alsbridge: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Probenchmark: ", 25, row_height, 0);
                    ////////////////////////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Added to team list: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Other list: ", 350, row_height, 0);
                    ////////////////////////////////

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Phone and Laptop ", 15, row_height, 0);

                    //////////////////////////////// chages required for dallas and remote locatioin///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Office Location: ", 15, row_height, 0);
                    ////////////////////////////////
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "IF DALLAS OFFICE ", 15, row_height, 0);
                    ////////////////////////////////
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Physical Extension: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Direct No: ", 350, row_height, 0);
                    ////////////////////////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Worksatation ", 15, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Docking Station: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Stand: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Monitor: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Keyboard: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Mouse: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Phone: ", 25, row_height, 0);
                    ////////////////////////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "IF REMOTE OFFICE ", 15, row_height, 0);
                    ////////////////////////////////
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Virtual Extension: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Redirect No: ", 350, row_height, 0);
                    ////////////////////////////////
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Direct Dial No: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Laptop Asset Id: ", 350, row_height, 0);

                    /////////////IT CheckList//////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "IT Checklist ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    ////out of two///
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Instant Messengers: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    /////out of two///
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Import Contacts: ", 350, row_height, 0);
                    ////////////////////////////////

                    ////////////////////////////////
                    cb.EndText();
                    document.NewPage();

                    row_height = 700;
                    cb.BeginText();
                    ////////////////////////////////
                    
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Mandatory Software/Access list ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes/No ", 300, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Adobe Reader: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "MS Office: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Wiki: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "GTM Meeting Loader: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "AVG: ", 25, row_height, 0);
                  

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Printers: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Jungle Dist: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "PDF Creator: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Add all shortcuts: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Map JD my docs and desktop: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email snapshot and keys to support@alsbridge.com: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Install encrypted SD card and local script: ", 25, row_height, 0);
                    ////////////////////////////////
                    ///////////////// yes and Confirm ///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Optional Software/Access confirm list ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirm ", 350, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "GTM License: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "PGI Conference: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Webex License: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "MS Project: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "MS Vision: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "VPN: ", 25, row_height, 0);
                    ////////////////////////////////
                    ///////////////// yes and Confirm ///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sales confirm list ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirm ", 350, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Salesforce: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Inside View: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Leadlander: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "PowerDialer: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Radar Report US: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Radar Report EU: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Discover Org: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Auto Emails: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "alsbridgesales@alsbridge.com: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "pbsales@alsbridge.com: ", 25, row_height, 0);
                    ////////////////////////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Additional comment: ", 15, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                //========Code of Print Employee IT Details End

                //========Code of Print Employee Administrative Details Start
                if (odtEmpAdmin.Rows.Count > 0)
                {
                    row_height -= 15;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Administrative Details", 15, row_height, 0);

                    ///////////////// yes and Confirm ///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Information ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirm ", 350, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Business Cards: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesBusinessCard"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmBusinessCard"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Business Cards Ordered: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesBusinessCardOrder"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmBusinessCardOrder"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Business Cards Quantity: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesBCQty"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, odtEmpAdmin.Rows[0]["BCQty"].ToString(), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Business Cards Confirm by HR: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesBusinessCardConfirmHR"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmBusinessCardConfirmHR"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Orbitz Account Activation: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesOrbitzAccountActivation"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmOrbitzAccountActivation"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "FedEx Discount Cards: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesFedExDiscountCard"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmFedExDiscountCard"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Outsourcing Leadership Login: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesOSLeadershipLogin"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmOSLeadershipLogin"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "NING Social Invite: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesNINGSocialInvite"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmNINGSocialInvite"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Administration emails with information on logins: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesAdministrationEmail"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmAdministrationEmail"].ToString()), 350, row_height, 0);
                    ////////////////////////////////

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                else
                {
                    row_height -= 15;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Administrative Details", 15, row_height, 0);

                    ///////////////// yes and Confirm ///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Information ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirm ", 350, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Business Cards: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Business Cards Ordered: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Business Cards Quantity: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Business Cards Confirm by HR: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Orbitz Account Activation: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "FedEx Discount Cards: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Outsourcing Leadership Login: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "NING Social Invite: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Administration emails with information on logins: ", 25, row_height, 0);
                    ////////////////////////////////

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                //========Code of Print Employee Administrative Details End

                //========Code of Print Employee Security Details Start
                if (odtEmpSecurity.Rows.Count > 0)
                {
                    row_height -= 15;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Security Details", 15, row_height, 0);

                    ///////////////// yes and Confirm ///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Information ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirm ", 350, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Parking Entry: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["YesParkingEntry"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["ConfirmParkingEntry"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Entry Key: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["YesEntryKey"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["ConfirmEntryKey"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Security Code: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["YesSecurityCode"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["ConfirmSecurityCode"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Security Information Sent: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["YesSecurityInfoSent"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["ConfirmSecurityInfoSent"].ToString()), 350, row_height, 0);

                    ///////////////////////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Meetings Invite ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirm ", 350, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Consulting Early Stage Pipeline: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["YesConsulting_ESP"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["ConfirmConsulting_ESP"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Consulting Proposal Pipeling: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["YesConsulting_PP"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["ConfirmConsulting_PP"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Consulting Operations: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["YesConsulting_OP"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["ConfirmConsulting_OP"].ToString()), 350, row_height, 0);

                    //////////////////////////////////////////
                    cb.EndText();
                    document.NewPage();
                    row_height = 700;
                    cb.BeginText();
                    //////////////////////////////////////////
                    
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Vendor Early Stage Pipeling: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["YesVendor_ESP"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["ConfirmVendor_ESP"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Vendor Proposal Pipeline: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["YesVendor_PP"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["ConfirmVendor_PP"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "NSG-HSG Pipeline: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["YesNSG_HSG_P"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["ConfirmNSG_HSG_P"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "NSG Operations: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["YesNSG_OP"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["ConfirmNSG_OP"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "HSG Operations: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["YesHSG_OP"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["ConfirmHSG_OP"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "US-UK Pipeline: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["YesUS_UK_P"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["ConfirmUS_UK_P"].ToString()), 350, row_height, 0);
                    ////////////////////////////////

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                else
                {
                    row_height -= 15;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Security Details", 15, row_height, 0);

                    ///////////////// yes and Confirm ///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Information ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirm ", 350, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Parking Entry: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Entry Key: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Security Code: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Security Information Sent: ", 25, row_height, 0);

                    ///////////////////////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Meetings Invite ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirm ", 350, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Consulting Early Stage Pipeline: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Consulting Proposal Pipeling: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Consulting Operations: ", 25, row_height, 0);

                    //////////////////////////////////////////
                    cb.EndText();
                    document.NewPage();
                    row_height = 700;
                    cb.BeginText();
                    //////////////////////////////////////////

                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Vendor Early Stage Pipeling: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Vendor Proposal Pipeline: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "NSG-HSG Pipeline: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "NSG Operations: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "HSG Operations: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "US-UK Pipeline: ", 25, row_height, 0);
                    ////////////////////////////////

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                //========Code of Print Employee Security Details End

                //========Code of Print Employee Payroll Details Start
                if (odtEmpPayroll.Rows.Count > 0)
                {
                    row_height -= 15;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Payroll Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Replicon Counsel & Project: " + ConvertToYesNo(odtEmpPayroll.Rows[0]["RepliconCounselProject"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Add to ADP Payroll: " + ConvertToYesNo(odtEmpPayroll.Rows[0]["ADPPayroll"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                else
                {
                    row_height -= 15;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Payroll Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Replicon Counsel & Project: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Add to ADP Payroll: ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                //========Code of Print Employee Payroll Details End

                //========Code of Print Employee HR Process Details Start
                if (odtEmpHRProcess.Rows.Count > 0)
                {
                    row_height -= 15;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Final HR Process", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Pre-Onboarding ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Welcome Email sent with documents ", 15, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "W4/W9: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpHRProcess.Rows[0]["WE_W4W9"].ToString()), 200, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "I9: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpHRProcess.Rows[0]["WE_I9"].ToString()), 200, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Direct Deposit Form: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpHRProcess.Rows[0]["WE_DDForm"].ToString()), 200, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Policy Signature Pages(4): ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpHRProcess.Rows[0]["WE_PolicySign"].ToString()), 200, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Run eVerify: " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["Run_e_verify"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Conduct Background check: " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["BackgoundCheck"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Agreement Executed by Ben: " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["AgreementExecuted"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "All documents gathered & confirm: " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["DocumentsGathered"].ToString()), 350, row_height, 0);

                    ////////////////////////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Consulting ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Counsel Group Lead Intro Sent: " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["CounselGroupLeadIntroduction"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Peer Coaching Intro sent: " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["PeerCoachingIntroduction"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Bio Updated and Posted on the Wiki: " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["BioUpdatedPostedOnWiki"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Contracts Meeting set with Reaghan: " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["ContactsMeetingWithReaghan"].ToString()), 350, row_height, 0);
                    ////////////////////////////////

                    ////////////////////////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "First Week ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Added to Directory: " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["AddToDirectory"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Company Directory Provided: " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["CompanyDirectoryProvided"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Voicemail Instruction sent: " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["VoicemailInstuctionSent"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Vcf Created/Uploaded: " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["VcfCreatedUploaded"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Skills Database Completed: " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["SkillDatabase"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Welcome Lunch Scheduled: " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["WelcomeLunchScheduled"].ToString()), 350, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Added to Benefits Portal ", 15, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Benefits Video Sent: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpHRProcess.Rows[0]["BenefitVideoSent"].ToString()), 200, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Benefits Overview Completed: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpHRProcess.Rows[0]["BenefitOverview"].ToString()), 200, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Benefits Enrollment Sent: ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpHRProcess.Rows[0]["BenefitEnrollmentSent"].ToString()), 200, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Added to 401(k): " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["Added401k"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Individual headshot: " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["IndividualHeadshot"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sales Support Training Completed: " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["TrainingSalesSupport"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "PB/OC Training Completed: " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["TrainingPBOC"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Replicon Training Completed: " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["TrainingReplicon"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Alsbridge Overview Completed: " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["AlsbridgeOverviewTraining"].ToString()), 350, row_height, 0);

                    ////////////////////////////////

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                else
                {
                    row_height -= 15;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Final HR Process", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Pre-Onboarding ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Welcome Email sent with documents ", 15, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "W4/W9: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "I9: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Direct Deposit Form: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Policy Signature Pages(4): ", 25, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Run eVerify: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Conduct Background check: ", 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Agreement Executed by Ben: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "All documents gathered & confirm: ", 350, row_height, 0);

                    ////////////////////////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Consulting ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Counsel Group Lead Intro Sent: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Peer Coaching Intro sent: ", 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Bio Updated and Posted on the Wiki: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Contracts Meeting set with Reaghan: ", 350, row_height, 0);
                    ////////////////////////////////

                    ////////////////////////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "First Week ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Added to Directory: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Company Directory Provided: ", 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Voicemail Instruction sent: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Vcf Created/Uploaded: ", 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Skills Database Completed: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Welcome Lunch Scheduled: ", 350, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Added to Benefits Portal ", 15, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Benefits Video Sent: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Benefits Overview Completed: ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Benefits Enrollment Sent: ", 25, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Added to 401(k): ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Individual headshot: ", 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sales Support Training Completed: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "PB/OC Training Completed: ", 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Replicon Training Completed: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Alsbridge Overview Completed: ", 350, row_height, 0);

                    ////////////////////////////////

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                //========Code of Print Employee HR Process Details End

                // Close the document, the writer and the filestream!
                document.Close();
                writer.Close();
                //fs.Close();

                Response.Clear();
                Response.ClearHeaders();
                Response.Buffer = true;
                Response.Charset = "";
                //Response.ContentType = "application/excel";                
                this.EnableViewState = false;
                //Code to generate chart at excel file at client side              

                //modified for open direct without saving on server start

                Response.ContentType = "application/octet-stream";
                Response.AddHeader("content-disposition", "attachment;filename=" + filename);
                Response.Buffer = true;
                Response.Clear();
                var bytes = ms.ToArray();
                Response.OutputStream.Write(bytes, 0, bytes.Length);
                Response.OutputStream.Flush();

                //LblMsg.Text = "Invoiced saved to the invoice folder. Good job!";
            }
        }
        catch (Exception rror)
        {
            //LblMsg.Text = rror.Message;
            //MsgDiv.Visible = true;
        }
    }

    private string ConvertToYesNo(string strValue)
    {
        strValue = strValue.Trim();
        if (strValue == null)
            return "No";
        else if (strValue == "")
            return "No";
        else if (strValue == "0")
            return "No";
        else if (strValue.ToLower() == "false")
            return "No";
        else if (strValue.ToLower() == "true")
            return "Yes";
        else if (strValue == "1")
            return "Yes";
        else
            return "No";
    }

    private string ConvertToStringDate(string strValue)
    {
        if (strValue == null)
            return "";
        else if (strValue == "")
            return "";
        else
            return Convert.ToDateTime(strValue).ToString("MM/dd/yyyy");
    }

    private static DataTable GetEmpDetails(int EmployeeID, DataTable odtEmpDetails)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            odtEmpDetails = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select * from Employee.EmployeeDetails Where EmployeeID='" + EmployeeID + "'").Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmpDetails;
    }
    private static DataTable GetEmpEmergencyDetails(int EmployeeID, DataTable odtEmergencyContact)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            odtEmergencyContact = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select * from Employee.EmergencyContact Where EmployeeID='" + EmployeeID + "'").Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmergencyContact;
    }
    private static DataTable GetEmpClassificationDetails(int EmployeeID, DataTable odtEmpClassification)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            string query = string.Empty;
            query = " Select ec.*, dd.DepartmentName from Employee.Classification ec";
            query += " left join Employee.Department dd on dd.DepartmentID = ec.DepartmentID";
            query += " Where EmployeeID='" + EmployeeID + "'";
            odtEmpClassification = SqlHelper.ExecuteDataset(con, CommandType.Text, query).Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmpClassification;
    }
    private static DataTable GetEmpITDetails(int EmployeeID, DataTable odtEmpIT)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            odtEmpIT = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select * from Employee.ITDetails Where EmployeeID='" + EmployeeID + "'").Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmpIT;
    }
    private static DataTable GetEmpAdminDetails(int EmployeeID, DataTable odtEmpAdmin)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            odtEmpAdmin = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select * from Employee.Administrative Where EmployeeID='" + EmployeeID + "'").Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmpAdmin;
    }
    private static DataTable GetEmpSecurityDetails(int EmployeeID, DataTable odtEmpSecurity)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            odtEmpSecurity = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select * from Employee.Security Where EmployeeID='" + EmployeeID + "'").Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmpSecurity;
    }
    private static DataTable GetEmpPayrollDetails(int EmployeeID, DataTable odtEmpPayroll)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            odtEmpPayroll = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select * from Employee.Payroll Where EmployeeID='" + EmployeeID + "'").Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmpPayroll;
    }
    private static DataTable GetEmpHRProcessDetails(int EmployeeID, DataTable odtEmpHRProcess)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            odtEmpHRProcess = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select * from Employee.HRProcess Where EmployeeID='" + EmployeeID + "'").Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmpHRProcess;
    }

    BaseFont f_cb1 = BaseFont.CreateFont("c:\\windows\\fonts\\calibrib.ttf", BaseFont.CP1257, BaseFont.NOT_EMBEDDED);
    BaseFont f_cb = BaseFont.CreateFont("c:\\windows\\fonts\\calibrib.ttf", BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
    BaseFont f_cn = BaseFont.CreateFont("c:\\windows\\fonts\\calibri.ttf", BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
    BaseFont f_ForColor = BaseFont.CreateFont("c:\\windows\\fonts\\calibri.ttf", BaseFont.CP1252, BaseFont.NOT_EMBEDDED);

    private void writeText(PdfContentByte cb, string Text, int X, int Y, BaseFont font, int Size)
    {
        cb.SetFontAndSize(font, Size);
        cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, Text, X, Y, 0);
    }
}
