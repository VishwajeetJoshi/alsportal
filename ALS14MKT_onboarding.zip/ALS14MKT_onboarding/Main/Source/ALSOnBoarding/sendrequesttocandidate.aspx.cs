﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;

public partial class sendrequesttocandidate : System.Web.UI.Page
{
    private int m_EmployeeID;
    MailSender oMailSender = new MailSender();
    CommonClass CC = new CommonClass();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        if (!IsPostBack)
        {
            Session["update"] = Server.UrlEncode(System.DateTime.Now.ToString());
        }
        MsgDiv.Visible = false;
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        ViewState["update"] = Session["update"];
    }

    protected void btnSend_Click(object sender, EventArgs e)
    {
        if (Session["update"].ToString() == ViewState["update"].ToString())
        {
            if (ValidateRecord() == false)
            {
                MsgDiv.Visible = true;
                return;
            }

            string AbsoluteUri = string.Empty;
            string CurrentFilePath = string.Empty;
            string QueryString = string.Empty;

            AbsoluteUri = Request.Url.AbsoluteUri.ToString();
            CurrentFilePath = Request.AppRelativeCurrentExecutionFilePath.ToString();
            CurrentFilePath = CurrentFilePath.Remove(0, 2);
            QueryString = Request.QueryString.ToString();
            if (QueryString == string.Empty)
            {
                AbsoluteUri = AbsoluteUri.Replace(CurrentFilePath, "");
            }
            else
            {
                AbsoluteUri = AbsoluteUri.Replace(CurrentFilePath + "?" + QueryString, "");
            }
            AbsoluteUri = AbsoluteUri + "candidatedetails.aspx?";

            string gid = System.Guid.NewGuid().ToString();

            m_EmployeeID = GetEmployeeID();

            SqlConnection con = SqlHelper.GetConnection();
            con.Open();
            try
            {
                SqlParameter[] sqlparam = new SqlParameter[] {
                                    new SqlParameter("@EmployeeID", m_EmployeeID),
                                    new SqlParameter("@FirstName", Server.HtmlEncode(txtFirstName.Text.Trim())),
                                    new SqlParameter("@LastName", Server.HtmlEncode(txtLastName.Text.Trim())),
                                    new SqlParameter("@PerEmailID", Server.HtmlEncode(txtUserName.Text.Trim())),
                                    new SqlParameter("@Code", gid),
                                    new SqlParameter("@CreatedBy", Session["UserName"])};

                SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddNewCandidate", sqlparam);
                LblMsg.Text = "Record was added successfully";
                MsgDiv.Visible = true;                
                //send link
                //AbsoluteUri += "eid=" + Encrypt(m_EmployeeID.ToString()) + "&code=" + gid;
                //AbsoluteUri += Encrypt("code=" + gid);
                AbsoluteUri += "code=" + gid;
                SendMail(txtUserName.Text, AbsoluteUri, txtFirstName.Text + " " + txtLastName);
                Reset();
            }
            catch (Exception ex)
            {
                CommonClass.AddErrorTrail("sendrequesttocandidate.aspx", "btnSave_Click", ex.Message);
                LblMsg.Text = "Oops! Server problem....try after some time";
                MsgDiv.Visible = true;
            }
            finally { con.Close(); }
            Session["update"] = Server.UrlEncode(System.DateTime.Now.ToString());
        }
        else
        {
            Reset();
        }        
    }

    private bool ValidateRecord()
    {
        SqlConnection sqlcon = SqlHelper.GetConnection();
        sqlcon.Open();
        try
        {
            DataTable odt = new DataTable();
            odt = SqlHelper.ExecuteDataset(sqlcon, CommandType.Text, "Select * from Employee.EmployeeDetails Where PerEmailID = '" + Server.HtmlEncode(txtUserName.Text.Trim()) + "'").Tables[0];
            if (odt.Rows.Count > 0)
            {
                LblMsg.Text = "This emailid already exist. You cannot enter duplicate emailid.";
                return false;
            }
        }
        catch (Exception ex)
        { }
        finally { sqlcon.Close(); }

        return true;
    }

    private void SendMail(string toEmailID, string appLink, string name)
    {
        string subject = string.Empty;
        string body = string.Empty;

        //subject = "<p style='font-size:10pt;font-family:Arial;'>New employee " + emplyeename + " OnBoarding</p>";
        subject = "Welcome to Alsbridge!";

        //body = name + ",<br />";
        body = "<p style='font-size:10pt;font-family:Arial;'>";
        body += "Hello,<br />";
        
        body += "<br />";
        body += "Welcome to Alsbridge, we are so excited to have you on our team! To begin we ask that you please click the link below and fill out the details. We will utilize this information to launch your On Boarding process.<br />";
        body += "<br />";
        body += appLink;
        body += "<br />";
        body += "<br />";
        body += "Thanks and Regards<br />";
        body += ConfigurationManager.AppSettings["HRName"].ToString() + "<br />";
        //body += "Director of Human Resources<br />";
        //body += "214-696-6410<br />";
        body += ConfigurationManager.AppSettings["HRContact"].ToString() + "<br />";
        body += "</p>";
        //oMailSender.SendMailMessage("from", "to", "bcc", "cc", "subject", "body");
        oMailSender.SendMailMessage("", toEmailID, "", "", subject, body);
    }

    private const string PARAMETER_NAME = "enc=";
    private const string ENCRYPTION_KEY = "EncDec";
    private readonly static byte[] SALT = Encoding.ASCII.GetBytes(ENCRYPTION_KEY.Length.ToString());

    private static string Encrypt(string inputText)
    {
        RijndaelManaged rijndaelCipher = new RijndaelManaged();
        byte[] plainText = Encoding.Unicode.GetBytes(inputText);
        PasswordDeriveBytes SecretKey = new PasswordDeriveBytes(ENCRYPTION_KEY, SALT);
        using (ICryptoTransform encryptor = rijndaelCipher.CreateEncryptor(SecretKey.GetBytes(32), SecretKey.GetBytes(16)))
        {
            using (MemoryStream memoryStream = new MemoryStream())
            {
                using (CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                {
                    cryptoStream.Write(plainText, 0, plainText.Length);
                    cryptoStream.FlushFinalBlock();
                    return PARAMETER_NAME + Convert.ToBase64String(memoryStream.ToArray());
                }
            }
        }
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Reset();
    }

    private void Reset()
    {
        txtFirstName.Text = "";
        txtLastName.Text = "";
        txtUserName.Text = "";
    }

    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("employeelisting.aspx");
    }

    protected void btnSkip_Click(object sender, EventArgs e)
    {
        Response.Redirect("createemployee.aspx");
    }

    private int GetEmployeeID()
    {
        int empid;
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            empid = AddOne(Convert.ToString((SqlHelper.ExecuteScalar(con, CommandType.Text, "Select max(EmployeeID) from Employee.EmployeeDetails with (nolock)"))));
            m_EmployeeID = empid;
            return empid;
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("sendrequesttocandidate.aspx", "GetEmployeeID", ex.Message);
            return 1;
        }
        finally
        { con.Close(); }
    }

    private int AddOne(string value)
    {
        if (value == null)
        {
            return 1;
        }
        else if (value == "")
        {
            return 1;
        }
        else
        {
            return Convert.ToInt32(value) + 1;
        }
    }
}
