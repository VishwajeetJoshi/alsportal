﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;
using System.Globalization;
using System.Net.Mail;
using System.Configuration;
using System.Web.Hosting;

public partial class employeeclassification : System.Web.UI.Page
{
    CommonClass CC = new CommonClass();
    MailSender oMailSender = new MailSender();
    private string m_Mode = string.Empty;
    private int m_EmployeeID;
    private bool FixMode = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        SetQueryStringValue();

        ddlDepartment.Attributes.Add("onChange", "validateMessage()");

        if (!IsPostBack)
        {
            FillDropDownList();
            FillEmployeeClassification();
            BindToolTip(ddlDepartment);
            hDepartmentValue.Value = ddlDepartment.SelectedIndex.ToString();
            hSecurityFix.Value = Convert.ToString(IsSecurityFix());
        }
        MsgDiv.Visible = false;
    }

    private void FillDropDownList()
    {
        //-------Fill Department
        DataTable odtDepartment = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            //odtDepartment = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select * from Employee.Department order by DepartmentName asc").Tables[0];
            odtDepartment = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetDepartmentViewDetails").Tables[0];
            if (odtDepartment.Rows.Count > 0)
            {
                odtDepartment = CC.DecodeDataTable(odtDepartment, "DepartmentName");
                ddlDepartment.DataSource = odtDepartment;
                ddlDepartment.DataTextField = "DepartmentName";
                ddlDepartment.DataValueField = "DepartmentID";
                ddlDepartment.DataBind();
                ddlDepartment.Items.Insert(0, new ListItem("-- Select One --", "0"));
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("employeeclassification.aspx", "FillDropDownList", ex.Message);
        }
        finally { con.Close(); }
    }

    private void BindToolTip(ListControl list)
    {
        foreach (ListItem item in list.Items)
        {
            item.Attributes.Add("title", item.Text);

        }
    }

    private void SetQueryStringValue()
    {
        try
        {
            if (Request.QueryString["EmployeeID"] != null)
            {
                m_EmployeeID = Convert.ToInt32(Request.QueryString["EmployeeID"]);
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("employeeclassification.aspx", "SetQueryStringValue", ex.Message);
            m_Mode = "Add";
            m_EmployeeID = 0;
        }
    }

    private void SetUserRole()
    {
        if (Session["UserRole"] != null)
        {
            if (Session["UserRole"].ToString().ToLower().Contains("system admin") || Session["UserRole"].ToString().ToLower().Contains("hr"))
            {
                if (m_EmployeeID > 0)
                { divSave.Visible = true; }
                else
                { divSave.Visible = false; }
            }
            else
            { divSave.Visible = false; }
        }
    }

    protected override void Render(HtmlTextWriter writer)
    {
        SetUserRole();
        base.Render(writer);
    }

    private void FillEmployeeClassification()
    {
        PopulateDetails();
        //if (FixMode == true)
        //{
        //    EnableDisable(true);
        //    divSave.Visible = false;
        //    divBack.Visible = true;
        //}
    }

    private void PopulateDetails()
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetEmployeeClassification", sqlparam).Tables[0];
            if (odt.Rows.Count > 0)
            {
                ddlEmployementType.SelectedIndex = ddlEmployementType.Items.IndexOf(ddlEmployementType.Items.FindByText(odt.Rows[0]["EmploymentType"].ToString()));
                txtTitle.Text = IfNullThenBlank(odt.Rows[0]["Title"].ToString());
                if (DBNull.Value != (odt.Rows[0]["StartDate"]))
                {
                    DateTime dt;
                    dt = Convert.ToDateTime(odt.Rows[0]["StartDate"].ToString());
                    txtStartDate.Text = CC.checkdate(dt);
                }

                //Laptop Date start
                if (DBNull.Value != (odt.Rows[0]["LaptopDate"]))
                {
                    DateTime dt;
                    dt = Convert.ToDateTime(odt.Rows[0]["LaptopDate"].ToString());
                    txtLaptopDate.Text = CC.checkdate(dt);
                }
                //Laptop date end
                //txtDepartment.Text = IfNullThenBlank(odt.Rows[0]["Department"].ToString());

                ddlDepartment.SelectedIndex = ddlDepartment.Items.IndexOf(ddlDepartment.Items.FindByValue(odt.Rows[0]["DepartmentID"].ToString()));

                if (ddlDepartment.SelectedIndex == 0)
                {
                    ddlDepartment.Items.RemoveAt(0);
                    ddlDepartment.Items.Insert(0, new ListItem(odt.Rows[0]["DepartmentName"].ToString(), odt.Rows[0]["DepartmentID"].ToString()));
                    //ddlDepartment.Text = odt.Rows[0]["DepartmentName"].ToString();
                }

                //txtProposedConsulting.Text = IfNullThenBlank(odt.Rows[0]["ProposedConsProject"].ToString());
                txtLocation.Text = IfNullThenBlank(odt.Rows[0]["Location"].ToString());

                cbPcEquipment.Checked = CC.IfNullThenZero(odt.Rows[0]["PCEquipment"].ToString());

                txtSpecialSW.Text = IfNullThenBlank(odt.Rows[0]["SpecialSoftware"].ToString());
                txtAddAccess.Text = IfNullThenBlank(odt.Rows[0]["AdditionalAccess"].ToString());

                cbShipAddress.Checked = CC.IfNullThenZero(odt.Rows[0]["LaptopShipAddress"].ToString());

                txtOtherLocation.Text = IfNullThenBlank(odt.Rows[0]["OtherLocation"].ToString());

                cbSalesforceLogin.Checked = CC.IfNullThenZero(odt.Rows[0]["SalesforceLogin"].ToString());
                cbGTM.Checked = CC.IfNullThenZero(odt.Rows[0]["GTM"].ToString());
                cbPPsalesCall.Checked = CC.IfNullThenZero(odt.Rows[0]["PPsalesCall"].ToString());
                cbOperations.Checked = CC.IfNullThenZero(odt.Rows[0]["NC_Operation"].ToString());
                //cbSales.Checked = CC.IfNullThenZero(odt.Rows[0]["NC_Sales"].ToString());
                //cbHSG.Checked = CC.IfNullThenZero(odt.Rows[0]["NC_HSG"].ToString());

                //
                ListItem selectedListItem = ddlRoleType.Items.FindByText(odt.Rows[0]["Role_Type"].ToString());
                if (selectedListItem != null)
                {
                    selectedListItem.Selected = true;
                }

                //new fields added on 190814
                cbAllHands.Checked = CC.IfNullThenZero(odt.Rows[0]["AllHands"].ToString());
                //cbManager.Checked = CC.IfNullThenZero(odt.Rows[0]["IsManager"].ToString());
                txtManager.Text = IfNullThenBlank(odt.Rows[0]["IsManager"].ToString());

                FixMode = (bool)odt.Rows[0]["FixMode"];
            }

        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("employeeclassification.aspx", "PopulateDetails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    private string IfNullThenBlank(string value)
    {
        if (value == null)
        {
            return "";
        }
        else if (value == "")
        {
            return "";
        }
        else
        {
            return Server.HtmlDecode(value);
        }
    }

    private void Reset()
    {
        ddlEmployementType.SelectedIndex = 0;
        txtTitle.Text = "";
        txtStartDate.Text = "";
        //Laptop Date start
        txtLaptopDate.Text = "";
        ddlDepartment.SelectedIndex = 0;

        txtLocation.Text = "";
        cbPcEquipment.Checked = false;

        txtSpecialSW.Text = "";
        txtAddAccess.Text = "";
        cbShipAddress.Checked = false;
        txtOtherLocation.Text = "";

        cbSalesforceLogin.Checked = false;
        cbGTM.Checked = false;
        cbPPsalesCall.Checked = false;
        cbOperations.Checked = false;
        //cbSales.Checked = false;
        //cbHSG.Checked = false;
        ddlRoleType.SelectedIndex = 0;

        //new field added 190814
        cbAllHands.Checked = false;
        txtManager.Text = "";
    }

    private void EnableDisable(bool boolValue)
    {
        //ddlEmployementType.SelectedIndex = 0;
        //txtTitle.ReadOnly = boolValue;
        //txtStartDate.ReadOnly = boolValue;
        //txtDepartment.ReadOnly = boolValue;
        //txtCounselDirect.ReadOnly = boolValue;
        //txtProposedConsulting.ReadOnly = boolValue;
        //txtLocation.ReadOnly = boolValue;
        //txtPcEquipment.ReadOnly = boolValue;
        //txtSpecialSW.ReadOnly = boolValue;
        //txtAddAccess.ReadOnly = boolValue;
        //txtSalesMeetNoti.ReadOnly = boolValue;
        //txtAllHandsMeetNoti.ReadOnly = boolValue;
        //txtMDDMeetNoti.ReadOnly = boolValue;
        //txtShipAddress.ReadOnly = boolValue;
        //txtOtherLocation.ReadOnly = boolValue;

        //cbSalesforceLogin.Checked = false;
        //cbPPsalesCall.Checked = false;
        //cbOperations.Checked = false;
        //cbSales.Checked = false;
        //cbHSG.Checked = false;
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        string EmploymentType = string.Empty;
        string Department = string.Empty;
        string RoleType = string.Empty;

        if (ddlEmployementType.SelectedIndex != 0)
        {
            EmploymentType = ddlEmployementType.SelectedItem.ToString();
        }
        if (ddlDepartment.SelectedValue != "0")
        {
            Department = ddlDepartment.SelectedValue;
        }
        if (ddlRoleType.SelectedIndex != 0)
        {
            RoleType = ddlRoleType.SelectedItem.ToString();
        }

        DateTime StartDate;
        if (txtStartDate.Text != "")
            StartDate = DateTime.ParseExact(txtStartDate.Text, "MM/dd/yyyy", CultureInfo.CurrentCulture);
        else
            StartDate = Convert.ToDateTime("01/01/1900");

        //Laptop date start
        DateTime LaptopDate;
        if (txtLaptopDate.Text != "")
            LaptopDate = DateTime.ParseExact(txtLaptopDate.Text, "MM/dd/yyyy", CultureInfo.CurrentCulture);
        else
            LaptopDate = Convert.ToDateTime("01/01/1900");
        //Laptop date end

        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@EmployeeID", m_EmployeeID),
                                    new SqlParameter("@EmploymentType", EmploymentType),
                                    new SqlParameter("@Title", Server.HtmlEncode(txtTitle.Text)),
                                    new SqlParameter("@StartDate", StartDate),
                                    //Laptop Date start
                                    new SqlParameter("@LaptopDate", LaptopDate),
                                    //Laptop Date end
                                    new SqlParameter("@Department", Department),                                    
                                    //new SqlParameter("@ProposedConsProject", Server.HtmlEncode(txtProposedConsulting.Text)),                                    
                                    new SqlParameter("@Location", Server.HtmlEncode(txtLocation.Text)),
                                    new SqlParameter("@PCEquipment", CC.CheckBoxValue(cbPcEquipment)),
                                    new SqlParameter("@SpecialSoftware", Server.HtmlEncode(txtSpecialSW.Text)),
                                    new SqlParameter("@AdditionalAccess", Server.HtmlEncode(txtAddAccess.Text)),
                                    
                                    new SqlParameter("@LaptopShipAddress", CC.CheckBoxValue(cbShipAddress)),
                                    new SqlParameter("@OtherLocation", Server.HtmlEncode(txtOtherLocation.Text)),
                                    new SqlParameter("@SalesforceLogin", CC.CheckBoxValue(cbSalesforceLogin)),
                                    new SqlParameter("@GTM", CC.CheckBoxValue(cbGTM)),
                                    new SqlParameter("@PPsalesCall", CC.CheckBoxValue(cbPPsalesCall)),
                                    new SqlParameter("@NC_Operation", CC.CheckBoxValue(cbOperations)),
                                    //new SqlParameter("@NC_Sales", CC.CheckBoxValue(cbSales)),
                                    //new SqlParameter("@NC_HSG", CC.CheckBoxValue(cbHSG)),
                                    new SqlParameter("@RoleType", RoleType),

                                    //new field added 190814
                                    new SqlParameter("@AllHands", CC.CheckBoxValue(cbAllHands)),
                                    new SqlParameter("@IsManager", Server.HtmlEncode(txtManager.Text)),

                                    new SqlParameter("@FixMode", false),
                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditEmployeeClassification", sqlparam);
            LblMsg.Text = "Record was updated successfully";
            MsgDiv.Visible = true;
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("employeeclassification.aspx", "btnSave_Click", ex.Message);
            LblMsg.Text = "Oops! Server problem....try after some time";
            MsgDiv.Visible = true;
        }
        finally { con.Close(); }
    }

    protected void btnSaveSubmit_Click(object sender, EventArgs e)
    {
        string EmploymentType = string.Empty;
        string Department = string.Empty;
        string RoleType = string.Empty;

        if (ddlEmployementType.SelectedIndex != 0)
        {
            EmploymentType = ddlEmployementType.SelectedItem.ToString();
        }
        if (ddlDepartment.SelectedIndex != 0)
        {
            Department = ddlDepartment.SelectedValue;
        }
        if (ddlRoleType.SelectedIndex != 0)
        {
            RoleType = ddlRoleType.SelectedItem.ToString();
        }

        DateTime StartDate;
        if (txtStartDate.Text != "")
            StartDate = DateTime.ParseExact(txtStartDate.Text, "MM/dd/yyyy", CultureInfo.CurrentCulture);
        else
            StartDate = Convert.ToDateTime("01/01/1900");
        //Laptop date start
        DateTime LaptopDate;
        if (txtLaptopDate.Text != "")
            LaptopDate = DateTime.ParseExact(txtLaptopDate.Text, "MM/dd/yyyy", CultureInfo.CurrentCulture);
        else
            LaptopDate = Convert.ToDateTime("01/01/1900");
        //Laptop date end

        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@EmployeeID", m_EmployeeID),
                                    new SqlParameter("@EmploymentType", EmploymentType),
                                    new SqlParameter("@Title", Server.HtmlEncode(txtTitle.Text)),
                                    new SqlParameter("@StartDate", StartDate),
                                    //Laptop Date start
                                    new SqlParameter("@LaptopDate", LaptopDate),
                                    //Laptop Date end
                                    new SqlParameter("@Department", Department),                                    
                                    //new SqlParameter("@ProposedConsProject", Server.HtmlEncode(txtProposedConsulting.Text)),                                    
                                    new SqlParameter("@Location", Server.HtmlEncode(txtLocation.Text)),
                                    new SqlParameter("@PCEquipment", CC.CheckBoxValue(cbPcEquipment)),
                                    new SqlParameter("@SpecialSoftware", Server.HtmlEncode(txtSpecialSW.Text)),
                                    new SqlParameter("@AdditionalAccess", Server.HtmlEncode(txtAddAccess.Text)),
                                    
                                    new SqlParameter("@LaptopShipAddress", CC.CheckBoxValue(cbShipAddress)),
                                    new SqlParameter("@OtherLocation", Server.HtmlEncode(txtOtherLocation.Text)),
                                    new SqlParameter("@SalesforceLogin", CC.CheckBoxValue(cbSalesforceLogin)),
                                    new SqlParameter("@GTM", CC.CheckBoxValue(cbGTM)),
                                    new SqlParameter("@PPsalesCall", CC.CheckBoxValue(cbPPsalesCall)),
                                    new SqlParameter("@NC_Operation", CC.CheckBoxValue(cbOperations)),
                                    //new SqlParameter("@NC_Sales", CC.CheckBoxValue(cbSales)),
                                    //new SqlParameter("@NC_HSG", CC.CheckBoxValue(cbHSG)),
                                    new SqlParameter("@RoleType", RoleType),

                                     //new field added 190814
                                    new SqlParameter("@AllHands", CC.CheckBoxValue(cbAllHands)),
                                    new SqlParameter("@IsManager", Server.HtmlEncode(txtManager.Text)),

                                    new SqlParameter("@FixMode", 1),
                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditEmployeeClassification", sqlparam);
            LblMsg.Text = "Record was updated successfully";
            MsgDiv.Visible = true;
            AlertMails();
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("employeeclassification.aspx", "btnSave_Click", ex.Message);
            LblMsg.Text = "Oops! Server problem....try after some time";
            MsgDiv.Visible = true;
        }
        finally { con.Close(); }
    }

    private int IsSecurityFix()
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetMeetingDetails", sqlparam).Tables[0];
            if (odt.Rows.Count > 0)
            {
                if (odt.Rows[0]["FixMode"].ToString().ToLower() == "true")
                {
                    return 1;
                    //LblMsg.Text = "The security process has already been completed for this employee, changing the department will NOT reset the meetings invitations. Please contact security directly.";
                }
                else
                {
                    return 0;
                }
            }
            else
            { return 0; }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("employeeclassification.aspx", "IsSecurityFix", ex.Message);
            return 0;
        }
        finally { con.Close(); }
    }

    private void AlertMails()
    {
        string AbsoluteUri = string.Empty;
        string CurrentFilePath = string.Empty;
        string QueryString = string.Empty;
        string EmployeeName = string.Empty;

        //oMailSender
        DataTable odt = new DataTable();
        DataTable odt1 = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            AbsoluteUri = Request.Url.AbsoluteUri.ToString();
            CurrentFilePath = Request.AppRelativeCurrentExecutionFilePath.ToString();
            CurrentFilePath = CurrentFilePath.Remove(0, 2);
            QueryString = Request.QueryString.ToString();
            AbsoluteUri = AbsoluteUri.Replace(CurrentFilePath + "?" + QueryString, "");
            AbsoluteUri = AbsoluteUri + "loginpage.aspx?";

            bool IsResourceFromIndia = false;
            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt1 = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetEmployeeDetails", sqlparam).Tables[0];
            if (odt1.Rows.Count > 0)
            {
                //////////// Modified on 070115 for sending emails alert to India users in case of Indian resource
                if (odt1.Rows[0]["Country"].ToString().ToLower() == "india")
                {
                    //return; 
                    IsResourceFromIndia = true;
                }
                EmployeeName = odt1.Rows[0]["FirstName"].ToString() + " " + odt1.Rows[0]["LastName"].ToString();//StartDate
            }
            else
            { return; }

            string query = string.Empty;
            //////////// Modified on 09 Oct, 2015 for adding stored procedure for allowing all user alert Start.
            ////////////// Modified on 070115 for sending emails alert to India users in case of Indian resource statt
            ////query = "Select * from Users where Role not in ('admin', 'hr')";

            //if (IsResourceFromIndia == false)
            //{
            //    query = "Select * from Users where Role not in ('System Admin', 'hr') and ISNULL(Country, '') <> 'India'";
            //}
            //else
            //{
            //    query = "Select * from Users where Role not in ('System Admin', 'hr') and ISNULL(Country, '') = 'India'";
            //}

            //odt = SqlHelper.ExecuteDataset(con, CommandType.Text, query).Tables[0];

            int IsIndia = 0;
            if (IsResourceFromIndia == false)
            { IsIndia = 0; }
            else
            { IsIndia = 1; }

            SqlParameter[] sqlparams = new SqlParameter[]{
                                        new SqlParameter("@Country", "India"),
                                        new SqlParameter("@IsResourceFromIndia", IsIndia)
            };
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetUserListForClassificationAlert", sqlparams).Tables[0];

            ////////////// Modified on 070115 for sending emails alert to India users in case of Indian resource end
            //////////// Modified on 09 Oct, 2015 for adding stored procedure for allowing all user alert end.

            if (odt.Rows.Count > 0)
            {
                for (int i = 0; i < odt.Rows.Count; i++)
                {
                    SendMail(odt.Rows[i]["UserName"].ToString(), odt.Rows[i]["Role"].ToString(), AbsoluteUri, odt.Rows[i]["FirstName"].ToString() + " " + odt.Rows[i]["LastName"].ToString(), EmployeeName);
                }
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("employeeclassification.aspx", "AlertMails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    private void SendMail(string UserID, string Role, string URLPath, string name, string emplyeename)
    {
        string subject = string.Empty;
        string body = string.Empty;

        //subject = "<p style='font-size:10pt;font-family:Arial;'>New employee " + emplyeename + " OnBoarding</p>";
        subject = "New employee " + emplyeename + " OnBoarding";

        //body = name + ",<br />";
        body = "<p style='font-size:10pt;font-family:Arial;'>";
        body += name + ",<br />";

        body += "<br />";
        body += emplyeename + " is due to start on " + DateTime.ParseExact(txtStartDate.Text, "MM/dd/yyyy", CultureInfo.CurrentCulture).ToShortDateString() + ".<br />";
        body += "Please update/complete all " + Role + " responsibilities to ensure a smooth onboarding for the resource.<br />";
        body += "<br />";

        List<string> roleList = new List<string>();
        roleList = Role.Split(',').ToList();
        foreach (string _Role in roleList)
        {
            if (Role.ToLower() == "hr")
            {
                //body += "URL: " + URLPath + "module=" + " <br />";
            }
            else if (Role.ToLower() == "it")
            {
                body += "Click Here to get started: " + URLPath + "module=informationtechnology.aspx&EmployeeID=" + m_EmployeeID + " <br />";
            }
            else if (Role.ToLower() == "administrative")
            {
                body += "Click Here to get started: " + URLPath + "module=administrative.aspx&EmployeeID=" + m_EmployeeID + " <br />";
            }
            else if (Server.HtmlDecode(_Role.Trim().ToLower()) == "sales & marketing")
            {
                body += "Click Here to get started: " + URLPath + "module=marketing.aspx&EmployeeID=" + m_EmployeeID + " <br />";
            }
            else if (Role.ToLower() == "security")
            {
                body += "Click Here to get started: " + URLPath + "module=security.aspx&EmployeeID=" + m_EmployeeID + " <br />";
            }
            else if (Role.ToLower() == "payroll")
            {
                body += "Click Here to get started: " + URLPath + "module=payroll.aspx&EmployeeID=" + m_EmployeeID + " <br />";
            }
            else if (Role.ToLower() == "meeting")
            {
                body += "Click Here to get started: " + URLPath + "module=Meeting.aspx&EmployeeID=" + m_EmployeeID + " <br />";
            }
        }
        //if (Role.ToLower() == "hr")
        //{
        //    //body += "URL: " + URLPath + "module=" + " <br />";
        //}
        //else if (Role.ToLower() == "it")
        //{
        //    body += "Click Here to get started: " + URLPath + "module=informationtechnology.aspx&EmployeeID=" + m_EmployeeID + " <br />";
        //}
        //else if (Role.ToLower() == "administrative")
        //{
        //    body += "Click Here to get started: " + URLPath + "module=administrative.aspx&EmployeeID=" + m_EmployeeID + " <br />";
        //}
        //else if (Role.ToLower() == "security")
        //{
        //    body += "Click Here to get started: " + URLPath + "module=security.aspx&EmployeeID=" + m_EmployeeID + " <br />";
        //}
        //else if (Role.ToLower() == "payroll")
        //{
        //    body += "Click Here to get started: " + URLPath + "module=payroll.aspx&EmployeeID=" + m_EmployeeID + " <br />";
        //}
        //else if (Role.ToLower() == "meeting")
        //{
        //    body += "Click Here to get started: " + URLPath + "module=Meeting.aspx&EmployeeID=" + m_EmployeeID + " <br />";
        //}

        body += "<br />";
        body += "Thanks and Regards<br />";
        //body += "<br />";
        body += ConfigurationManager.AppSettings["HRName"].ToString() + "<br />";
        //body += "Director of Human Resources<br />";
        //body += "214-696-6410<br />";
        body += ConfigurationManager.AppSettings["HRContact"].ToString() + "<br />";
        body += "</p>";
        //////////////oMailSender.SendMailMessage("from", "to", "bcc", "cc", "subject", "body");
        oMailSender.SendMailMessage(Session["UserName"].ToString(), UserID, "", "", subject, body);
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Reset();
    }
}
