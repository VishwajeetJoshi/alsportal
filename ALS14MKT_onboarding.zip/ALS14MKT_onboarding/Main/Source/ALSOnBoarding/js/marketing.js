﻿function CheckAllFieldsVaule(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesBIOUpload");
    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmBIOUpload");
    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesPressRelease");
    var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmPressRelease");
    var cb5 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesImportSF");
    var cb6 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmImportSF");

    var cb7 = document.getElementById("ctl00_ContentPlaceHolder1_cbDeclinedBIOUpload");
    var cb8 = document.getElementById("ctl00_ContentPlaceHolder1_cbDeclinedPressRelease");
    var cb9 = document.getElementById("ctl00_ContentPlaceHolder1_cbDeclinedImportSF");

//    var cb10 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesPhotoUploaded");
//    var cb11 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmPhotoUploaded");
//    var cb12 = document.getElementById("ctl00_ContentPlaceHolder1_cbDeclinedPhotoUploaded");
    var cb13 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesMarketingOverview");
    var cb14 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmMarketingOverview");
    var cb15 = document.getElementById("ctl00_ContentPlaceHolder1_cbDeclinedMarketingOverview");
    var cb16 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesLinkedinProfile");
    var cb17 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmLinkedinProfile");
    var cb18 = document.getElementById("ctl00_ContentPlaceHolder1_cbDeclinedLinkedinProfile");


    if (cb1.checked == false && cb2.checked == false && cb3.checked == false && cb4.checked == false &&
        cb5.checked == false && cb6.checked == false && cb7.checked == false && cb8.checked == false && 
        cb9.checked == false &&  
        cb13.checked == false && cb14.checked == false && cb15.checked == false && cb16.checked == false &&
        cb17.checked == false && cb18.checked == false) {
        args.IsValid = false;
    }
    else {
        args.IsValid = true;
    }
}

function CheckConfirmbyMe(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmbyMe");
    if (cb1.checked == false)
        args.IsValid = false;
    else
        args.IsValid = true;
}

function enabledisableconfirm(checkboxid) {
    var confirmcheckboxid;

        confirmcheckboxid = checkboxid.id.replace("Yes", "Confirm");

    if (checkboxid.checked == true) {

        document.getElementById(confirmcheckboxid).disabled = false;
    }
    else {
        if (document.getElementById(confirmcheckboxid).isContentEditable == false) {
            try {
                document.getElementById(confirmcheckboxid).isContentEditable = true;
            }
            catch (e) { }
            document.getElementById(confirmcheckboxid).checked = false;
            document.getElementById(confirmcheckboxid).disabled = true;
        }
        else {
            document.getElementById(confirmcheckboxid).checked = false;
            document.getElementById(confirmcheckboxid).disabled = true;
        }        
    }
}

////For Sales

function CheckAllFieldsVauleSales(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSalesforceTraining");
    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmSalesforceTraining");
    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbDeclinedSalesforceTraining");
    //var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesWikiTraining");
    //var cb5 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmWikiTraining");    
    //var cb6 = document.getElementById("ctl00_ContentPlaceHolder1_cbDeclinedWikiTraining");
    var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSalesSupportTraining");
    var cb5 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmSalesSupportTraining");
    var cb6 = document.getElementById("ctl00_ContentPlaceHolder1_cbDeclinedSalesSupportTraining");
    var cb7 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSolutionsDevOverview");
    var cb8 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmSolutionsDevOverview");
    var cb9 = document.getElementById("ctl00_ContentPlaceHolder1_cbDeclinedSolutionsDevOverview");

    if (cb1.checked == false && cb2.checked == false && cb3.checked == false && 
        cb4.checked == false && cb5.checked == false && cb6.checked == false &&
        cb7.checked == false && cb8.checked == false && cb9.checked == false) {
        args.IsValid = false;
    }
    else {
        args.IsValid = true;
    }
}

function CheckConfirmbyMeSales(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmbyMeSales");
    if (cb1.checked == false)
        args.IsValid = false;
    else
        args.IsValid = true;
}

