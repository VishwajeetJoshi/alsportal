﻿function CheckMandatory(source, args) {
    var txt1 = document.getElementById("ctl00_ContentPlaceHolder1_txtLastDay");
    var txt2 = document.getElementById("ctl00_ContentPlaceHolder1_txtSeparationDate");
//    var txt3 = document.getElementById("ctl00_ContentPlaceHolder1_txtForwardEmailAddress");
    var ddl1 = document.getElementById("ctl00_ContentPlaceHolder1_ddlDismissal");

    if (txt1.value == "") {
        args.IsValid = false;
    }
    else if (txt2.value == "") {
        args.IsValid = false;
    }
//    else if (txt3.value == "") {
//        args.IsValid = false;
//    } 
    else if (ddl1.options[ddl1.selectedIndex].value == "0") {
        args.IsValid = false;
    }
    else {
        args.IsValid = true;
    }
}


function CheckConfirmbyMe(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmbyMe");
    if (cb1.checked == false)
        args.IsValid = false;
    else
        args.IsValid = true;
}

function checkdate(input) {
    var validformat = /^\d{2}\/\d{2}\/\d{4}$/ //Basic check for format validity
    var returnval = false
    if (input.value == "") {
        returnval = true
    }
    else {
        if (!validformat.test(input.value))
            alert("Invalid Date Format. Please correct and submit again.")
        else { //Detailed check for valid date ranges
            var monthfield = input.value.split("/")[0]
            var dayfield = input.value.split("/")[1]
            var yearfield = input.value.split("/")[2]
            var dayobj = new Date(yearfield, monthfield - 1, dayfield)
            if ((dayobj.getDate() != dayfield) || (dayobj.getMonth() + 1 != monthfield) || (dayobj.getFullYear() != yearfield))
                alert("Invalid Day, Month, or Year range detected. Please correct date format (MM/DD/YYYY)")
            else
                returnval = true
        }
        if (returnval == false)
        //input.select()
            setTimeout(function() { document.getElementById(input.id).focus(); }, 1);
        return returnval
    }
}