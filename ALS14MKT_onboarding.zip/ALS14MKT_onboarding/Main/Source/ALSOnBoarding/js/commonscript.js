﻿

function alertuserfordelete() {
    var revtal;
    revtal = confirm("Are you sure?");
    if (revtal == true)
        return true;
    else
        return false;
}