﻿function CheckAllFieldsVaule(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbBioWebsite");

    if (cb1.checked == false) {
        args.IsValid = false;
    }
    else {
        args.IsValid = true;
    }
}



function CheckConfirmbyMe(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmbyMe");
    if (cb1.checked == false)
        args.IsValid = false;
    else
        args.IsValid = true;
}
