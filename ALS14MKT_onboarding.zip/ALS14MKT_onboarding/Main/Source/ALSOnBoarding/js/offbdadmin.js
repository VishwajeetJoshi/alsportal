﻿function CheckAllFieldsVaule(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbKeyFob");
    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbKeyCard");
    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbAlarmCode");
    var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbTravelAccess");
    var cb5 = document.getElementById("ctl00_ContentPlaceHolder1_cbDisableFedExKinkos");
    //var cb6 = document.getElementById("ctl00_ContentPlaceHolder1_cbRemoveNING");

    if (cb1.checked == false && cb2.checked == false && cb3.checked == false && cb4.checked == false &&
        cb5.checked == false) {
        args.IsValid = false;
    }
    else {
        args.IsValid = true;
    }
}



function CheckConfirmbyMe(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmbyMe");
    if (cb1.checked == false)
        args.IsValid = false;
    else
        args.IsValid = true;
}
