﻿function CheckAllFieldsVaule(source, args) {
//    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesBCards");
//    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmBCards");
    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesBCardOrdered");
    var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmBCardOrdered");
    var cb5 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesBCQty");
//    var cb6 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesBCconfirmedByHR");
//    var cb7 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmBCconfirmedByHR");
    var cb8 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesOrbitz");
    var cb9 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmOrbitz");
    var cb10 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesFedEx");
    var cb11 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmFedEx");
    var cb12 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesOutsourcingLeadership");
    var cb13 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmOutsourcingLeadership");
//    var cb14 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesNING");
//    var cb15 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmNING");
    var cb16 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesAdministrationEmail");
    var cb17 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmAdministrationEmail");
//    var cb18 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesOutsourcingCenter");
//    var cb19 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmOutsourcingCenter");

    var cb20 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesOffSpaceAllocation");
    var cb21 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmOffSpaceAllocation");
    
    //New added fields on 250814
    var cb22 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesIndiaLaptopPhonePro");
    var cb23 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmIndiaLaptopPhonePro");
    var cb24 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesIndiaIDCard");
    var cb25 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmIndiaIDCard");
    var cb26 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesIndiaJoiningKit");
    var cb27 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmIndiaJoiningKit");
    
    var ddl1 = document.getElementById("ctl00_ContentPlaceHolder1_ddlConfirmBCQty");
    //confirm("Test Message");
    if (cb3.checked == false && cb4.checked == false
     && cb5.checked == false && cb8.checked == false
     && cb9.checked == false && cb10.checked == false 
     && cb11.checked == false && cb12.checked == false
     && cb13.checked == false && cb16.checked == false
     && cb17.checked == false && cb20.checked == false
     && cb21.checked == false && cb22.checked == false
     && cb23.checked == false && cb24.checked == false
     && cb25.checked == false && cb26.checked == false
     && cb27.checked == false && ddl1.options[ddl1.selectedIndex].value == "0") {
        args.IsValid = false;
    }
    else {
        args.IsValid = true;
    }
}

function CheckConfirmbyMe(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmbyMe");
    if (cb1.checked == false)
        args.IsValid = false;
    else
        args.IsValid = true;
}

function disbaleconfirmcheckboxes() {
//    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesBCards");
//    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmBCards");
    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesBCardOrdered");
    var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmBCardOrdered");
    var cb5 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesBCQty");
//    var cb7 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesBCconfirmedByHR");
//    var cb8 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmBCconfirmedByHR");
    var cb9 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesOrbitz");
    var cb10 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmOrbitz");
    var cb11 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesFedEx");
    var cb12 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmFedEx");
    var cb13 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesOutsourcingLeadership");
    var cb14 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmOutsourcingLeadership");
//    var cb15 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesNING");
//    var cb16 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmNING");
    var cb17 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesAdministrationEmail");
    var cb18 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmAdministrationEmail");
//    var cb19 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesOutsourcingCenter");
//    var cb20 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmOutsourcingCenter");

    var cb21 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesOffSpaceAllocation");
    var cb22 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmOffSpaceAllocation");
    
    var ddl6 = document.getElementById("ctl00_ContentPlaceHolder1_ddlConfirmBCQty");

    //New added fields on 250814
    var cb23 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesIndiaLaptopPhonePro");
    var cb24 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmIndiaLaptopPhonePro");
    var cb25 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesIndiaIDCard");
    var cb26 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmIndiaIDCard");
    var cb27 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesIndiaJoiningKit");
    var cb28 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmIndiaJoiningKit");
    
//    if (cb1.checked == false) {
//        document.getElementById(cb2.id).disabled = true;
//    }
    if (cb3.checked == false) {
        document.getElementById(cb4.id).disabled = true;
    }
    if (cb5.checked == false) {
        document.getElementById(ddl6.id).disabled = true;
    }
//    if (cb7.checked == false) {
//        document.getElementById(cb8.id).disabled = true;
//    }
    if (cb9.checked == false) {
        document.getElementById(cb10.id).disabled = true;
    }
    if (cb11.checked == false) {
        document.getElementById(cb12.id).disabled = true;
    }
    if (cb13.checked == false) {
        document.getElementById(cb14.id).disabled = true;
    }
//    if (cb15.checked == false) {
//        document.getElementById(cb16.id).disabled = true;
//    }
    if (cb17.checked == false) {
        document.getElementById(cb18.id).disabled = true;
    }
//    if (cb19.checked == false) {
//        document.getElementById(cb20.id).disabled = true;
//    }
    if (cb21.checked == false) {
        document.getElementById(cb22.id).disabled = true;
    }
    if (cb23.checked == false) {
        document.getElementById(cb24.id).disabled = true;
    }
    if (cb25.checked == false) {
        document.getElementById(cb26.id).disabled = true;
    }
    if (cb27.checked == false) {
        document.getElementById(cb28.id).disabled = true;
    }
}

function enabledisableconfirm(checkboxid) {
    var confirmcheckboxid;
    if (checkboxid.id.indexOf("cbYesBCQty") != -1)
        confirmcheckboxid = checkboxid.id.replace("cbYesBCQty", "ddlConfirmBCQty");
    else
        confirmcheckboxid = checkboxid.id.replace("Yes", "Confirm");

    if (checkboxid.checked == true) {

        document.getElementById(confirmcheckboxid).disabled = false;
    }
    else {
        if (document.getElementById(confirmcheckboxid).isContentEditable == false) {
            try {
                document.getElementById(confirmcheckboxid).isContentEditable = true;
            }
            catch (e) { }
            document.getElementById(confirmcheckboxid).checked = false;
            document.getElementById(confirmcheckboxid).disabled = true;
        }
        else {
            document.getElementById(confirmcheckboxid).checked = false;
            document.getElementById(confirmcheckboxid).disabled = true;
        }
        //        document.getElementById(confirmcheckboxid).isContentEditable = true;
        //        document.getElementById(confirmcheckboxid).checked = false;
        //        document.getElementById(confirmcheckboxid).disabled = true;
    }
}


function CheckYesConfirmFieldsVaule(source, args) {
    var flag = true;
//    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesBCards");
//    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmBCards");
    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesBCardOrdered");
    var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmBCardOrdered");
    var cb5 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesBCQty");
//    var cb7 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesBCconfirmedByHR");
//    var cb8 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmBCconfirmedByHR");
    var cb9 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesOrbitz");
    var cb10 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmOrbitz");
    var cb11 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesFedEx");
    var cb12 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmFedEx");
    var cb13 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesOutsourcingLeadership");
    var cb14 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmOutsourcingLeadership");
//    var cb15 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesNING");
//    var cb16 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmNING");
    var cb17 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesAdministrationEmail");
    var cb18 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmAdministrationEmail");
//    var cb19 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesOutsourcingCenter");
//    var cb20 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmOutsourcingCenter");

    var cb21 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesOffSpaceAllocation");
    var cb22 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmOffSpaceAllocation");

    var ddl6 = document.getElementById("ctl00_ContentPlaceHolder1_ddlConfirmBCQty");

    //New added fields on 250814
    var cb23 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesIndiaLaptopPhonePro");
    var cb24 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmIndiaLaptopPhonePro");
    var cb25 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesIndiaIDCard");
    var cb26 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmIndiaIDCard");
    var cb27 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesIndiaJoiningKit");
    var cb28 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmIndiaJoiningKit");

//    if (cb1.checked == true) {
//        if (cb2.checked == false) {
//            flag = false;
//        }
//    }
    if (cb3.checked == true) {
        if (cb4.checked == false) {
            flag = false;
        }
    }
    if (cb5.checked == true) {
        if (ddl6.options[ddl6.selectedIndex].value == "0") {
            flag = false;
        }
    }
//    if (cb7.checked == true) {
//        if (cb8.checked == false) {
//            flag = false;
//        }
//    }
    if (cb9.checked == true) {
        if (cb10.checked == false) {
            flag = false;
        }
    }
    if (cb11.checked == true) {
        if (cb12.checked == false) {
            flag = false;
        }
    }
    if (cb13.checked == true) {
        if (cb14.checked == false) {
            flag = false;
        }
    }
//    if (cb15.checked == true) {
//        if (cb16.checked == false) {
//            flag = false;
//        }
//    }
    if (cb17.checked == true) {
        if (cb18.checked == false) {
            flag = false;
        }
    }
//    if (cb19.checked == true) {
//        if (cb20.checked == false) {
//            flag = false;
//        }
//    }
    if (cb21.checked == true) {
        if (cb22.checked == false) {
            flag = false;
        }
    }

    if (cb23.checked == true) {
        if (cb24.checked == false) {
            flag = false;
        }
    }
    if (cb25.checked == true) {
        if (cb26.checked == false) {
            flag = false;
        }
    }
    if (cb27.checked == true) {
        if (cb28.checked == false) {
            flag = false;
        }
    }    

    if (flag == false)
        args.IsValid = false;
    else
        args.IsValid = true;
}
