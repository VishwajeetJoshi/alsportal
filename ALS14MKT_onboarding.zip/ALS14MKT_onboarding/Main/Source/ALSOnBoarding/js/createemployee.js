﻿//<!-- This script is based on the javascript code of Roman Feldblum (web.developer@programmer.net) -->
//<!-- Original script : http://javascript.internet.com/forms/format-phone-number.html -->
//<!-- Original script is revised by Eralper Yilmaz (http://www.eralper.com) -->
//<!-- Revised script : http://www.kodyaz.com -->

var zChar = new Array(' ', '-', '-', '.');
var maxphonelength = 12;
var phonevalue1;
var phonevalue2;
var cursorposition;

function ParseForNumber1(object) {
    phonevalue1 = ParseChar(object.value, zChar);
}
function ParseForNumber2(object) {
    phonevalue2 = ParseChar(object.value, zChar);
}

function backspacerUP(object, e) {
    if (e) {
        e = e
    } else {
        e = window.event
    }
    if (e.which) {
        var keycode = e.which
    } else {
        var keycode = e.keyCode
    }

    ParseForNumber1(object)

    if (keycode >= 48) {
        ValidatePhone(object)
    }
}

function backspacerDOWN(object, e) {
    if (e) {
        e = e
    } else {
        e = window.event
    }
    if (e.which) {
        var keycode = e.which
    } else {
        var keycode = e.keyCode
    }
    ParseForNumber2(object)
}

function GetCursorPosition() {

    var t1 = phonevalue1;
    var t2 = phonevalue2;
    var bool = false
    for (i = 0; i < t1.length; i++) {
        if (t1.substring(i, 1) != t2.substring(i, 1)) {
            if (!bool) {
                cursorposition = i
                bool = true
            }
        }
    }
}

function ValidatePhone(object) {

    var p = phonevalue1

    p = p.replace(/[^\d]*/gi, "")

    if (p.length < 3) {
        object.value = p
    } else if (p.length == 3) {
        pp = p;
        d4 = p.indexOf('-')
        d5 = p.indexOf('-')
        if (d4 == -1) {
            pp = pp;
        }
        if (d5 == -1) {
            pp = pp + "-";
        }
        object.value = pp;
    } else if (p.length > 3 && p.length < 6) {
        p = p;
        l30 = p.length;
        p30 = p.substring(0, 3);
        p30 = p30 + "-"

        p31 = p.substring(3, l30);
        pp = p30 + p31;

        object.value = pp;

    } else if (p.length >= 6) {
        p = p;
        l30 = p.length;
        p30 = p.substring(0, 3);
        p30 = p30 + "-"
        //        if (l30 == 7)
        //            l30 = l30 - 1;
        p31 = p.substring(3, l30);
        pp = p30 + p31;

        l40 = pp.length;
        p40 = pp.substring(0, 7);
        p40 = p40 + "-"

        p41 = pp.substring(7, l40);
        ppp = p40 + p41;

        object.value = ppp.substring(0, maxphonelength);
    }

    GetCursorPosition()

    if (cursorposition >= 0) {
        if (cursorposition == 0) {
            cursorposition = 2
        } else if (cursorposition <= 2) {
            cursorposition = cursorposition + 1
        } else if (cursorposition <= 5) {
            cursorposition = cursorposition + 2
        } else if (cursorposition == 6) {
            cursorposition = cursorposition + 2
        } else if (cursorposition == 7) {
            cursorposition = cursorposition + 4
            e1 = object.value.indexOf(')')
            e2 = object.value.indexOf('-')
            if (e1 > -1 && e2 > -1) {
                if (e2 - e1 == 4) {
                    cursorposition = cursorposition - 1
                }
            }
        } else if (cursorposition < 11) {
            cursorposition = cursorposition + 3
        } else if (cursorposition == 11) {
            cursorposition = cursorposition + 1
        } else if (cursorposition >= 12) {
            cursorposition = cursorposition
        }

        var txtRange = object.createTextRange();
        txtRange.moveStart("character", cursorposition);
        txtRange.moveEnd("character", cursorposition - object.value.length);
        txtRange.select();
    }

}

function ParseChar(sStr, sChar) {
    if (sChar.length == null) {
        zChar = new Array(sChar);
    }
    else zChar = sChar;

    for (i = 0; i < zChar.length; i++) {
        sNewStr = "";

        var iStart = 0;
        var iEnd = sStr.indexOf(sChar[i]);

        while (iEnd != -1) {
            sNewStr += sStr.substring(iStart, iEnd);
            iStart = iEnd + 1;
            iEnd = sStr.indexOf(sChar[i], iStart);
        }
        sNewStr += sStr.substring(sStr.lastIndexOf(sChar[i]) + 1, sStr.length);

        sStr = sNewStr;
    }

    return sNewStr;
}

function echeck() {
    //TBUserName
    var str = document.getElementById("ctl00_ContentPlaceHolder1_txtPerEmailId").value;
    if (str == "") {
        return true;
    }
    var at = "@"
    var dot = "."
    var lat = str.indexOf(at)
    var lstr = str.length
    var ldot = str.indexOf(dot)
    if (str.indexOf(at) == -1) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtPerEmailId").focus(); }, 1);
        return false;
    }

    if (str.indexOf(at) == -1 || str.indexOf(at) == 0 || str.indexOf(at) == lstr) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtPerEmailId").focus(); }, 1);
        return false;
    }

    if (str.indexOf(dot) == -1 || str.indexOf(dot) == 0 || str.indexOf(dot) == lstr) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtPerEmailId").focus(); }, 1);
        return false;
    }

    if (str.indexOf(at, (lat + 1)) != -1) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtPerEmailId").focus(); }, 1);
        return false;
    }

    if (str.substring(lat - 1, lat) == dot || str.substring(lat + 1, lat + 2) == dot) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtPerEmailId").focus(); }, 1);
        return false;
    }

    if (str.indexOf(dot, (lat + 2)) == -1) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtPerEmailId").focus(); }, 1);
        return false;
    }

    if (str.indexOf(" ") != -1) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtPerEmailId").focus(); }, 1);
        return false;
    }

    return true;
}


function reset() {
    document.getElementById("ctl00_ContentPlaceHolder1_txtLastName").innertext = "";
    document.getElementById("ctl00_ContentPlaceHolder1_txtFirstName").value = "";
    document.getElementById("ctl00_ContentPlaceHolder1_txtMiddleInitial").value = "";
    document.getElementById("ctl00_ContentPlaceHolder1_txtStreet").value = "";
    document.getElementById("ctl00_ContentPlaceHolder1_txtAptUnit").value = "";
    document.getElementById("ctl00_ContentPlaceHolder1_txtCity").value = "";

    var e = document.getElementById("ctl00_ContentPlaceHolder1_ddlState");
    e.options[e.selectedIndex].value == "0";

    document.getElementById("ctl00_ContentPlaceHolder1_txtZip").value = "";
    document.getElementById("ctl00_ContentPlaceHolder1_txtHomePhone").value = "";
    document.getElementById("ctl00_ContentPlaceHolder1_txtCellPhone").value = "";
    document.getElementById("ctl00_ContentPlaceHolder1_txtBusinessCard").value = "";
    document.getElementById("ctl00_ContentPlaceHolder1_txtCoEmailId").value = "";
    document.getElementById("ctl00_ContentPlaceHolder1_txtPerEmailId").value = "";
    document.getElementById("ctl00_ContentPlaceHolder1_txtRefLastName").value = "";
    document.getElementById("ctl00_ContentPlaceHolder1_txtRefFirstName").value = "";
    document.getElementById("ctl00_ContentPlaceHolder1_txtRefMiddleInitial").value = "";
    document.getElementById("ctl00_ContentPlaceHolder1_txtRefStreet").value = "";
    document.getElementById("ctl00_ContentPlaceHolder1_txtRefAptUnit").value = "";
    document.getElementById("ctl00_ContentPlaceHolder1_txtRefCity").value = "";

    var e = document.getElementById("ctl00_ContentPlaceHolder1_ddlRefState");
    e.options[e.selectedIndex].value == "0";

    document.getElementById("ctl00_ContentPlaceHolder1_txtRefZip").value = "";
    document.getElementById("ctl00_ContentPlaceHolder1_txtRefPriPhone").value = "";
    document.getElementById("ctl00_ContentPlaceHolder1_txtRefAltPhone").value = "";
    document.getElementById("ctl00_ContentPlaceHolder1_txtRelationship").value = "";

}


//function echeck() {
//    //TBUserName
//    var str = document.getElementById("ContentPlaceHolder1_txtPerEmailId").value;
//    if (str == "") {
//        return true;
//    }
//    var at = "@"
//    var dot = "."
//    var lat = str.indexOf(at)
//    var lstr = str.length
//    var ldot = str.indexOf(dot)
//    if (str.indexOf(at) == -1) {
//        alert("Please add a valid user name eg: abc@abc.com");
//        setTimeout(function() { document.getElementById("ContentPlaceHolder1_txtPerEmailId").focus(); }, 1);
//        return false;
//    }

//    if (str.indexOf(at) == -1 || str.indexOf(at) == 0 || str.indexOf(at) == lstr) {
//        alert("Please add a valid user name eg: abc@abc.com");
//        setTimeout(function() { document.getElementById("ContentPlaceHolder1_txtPerEmailId").focus(); }, 1);
//        return false;
//    }

//    if (str.indexOf(dot) == -1 || str.indexOf(dot) == 0 || str.indexOf(dot) == lstr) {
//        alert("Please add a valid user name eg: abc@abc.com");
//        setTimeout(function() { document.getElementById("ContentPlaceHolder1_txtPerEmailId").focus(); }, 1);
//        return false;
//    }

//    if (str.indexOf(at, (lat + 1)) != -1) {
//        alert("Please add a valid user name eg: abc@abc.com");
//        setTimeout(function() { document.getElementById("ContentPlaceHolder1_txtPerEmailId").focus(); }, 1);
//        return false;
//    }

//    if (str.substring(lat - 1, lat) == dot || str.substring(lat + 1, lat + 2) == dot) {
//        alert("Please add a valid user name eg: abc@abc.com");
//        setTimeout(function() { document.getElementById("ContentPlaceHolder1_txtPerEmailId").focus(); }, 1);
//        return false;
//    }

//    if (str.indexOf(dot, (lat + 2)) == -1) {
//        alert("Please add a valid user name eg: abc@abc.com");
//        setTimeout(function() { document.getElementById("ContentPlaceHolder1_txtPerEmailId").focus(); }, 1);
//        return false;
//    }

//    if (str.indexOf(" ") != -1) {
//        alert("Please add a valid user name eg: abc@abc.com");
//        setTimeout(function() { document.getElementById("ContentPlaceHolder1_txtPerEmailId").focus(); }, 1);
//        return false;
//    }

//    return true;
//}


//function reset() {
//    document.getElementById("ContentPlaceHolder1_txtLastName").innertext = "";
//    document.getElementById("ContentPlaceHolder1_txtFirstName").value = "";
//    document.getElementById("ContentPlaceHolder1_txtMiddleInitial").value = "";
//    document.getElementById("ContentPlaceHolder1_txtStreet").value = "";
//    document.getElementById("ContentPlaceHolder1_txtAptUnit").value = "";
//    document.getElementById("ContentPlaceHolder1_txtCity").value = "";

//    var e = document.getElementById("ContentPlaceHolder1_ddlState");
//    e.options[e.selectedIndex].value == "0";

//    document.getElementById("ContentPlaceHolder1_txtZip").value = "";
//    document.getElementById("ContentPlaceHolder1_txtHomePhone").value = "";
//    document.getElementById("ContentPlaceHolder1_txtCellPhone").value = "";
//    document.getElementById("ContentPlaceHolder1_txtBusinessCard").value = "";
//    document.getElementById("ContentPlaceHolder1_txtCoEmailId").value = "";
//    document.getElementById("ContentPlaceHolder1_txtPerEmailId").value = "";
//    document.getElementById("ContentPlaceHolder1_txtRefLastName").value = "";
//    document.getElementById("ContentPlaceHolder1_txtRefFirstName").value = "";
//    document.getElementById("ContentPlaceHolder1_txtRefMiddleInitial").value = "";
//    document.getElementById("ContentPlaceHolder1_txtRefStreet").value = "";
//    document.getElementById("ContentPlaceHolder1_txtRefAptUnit").value = "";
//    document.getElementById("ContentPlaceHolder1_txtRefCity").value = "";

//    var e = document.getElementById("ContentPlaceHolder1_ddlRefState");
//    e.options[e.selectedIndex].value == "0";

//    document.getElementById("ContentPlaceHolder1_txtRefZip").value = "";
//    document.getElementById("ContentPlaceHolder1_txtRefPriPhone").value = "";
//    document.getElementById("ContentPlaceHolder1_txtRefAltPhone").value = "";
//    document.getElementById("ContentPlaceHolder1_txtRelationship").value = "";

//}