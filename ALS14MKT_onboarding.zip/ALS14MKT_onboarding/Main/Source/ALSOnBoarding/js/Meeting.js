﻿function CheckAllFieldsVaule(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesConsultingESP");
    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesConsultingPP");
    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesConsultingOP");
    //var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesVendorESP");
    //var cb5 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesVendorPP");

    //var cb7 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesNSG_OP");
    var cb8 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesHSG_OP");
    //var cb9 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesUS_UK_P");
    var cb10 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesWIPReview");
    var cb11 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesDealReview");
    var cb12 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesMonthlyProbCall");
    var cb13 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesWklEuropeUdt");
    var cb14 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesWklVendorCall");
    var cb15 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesWklHWSWCall");
    var cb16 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSDTeamMtg");
    var cb17 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSSTeamMtg");

    if (cb1.checked == false && cb2.checked == false && cb3.checked == false &&
        cb8.checked == false && cb10.checked == false && cb11.checked == false && cb12.checked == false &&
        cb13.checked == false && cb14.checked == false && cb15.checked == false && cb16.checked == false && cb17.checked == false) {
        args.IsValid = false;
    }
    else {
        args.IsValid = true;
    }
}

function CheckConfirmbyMe(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmbyMe");
    if (cb1.checked == false)
        args.IsValid = false;
    else
        args.IsValid = true;
}

function disbaleconfirmcheckboxes() {
    var cb9 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesConsultingESP");
    var cb10 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmConsultingESP");
    var cb11 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesConsultingPP");
    var cb12 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmConsultingPP");
    var cb13 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesConsultingOP");
    var cb14 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmConsultingOP");

    //var cb15 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesVendorESP");
    //var cb16 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmVendorESP");
    //var cb17 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesVendorPP");
    //var cb18 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmVendorPP");
    //var cb21 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesNSG_OP");
    //var cb22 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmNSG_OP");

    var cb23 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesHSG_OP");
    var cb24 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmHSG_OP");

    //var cb25 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesUS_UK_P");
    //var cb26 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmUS_UK_P");

    var cb27 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesWIPReview");
    var cb28 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmWIPReview");
    var cb29 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesDealReview");
    var cb30 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmDealReview");
    var cb31 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesMonthlyProbCall");
    var cb32 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmMonthlyProbCall");
    var cb33 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesWklEuropeUdt");
    var cb34 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmWklEuropeUdt");
    var cb35 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesWklVendorCall");
    var cb36 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmWklVendorCall");
    var cb37 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesWklHWSWCall");
    var cb38 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmWklHWSWCall");
    var cb39 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSDTeamMtg");
    var cb40 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmSDTeamMtg");
    var cb41 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSSTeamMtg");
    var cb42 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmSSTeamMtg");

    if (cb9.checked == false) {
        document.getElementById(cb10.id).disabled = true;
    }
    if (cb11.checked == false) {
        document.getElementById(cb12.id).disabled = true;
    }
    if (cb13.checked == false) {
        document.getElementById(cb14.id).disabled = true;
    }
    //    if (cb15.checked == false) {
    //        document.getElementById(cb16.id).disabled = true;
    //    }
    //    if (cb17.checked == false) {
    //        document.getElementById(cb18.id).disabled = true;
    //    }
    //    if (cb21.checked == false) {
    //        document.getElementById(cb22.id).disabled = true;
    //    }
    if (cb23.checked == false) {
        document.getElementById(cb24.id).disabled = true;
    }
    //    if (cb25.checked == false) {
    //        document.getElementById(cb26.id).disabled = true;
    //    }
    if (cb27.checked == false) {
        document.getElementById(cb28.id).disabled = true;
    }
    if (cb29.checked == false) {
        document.getElementById(cb30.id).disabled = true;
    }
    if (cb31.checked == false) {
        document.getElementById(cb32.id).disabled = true;
    }
    if (cb33.checked == false) {
        document.getElementById(cb34.id).disabled = true;
    }
    if (cb35.checked == false) {
        document.getElementById(cb36.id).disabled = true;
    }
    if (cb37.checked == false) {
        document.getElementById(cb38.id).disabled = true;
    }
    if (cb39.checked == false) {
        document.getElementById(cb40.id).disabled = true;
    }
    if (cb41.checked == false) {
        document.getElementById(cb42.id).disabled = true;
    }
}

function enabledisableconfirm(checkboxid) {
    var confirmcheckboxid;
    confirmcheckboxid = checkboxid.id.replace("Yes", "Confirm");

    if (checkboxid.checked == true) {

        document.getElementById(confirmcheckboxid).disabled = false;
    }
    else {
        if (document.getElementById(confirmcheckboxid).isContentEditable == false) {
            try {
                document.getElementById(confirmcheckboxid).isContentEditable = true;
            }
            catch (e) { }
            document.getElementById(confirmcheckboxid).checked = false;
            document.getElementById(confirmcheckboxid).disabled = true;
        }
        else {
            document.getElementById(confirmcheckboxid).checked = false;
            document.getElementById(confirmcheckboxid).disabled = true;
        }
    }
}


function CheckYesConfirmFieldsVaule(source, args) {
    var flag = true;
    var cb9 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesConsultingESP");
    var cb10 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmConsultingESP");
    var cb11 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesConsultingPP");
    var cb12 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmConsultingPP");
    var cb13 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesConsultingOP");
    var cb14 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmConsultingOP");
    
    //var cb15 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesVendorESP");
    //var cb16 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmVendorESP");
    //var cb17 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesVendorPP");
    //var cb18 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmVendorPP");
    //var cb21 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesNSG_OP");
    //var cb22 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmNSG_OP");
    
    var cb23 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesHSG_OP");
    var cb24 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmHSG_OP");
    
    //var cb25 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesUS_UK_P");
    //var cb26 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmUS_UK_P");

    var cb27 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesWIPReview");
    var cb28 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmWIPReview");
    var cb29 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesDealReview");
    var cb30 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmDealReview");
    var cb31 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesMonthlyProbCall");
    var cb32 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmMonthlyProbCall");
    var cb33 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesWklEuropeUdt");
    var cb34 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmWklEuropeUdt");
    var cb35 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesWklVendorCall");
    var cb36 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmWklVendorCall");
    var cb37 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesWklHWSWCall");
    var cb38 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmWklHWSWCall");
    var cb39 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSDTeamMtg");
    var cb40 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmSDTeamMtg");
    var cb41 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSSTeamMtg");
    var cb42 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmSSTeamMtg");

    if (cb9.checked == true) {
        if (cb10.checked == false) {
            flag = false;
        }
    }
    if (cb11.checked == true) {
        if (cb12.checked == false) {
            flag = false;
        }
    }
    if (cb13.checked == true) {
        if (cb14.checked == false) {
            flag = false;
        }
    }
//    if (cb15.checked == true) {
//        if (cb16.checked == false) {
//            flag = false;
//        }
//    }
//    if (cb17.checked == true) {
//        if (cb18.checked == false) {
//            flag = false;
//        }
//    }

//    if (cb21.checked == true) {
//        if (cb22.checked == false) {
//            flag = false;
//        }
//    }
    if (cb23.checked == true) {
        if (cb24.checked == false) {
            flag = false;
        }
    }
//    if (cb25.checked == true) {
//        if (cb26.checked == false) {
//            flag = false;
//        }
//    }
    if (cb27.checked == true) {
        if (cb28.checked == false) {
            flag = false;
        }
    }
    if (cb29.checked == true) {
        if (cb30.checked == false) {
            flag = false;
        }
    }
    if (cb31.checked == true) {
        if (cb32.checked == false) {
            flag = false;
        }
    }
    if (cb33.checked == true) {
        if (cb34.checked == false) {
            flag = false;
        }
    }
    if (cb35.checked == true) {
        if (cb36.checked == false) {
            flag = false;
        }
    }
    if (cb37.checked == true) {
        if (cb38.checked == false) {
            flag = false;
        }
    }
    if (cb39.checked == true) {
        if (cb40.checked == false) {
            flag = false;
        }
    }
    if (cb41.checked == true) {
        if (cb42.checked == false) {
            flag = false;
        }
    }
    if (flag == false)
        args.IsValid = false;
    else
        args.IsValid = true;
}
