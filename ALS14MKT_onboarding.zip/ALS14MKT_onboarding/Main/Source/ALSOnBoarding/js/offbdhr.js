﻿function CheckAllFieldsVaule(source, args) {
//    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbSelectSource");
    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbFidelity");
    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbADP");
    var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbCompanyDirectory");
    var cb5 = document.getElementById("ctl00_ContentPlaceHolder1_cbReplicon");
    var cb6 = document.getElementById("ctl00_ContentPlaceHolder1_cbHeadshotwiki");

    var cb7 = document.getElementById("ctl00_ContentPlaceHolder1_cbExitInterview");
    var cb8 = document.getElementById("ctl00_ContentPlaceHolder1_cbFinalPayReview");
    var cb9 = document.getElementById("ctl00_ContentPlaceHolder1_cbTerminationAgreement");
    var cb10 = document.getElementById("ctl00_ContentPlaceHolder1_cbFinalPayADP");
//    var cb11 = document.getElementById("ctl00_ContentPlaceHolder1_cbNotifyCOBRA");
//    var cb12 = document.getElementById("ctl00_ContentPlaceHolder1_cbDisablePortal");

    if (cb2.checked == false && cb3.checked == false && cb4.checked == false && cb5.checked == false && cb6.checked == false &&
        cb7.checked == false && cb8.checked == false && cb9.checked == false && cb10.checked == false) {
        args.IsValid = false;
    }
    else {
        args.IsValid = true;
    }
}


function CheckConfirmbyMe(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmbyMe");
    if (cb1.checked == false)
        args.IsValid = false;
    else
        args.IsValid = true;
}
