﻿//var containerId = '#tabs-container';

$("li").click(function() {
    // If this isn't already active
if (!$(this).hasClass("current")) {
        // Remove the class from anything that is active
    $("li.active").removeClass("current");
        // And make this active
    $(this).addClass("current");
    }
});

//var tabsId = '#tabs';
//$("li").click(function() {
//    // Preload tab on page load
//    if ($((this) + ' li.current a').length > 0) {
//        //loadTab($(tabsId + ' li.current a'));
//    }

//    $((this) + ' a').click(function() {
//        if ($(this).parent().hasClass('current')) { return false; }

//        $((this) + ' li.current').removeClass('current');
//        $(this).parent().addClass('current');

//        //loadTab($(this));
//        return false;
//    });
//});

//function loadTab(tabObj) {
//    if (!tabObj || !tabObj.length) { return; }
//    $(containerId).addClass('loading');
//    $(containerId).fadeOut('fast');

//    $(containerId).load(tabObj.attr('href'), function() {
//        $(containerId).removeClass('loading');
//        $(containerId).fadeIn('fast');
//    });
//}