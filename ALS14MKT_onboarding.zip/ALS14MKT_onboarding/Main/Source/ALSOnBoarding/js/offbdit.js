﻿function CheckAllFieldsVaule(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbPwdChange");
    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbEmailForwarded");
    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbEmailArchived");
    //var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbWikiAccessRemoved");
    var cb5 = document.getElementById("ctl00_ContentPlaceHolder1_cbL3WebConnectAc");
    var cb6 = document.getElementById("ctl00_ContentPlaceHolder1_cbSalesforceDisabled");
    //var cb7 = document.getElementById("ctl00_ContentPlaceHolder1_cbPrinterRemoved");
    var cb8 = document.getElementById("ctl00_ContentPlaceHolder1_cbVPNDisabled");

    var cb9 = document.getElementById("ctl00_ContentPlaceHolder1_cbRemoveEmailGroup");
    var cb10 = document.getElementById("ctl00_ContentPlaceHolder1_cbSendboxRecoverLaptop");
    var cb11 = document.getElementById("ctl00_ContentPlaceHolder1_cbLaptopHardwareRecovered");
    var cb12 = document.getElementById("ctl00_ContentPlaceHolder1_cbBackupConducted");
    
    var txt1 = document.getElementById("ctl00_ContentPlaceHolder1_txtAdditionalAccess");

    if (cb1.checked == false && cb2.checked == false && cb3.checked == false &&
        cb5.checked == false && cb6.checked == false && cb8.checked == false &&
        cb9.checked == false && cb10.checked == false && cb11.checked == false && cb12.checked == false &&
        txt1.value == "") {
        args.IsValid = false;
    }
    else {
        args.IsValid = true;
    }
}



function CheckConfirmbyMe(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmbyMe");
    if (cb1.checked == false)
        args.IsValid = false;
    else
        args.IsValid = true;
}
