﻿function CheckAllFieldsVaule(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbW4W9");
    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbI9");
    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbDDForm");
    var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbPolicySign");
    var cb5 = document.getElementById("ctl00_ContentPlaceHolder1_cbScheduleOnboarding");
    var cb6 = document.getElementById("ctl00_ContentPlaceHolder1_cbOnboardingAgenda");
    var cb7 = document.getElementById("ctl00_ContentPlaceHolder1_cbRuneverify");
    var cb8 = document.getElementById("ctl00_ContentPlaceHolder1_cbBackgroundCheck");
    var cb9 = document.getElementById("ctl00_ContentPlaceHolder1_cbOfferLetter");
    var cb10 = document.getElementById("ctl00_ContentPlaceHolder1_cbEmploymentAgreement");
    var cb11 = document.getElementById("ctl00_ContentPlaceHolder1_cbRepliconCounselProject");
    var cb12 = document.getElementById("ctl00_ContentPlaceHolder1_cbAlsbridgeDebitCard");
    var cb13 = document.getElementById("ctl00_ContentPlaceHolder1_cbAddedToPayrollIndia");
    var cb14 = document.getElementById("ctl00_ContentPlaceHolder1_cbNewHireKit");
    var cb15 = document.getElementById("ctl00_ContentPlaceHolder1_cbAddtoDir");
    var cb16 = document.getElementById("ctl00_ContentPlaceHolder1_cbLunchSecheduled");
    var cb17 = document.getElementById("ctl00_ContentPlaceHolder1_cbBenefitOverview");
    var cb18 = document.getElementById("ctl00_ContentPlaceHolder1_cbAdded401k");
    var cb19 = document.getElementById("ctl00_ContentPlaceHolder1_cbIndividualHeadshot");
    var cb20 = document.getElementById("ctl00_ContentPlaceHolder1_cbTrainingReplicon");
    var cb21 = document.getElementById("ctl00_ContentPlaceHolder1_cbAlsbridgeOverview");
    var cb22 = document.getElementById("ctl00_ContentPlaceHolder1_cbADPPayroll");
    var cb23 = document.getElementById("ctl00_ContentPlaceHolder1_cbResume");
    var cb24 = document.getElementById("ctl00_ContentPlaceHolder1_cbAssessments");
    

    if (cb1.checked == false && cb2.checked == false && cb3.checked == false && cb4.checked == false &&
    cb5.checked == false && cb6.checked == false && cb7.checked == false && cb8.checked == false &&
    cb9.checked == false && cb10.checked == false && cb11.checked == false && cb12.checked == false &&
    cb13.checked == false && cb14.checked == false && cb15.checked == false && cb16.checked == false &&
    cb17.checked == false && cb18.checked == false && cb19.checked == false && cb20.checked == false &&
    cb21.checked == false && cb22.checked == false && cb23.checked == false && cb24.checked == false) {
        args.IsValid = false;
    }
    else {
        args.IsValid = true;
    }
}


function CheckConfirmbyMe(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmbyMe");
    if (cb1.checked == false)
        args.IsValid = false;
    else
        args.IsValid = true;
}

//function CheckAllFieldsVaule(source, args) {
//    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbW4W9");
//    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbI9");
//    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbDDForm");
//    var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbPolicySign");
//    var cb5 = document.getElementById("ctl00_ContentPlaceHolder1_cbRuneverify");
//    var cb6 = document.getElementById("ctl00_ContentPlaceHolder1_cbBackgroundCheck");
//    var cb7 = document.getElementById("ctl00_ContentPlaceHolder1_cbAgreementExecuted");
//    var cb8 = document.getElementById("ctl00_ContentPlaceHolder1_cbDocumentsGathered");
//    var cb9 = document.getElementById("ctl00_ContentPlaceHolder1_cbCounselGroupLeadIntro");
//    var cb10 = document.getElementById("ctl00_ContentPlaceHolder1_cbPeerCoachingIntro");
//    var cb11 = document.getElementById("ctl00_ContentPlaceHolder1_cbBioUpdtdPtdWiki");
//    var cb12 = document.getElementById("ctl00_ContentPlaceHolder1_cbContactMeetingSetReaghan");
//    var cb13 = document.getElementById("ctl00_ContentPlaceHolder1_cbAddtoDir");
//    var cb14 = document.getElementById("ctl00_ContentPlaceHolder1_cbCoDir");
//    var cb15 = document.getElementById("ctl00_ContentPlaceHolder1_cbVoicemailInst");
//    var cb16 = document.getElementById("ctl00_ContentPlaceHolder1_cbVcfCrUp");
//    var cb17 = document.getElementById("ctl00_ContentPlaceHolder1_cbSkillDatabase");
//    var cb18 = document.getElementById("ctl00_ContentPlaceHolder1_cbLunchSecheduled");
//    var cb19 = document.getElementById("ctl00_ContentPlaceHolder1_cbBenefitVideo");
//    var cb20 = document.getElementById("ctl00_ContentPlaceHolder1_cbBenefitOverview");
//    var cb21 = document.getElementById("ctl00_ContentPlaceHolder1_cbBenefitEnrollment");
//    var cb22 = document.getElementById("ctl00_ContentPlaceHolder1_cbAdded401k");
//    var cb23 = document.getElementById("ctl00_ContentPlaceHolder1_cbIndividualHeadshot");
//    var cb24 = document.getElementById("ctl00_ContentPlaceHolder1_cbTrainingSalesSupport");
//    var cb25 = document.getElementById("ctl00_ContentPlaceHolder1_cbTrainingPBOC");
//    var cb26 = document.getElementById("ctl00_ContentPlaceHolder1_cbTrainingReplicon");
//    var cb27 = document.getElementById("ctl00_ContentPlaceHolder1_cbAlsbridgeOverview");

//    var cb28 = document.getElementById("ctl00_ContentPlaceHolder1_cbNewHireTest");
//    var cb29 = document.getElementById("ctl00_ContentPlaceHolder1_cbLinkedinUpdate");
//    var cb30 = document.getElementById("ctl00_ContentPlaceHolder1_cbRepliconCounselProject");
//    var cb31 = document.getElementById("ctl00_ContentPlaceHolder1_cbADPPayroll");
//    var cb32 = document.getElementById("ctl00_ContentPlaceHolder1_cbAlsbridgeDebitCard");

//    var cb33 = document.getElementById("ctl00_ContentPlaceHolder1_cbReferences");
//    var cb34 = document.getElementById("ctl00_ContentPlaceHolder1_cbResume");
//    var cb35 = document.getElementById("ctl00_ContentPlaceHolder1_cbAssessments");

//    if (cb1.checked == false && cb2.checked == false && cb3.checked == false && cb4.checked == false &&
//    cb5.checked == false && cb6.checked == false && cb7.checked == false && cb8.checked == false &&
//    cb9.checked == false && cb10.checked == false && cb11.checked == false && cb12.checked == false &&
//    cb13.checked == false && cb14.checked == false && cb15.checked == false && cb16.checked == false &&
//    cb17.checked == false && cb18.checked == false && cb19.checked == false && cb20.checked == false &&
//    cb21.checked == false && cb22.checked == false && cb23.checked == false && cb24.checked == false &&
//    cb25.checked == false && cb26.checked == false && cb27.checked == false && cb28.checked == false &&
//    cb29.checked == false && cb30.checked == false && cb31.checked == false && cb32.checked == false &&
//    cb33.checked == false && cb34.checked == false && cb35.checked == false) {
//        args.IsValid = false;
//    }
//    else {
//        args.IsValid = true;
//    }
//}

//function CheckAllFieldsVaule1(source, args) {
//    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbW4W9");
//    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbI9");
//    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbDDForm");
//    var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbPolicySign");
//    var cb5 = document.getElementById("ctl00_ContentPlaceHolder1_cbRuneverify");
//    var cb6 = document.getElementById("ctl00_ContentPlaceHolder1_cbBackgroundCheck");
//    var cb7 = document.getElementById("ctl00_ContentPlaceHolder1_cbAgreementExecuted");
//    var cb8 = document.getElementById("ctl00_ContentPlaceHolder1_cbDocumentsGathered");
//    var cb9 = document.getElementById("ctl00_ContentPlaceHolder1_cbCounselGroupLeadIntro");
//    var cb10 = document.getElementById("ctl00_ContentPlaceHolder1_cbPeerCoachingIntro");
//    var cb11 = document.getElementById("ctl00_ContentPlaceHolder1_cbBioUpdtdPtdWiki");
//    var cb12 = document.getElementById("ctl00_ContentPlaceHolder1_cbContactMeetingSetReaghan");
//    var cb13 = document.getElementById("ctl00_ContentPlaceHolder1_cbAddtoDir");
//    var cb14 = document.getElementById("ctl00_ContentPlaceHolder1_cbCoDir");
//    var cb15 = document.getElementById("ctl00_ContentPlaceHolder1_cbVoicemailInst");
//    var cb16 = document.getElementById("ctl00_ContentPlaceHolder1_cbVcfCrUp");
//    var cb17 = document.getElementById("ctl00_ContentPlaceHolder1_cbSkillDatabase");
//    var cb18 = document.getElementById("ctl00_ContentPlaceHolder1_cbLunchSecheduled");
//    var cb19 = document.getElementById("ctl00_ContentPlaceHolder1_cbBenefitVideo");
//    var cb20 = document.getElementById("ctl00_ContentPlaceHolder1_cbBenefitOverview");
//    var cb21 = document.getElementById("ctl00_ContentPlaceHolder1_cbBenefitEnrollment");
//    var cb22 = document.getElementById("ctl00_ContentPlaceHolder1_cbAdded401k");
//    var cb23 = document.getElementById("ctl00_ContentPlaceHolder1_cbIndividualHeadshot");
//    var cb24 = document.getElementById("ctl00_ContentPlaceHolder1_cbTrainingSalesSupport");
//    var cb25 = document.getElementById("ctl00_ContentPlaceHolder1_cbTrainingPBOC");
//    var cb26 = document.getElementById("ctl00_ContentPlaceHolder1_cbTrainingReplicon");
//    var cb27 = document.getElementById("ctl00_ContentPlaceHolder1_cbAlsbridgeOverview");

//    var cb28 = document.getElementById("ctl00_ContentPlaceHolder1_cbNewHireTest");
//    var cb29 = document.getElementById("ctl00_ContentPlaceHolder1_cbLinkedinUpdate");
//    var cb30 = document.getElementById("ctl00_ContentPlaceHolder1_cbRepliconCounselProject");
//    var cb31 = document.getElementById("ctl00_ContentPlaceHolder1_cbADPPayroll");
//    var cb32 = document.getElementById("ctl00_ContentPlaceHolder1_cbAlsbridgeDebitCard");

//    var cb33 = document.getElementById("ctl00_ContentPlaceHolder1_cbReferences");
//    var cb34 = document.getElementById("ctl00_ContentPlaceHolder1_cbResume");
//    var cb35 = document.getElementById("ctl00_ContentPlaceHolder1_cbAssessments");

//    if (cb1.checked == false && cb2.checked == false && cb3.checked == false && cb4.checked == false &&
//    cb5.checked == false && cb6.checked == false && cb7.checked == false && cb8.checked == false &&
//    cb9.checked == false && cb10.checked == false && cb11.checked == false && cb12.checked == false &&
//    cb13.checked == false && cb14.checked == false && cb15.checked == false && cb16.checked == false &&
//    cb17.checked == false && cb18.checked == false && cb19.checked == false && cb20.checked == false &&
//    cb21.checked == false && cb22.checked == false && cb23.checked == false && cb24.checked == false &&
//    cb25.checked == false && cb26.checked == false && cb27.checked == false && cb28.checked == false &&
//    cb29.checked == false && cb30.checked == false && cb31.checked == false && cb32.checked == false &&
//    cb33.checked == false && cb34.checked == false && cb35.checked == false) {
//        args.IsValid = false;
//    }
//    else {
//        args.IsValid = true;
//    }
//}

//function CheckConfirmbyMe(source, args) {
//    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmbyMe");
//    if (cb1.checked == false)
//        args.IsValid = false;
//    else
//        args.IsValid = true;
//}