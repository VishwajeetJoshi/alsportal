﻿function CheckAllFieldsVaule(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesParkingEntry");
    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesEntryKey");
    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSecurityCode");
    var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSecurityinfo");    

    if (cb1.checked == false && cb2.checked == false && cb3.checked == false && cb4.checked == false) {
        args.IsValid = false;
    }
    else {
        args.IsValid = true;
    }
}

function CheckAllFieldsVaule1(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesParkingEntry");
    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesEntryKey");
    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSecurityCode");
    var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSecurityinfo");

    if (cb1.checked == false && cb2.checked == false && cb3.checked == false && cb4.checked == false) {
        args.IsValid = false;
    }
    else {
        args.IsValid = true;
    }
}

function CheckConfirmbyMe(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmbyMe");
    if (cb1.checked == false)
        args.IsValid = false;
    else
        args.IsValid = true;
}

function disbaleconfirmcheckboxes() {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesParkingEntry");
    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmParkingEntry");
    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesEntryKey");
    var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmEntryKey");
    var cb5 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSecurityCode");
    var cb6 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmSecurityCode");
    var cb7 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSecurityinfo");
    var cb8 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmSecurityinfo");
   
    if (cb1.checked == false) {
        document.getElementById(cb2.id).disabled = true;
    }
    if (cb3.checked == false) {
        document.getElementById(cb4.id).disabled = true;
    }
    if (cb5.checked == false) {
        document.getElementById(cb6.id).disabled = true;
    }
    if (cb7.checked == false) {
        document.getElementById(cb8.id).disabled = true;
    }   
}

function enabledisableconfirm(checkboxid) {
    var confirmcheckboxid;
    confirmcheckboxid = checkboxid.id.replace("Yes", "Confirm");

    if (checkboxid.checked == true) {

        document.getElementById(confirmcheckboxid).disabled = false;
    }
    else {
        if (document.getElementById(confirmcheckboxid).isContentEditable == false) {
            try {
                document.getElementById(confirmcheckboxid).isContentEditable = true;
            }
            catch (e) { }
            document.getElementById(confirmcheckboxid).checked = false;
            document.getElementById(confirmcheckboxid).disabled = true;
        }
        else {
            document.getElementById(confirmcheckboxid).checked = false;
            document.getElementById(confirmcheckboxid).disabled = true;
        }
    }
}

function CheckYesConfirmFieldsVaule(source, args) {
    var flag = true;
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesParkingEntry");
    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmParkingEntry");
    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesEntryKey");
    var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmEntryKey");
    var cb5 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSecurityCode");
    var cb6 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmSecurityCode");
    var cb7 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSecurityinfo");
    var cb8 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmSecurityinfo");
    
    if (cb1.checked == true) {
        if (cb2.checked == false) {
            flag = false;
        }
    }
    if (cb3.checked == true) {
        if (cb4.checked == false) {
            flag = false;
        }
    }
    if (cb5.checked == true) {
        if (cb6.checked == false) {
            flag = false;
        }
    }
    if (cb7.checked == true) {
        if (cb8.checked == false) {
            flag = false;
        }
    }    

    if (flag == false)
        args.IsValid = false;
    else
        args.IsValid = true;
}
