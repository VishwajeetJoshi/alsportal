﻿
function echeck() {
    //TBUserName
    var str = document.getElementById("ctl00_ContentPlaceHolder1_txtUserName").value;
    if (str == "") {
        return true;
    }
    var at = "@"
    var dot = "."
    var lat = str.indexOf(at)
    var lstr = str.length
    var ldot = str.indexOf(dot)
    if (str.indexOf(at) == -1) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtUserName").focus(); }, 1);
        return false;
    }

    if (str.indexOf(at) == -1 || str.indexOf(at) == 0 || str.indexOf(at) == lstr) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtUserName").focus(); }, 1);
        return false;
    }

    if (str.indexOf(dot) == -1 || str.indexOf(dot) == 0 || str.indexOf(dot) == lstr) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtUserName").focus(); }, 1);
        return false;
    }

    if (str.indexOf(at, (lat + 1)) != -1) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtUserName").focus(); }, 1);
        return false;
    }

    if (str.substring(lat - 1, lat) == dot || str.substring(lat + 1, lat + 2) == dot) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtUserName").focus(); }, 1);
        return false;
    }

    if (str.indexOf(dot, (lat + 2)) == -1) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtUserName").focus(); }, 1);
        return false;
    }

    if (str.indexOf(" ") != -1) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtUserName").focus(); }, 1);
        return false;
    }

    return true;
}

function pwdcheck1() {
    var str = document.getElementById("ctl00_ContentPlaceHolder1_txtPwd").value;

    if (str == "") {
        return true;
    }
    var ck_pwd2 = /^[^\s]{6,20}/;
    var ck_pwd3 = /^.*[A-Z].*/;
    var ck_pwd4 = /^.*[0-9].*/;

    if (!ck_pwd2.test(str)) {
        alert("Password must be at least 6 charactor with combination of number and letter and at least one uppercase");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtPwd").focus(); }, 1);
        return false;
    }
    else if (!ck_pwd3.test(str)) {
        alert("Password must be at least 6 charactor with combination of number and letter and at least one uppercase");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtPwd").focus(); }, 1);
        return false;
    }
    else if (!ck_pwd4.test(str)) {
        alert("Password must be at least 6 charactor with combination of number and letter and at least one uppercase");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtPwd").focus(); }, 1);
        return false;
    }
    return true
}

function alltrim(str) {
    return str.replace(/^\s+|\s+$/g, '');
}

function pwdconfirm1() {
    var str = document.getElementById("ctl00_ContentPlaceHolder1_txtPwd").value;
    var str1 = document.getElementById("ctl00_ContentPlaceHolder1_txtConfirmPwd").value;
    if (str1 == "") {
        return true;
    }
    if (str == str1) {
        return true
    }
    else {
        alert("Password does not match.");
        document.getElementById("ctl00_ContentPlaceHolder1_txtConfirmPwd").value = "";
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtConfirmPwd").focus(); }, 1);
        return false;
    }
}

function checkRole(source, args) {    
        if ($('#divRole').find('input:checkbox:checked').length == 0) {
            args.IsValid = false;
        }
        else {
            args.IsValid = true;
        }
}