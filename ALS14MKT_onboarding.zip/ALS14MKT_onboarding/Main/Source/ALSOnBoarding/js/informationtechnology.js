﻿var zChar = new Array(' ', '-', '-', '.');
var maxphonelength = 12;
var phonevalue1;
var phonevalue2;
var cursorposition;

function ParseForNumber1(object) {
    phonevalue1 = ParseChar(object.value, zChar);
}
function ParseForNumber2(object) {
    phonevalue2 = ParseChar(object.value, zChar);
}

function backspacerUP(object, e) {
    if (e) {
        e = e
    } else {
        e = window.event
    }
    if (e.which) {
        var keycode = e.which
    } else {
        var keycode = e.keyCode
    }

    ParseForNumber1(object)

    if (keycode >= 48) {
        ValidatePhone(object)
    }
}

function backspacerDOWN(object, e) {
    if (e) {
        e = e
    } else {
        e = window.event
    }
    if (e.which) {
        var keycode = e.which
    } else {
        var keycode = e.keyCode
    }
    ParseForNumber2(object)
}

function GetCursorPosition() {

    var t1 = phonevalue1;
    var t2 = phonevalue2;
    var bool = false
    for (i = 0; i < t1.length; i++) {
        if (t1.substring(i, 1) != t2.substring(i, 1)) {
            if (!bool) {
                cursorposition = i
                bool = true
            }
        }
    }
}

function ValidatePhone(object) {

    var p = phonevalue1

    p = p.replace(/[^\d]*/gi, "")

    if (p.length < 3) {
        object.value = p
    } else if (p.length == 3) {
        pp = p;
        d4 = p.indexOf('-')
        d5 = p.indexOf('-')
        if (d4 == -1) {
            pp = pp;
        }
        if (d5 == -1) {
            pp = pp + "-";
        }
        object.value = pp;
    } else if (p.length > 3 && p.length < 6) {
        p = p;
        l30 = p.length;
        p30 = p.substring(0, 3);
        p30 = p30 + "-"

        p31 = p.substring(3, l30);
        pp = p30 + p31;

        object.value = pp;

    } else if (p.length >= 6) {
        p = p;
        l30 = p.length;
        p30 = p.substring(0, 3);
        p30 = p30 + "-"
        //        if (l30 == 7)
        //            l30 = l30 - 1;
        p31 = p.substring(3, l30);
        pp = p30 + p31;

        l40 = pp.length;
        p40 = pp.substring(0, 7);
        p40 = p40 + "-"

        p41 = pp.substring(7, l40);
        ppp = p40 + p41;

        object.value = ppp.substring(0, maxphonelength);
    }

    GetCursorPosition()

    if (cursorposition >= 0) {
        if (cursorposition == 0) {
            cursorposition = 2
        } else if (cursorposition <= 2) {
            cursorposition = cursorposition + 1
        } else if (cursorposition <= 5) {
            cursorposition = cursorposition + 2
        } else if (cursorposition == 6) {
            cursorposition = cursorposition + 2
        } else if (cursorposition == 7) {
            cursorposition = cursorposition + 4
            e1 = object.value.indexOf(')')
            e2 = object.value.indexOf('-')
            if (e1 > -1 && e2 > -1) {
                if (e2 - e1 == 4) {
                    cursorposition = cursorposition - 1
                }
            }
        } else if (cursorposition < 11) {
            cursorposition = cursorposition + 3
        } else if (cursorposition == 11) {
            cursorposition = cursorposition + 1
        } else if (cursorposition >= 12) {
            cursorposition = cursorposition
        }

        var txtRange = object.createTextRange();
        txtRange.moveStart("character", cursorposition);
        txtRange.moveEnd("character", cursorposition - object.value.length);
        txtRange.select();
    }

}

function ParseChar(sStr, sChar) {
    if (sChar.length == null) {
        zChar = new Array(sChar);
    }
    else zChar = sChar;

    for (i = 0; i < zChar.length; i++) {
        sNewStr = "";

        var iStart = 0;
        var iEnd = sStr.indexOf(sChar[i]);

        while (iEnd != -1) {
            sNewStr += sStr.substring(iStart, iEnd);
            iStart = iEnd + 1;
            iEnd = sStr.indexOf(sChar[i], iStart);
        }
        sNewStr += sStr.substring(sStr.lastIndexOf(sChar[i]) + 1, sStr.length);

        sStr = sNewStr;
    }

    return sNewStr;
}

function checkdate(input) {
    var validformat = /^\d{2}\/\d{2}\/\d{4}$/ //Basic check for format validity
    var returnval = false
    if (input.value == "") {
        returnval = true
    }
    else {
        if (!validformat.test(input.value))
            alert("Invalid Date Format. Please correct and submit again.")
        else { //Detailed check for valid date ranges
            var monthfield = input.value.split("/")[0]
            var dayfield = input.value.split("/")[1]
            var yearfield = input.value.split("/")[2]
            var dayobj = new Date(yearfield, monthfield - 1, dayfield)
            if ((dayobj.getDate() != dayfield) || (dayobj.getMonth() + 1 != monthfield) || (dayobj.getFullYear() != yearfield))
                alert("Invalid Day, Month, or Year range detected. Please correct date format (MM/DD/YYYY)")
            else
                returnval = true
        }
        if (returnval == false)
        //input.select()
            setTimeout(function() { document.getElementById(input.id).focus(); }, 1);
        return returnval
    }
}

function echeck() {
    //TBUserName
    var str = document.getElementById("ctl00_ContentPlaceHolder1_txtEmailAddress").value;
    if (str == "") {
        return true;
    }
    var at = "@"
    var dot = "."
    var lat = str.indexOf(at)
    var lstr = str.length
    var ldot = str.indexOf(dot)
    if (str.indexOf(at) == -1) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtEmailAddress").focus(); }, 1);
        return false;
    }

    if (str.indexOf(at) == -1 || str.indexOf(at) == 0 || str.indexOf(at) == lstr) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtEmailAddress").focus(); }, 1);
        return false;
    }

    if (str.indexOf(dot) == -1 || str.indexOf(dot) == 0 || str.indexOf(dot) == lstr) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtEmailAddress").focus(); }, 1);
        return false;
    }

    if (str.indexOf(at, (lat + 1)) != -1) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtEmailAddress").focus(); }, 1);
        return false;
    }

    if (str.substring(lat - 1, lat) == dot || str.substring(lat + 1, lat + 2) == dot) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtEmailAddress").focus(); }, 1);
        return false;
    }

    if (str.indexOf(dot, (lat + 2)) == -1) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtEmailAddress").focus(); }, 1);
        return false;
    }

    if (str.indexOf(" ") != -1) {
        alert("Please add a valid user name eg: abc@abc.com");
        setTimeout(function() { document.getElementById("ctl00_ContentPlaceHolder1_txtEmailAddress").focus(); }, 1);
        return false;
    }

    return true;
}

//
function CheckAllFieldsVaule(source, args) {
    var t1 = document.getElementById("ctl00_ContentPlaceHolder1_txtEmailAddress");
    var t2 = document.getElementById("ctl00_ContentPlaceHolder1_txtOtherTeamList");
    var t3 = document.getElementById("ctl00_ContentPlaceHolder1_txtDallasPhyExtention");
    var t4 = document.getElementById("ctl00_ContentPlaceHolder1_txtDallasDirectNo");
    var t5 = document.getElementById("ctl00_ContentPlaceHolder1_txtRemoteRedirectNo");
    var t6 = document.getElementById("ctl00_ContentPlaceHolder1_txtLaptopAssest");
    var t7 = document.getElementById("ctl00_ContentPlaceHolder1_txtAdditionalComment");

    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbEmailSignatures");
    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbTeamList");
    
    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbDockingStattion");
    var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbStand");
    var cb5 = document.getElementById("ctl00_ContentPlaceHolder1_cbMonitor");
    var cb6 = document.getElementById("ctl00_ContentPlaceHolder1_cbKeyboard");
    var cb7 = document.getElementById("ctl00_ContentPlaceHolder1_cbMouse");
    var cb8 = document.getElementById("ctl00_ContentPlaceHolder1_cbPhone");
    var cb9 = document.getElementById("ctl00_ContentPlaceHolder1_cbExtraBattery");
    var cb10 = document.getElementById("ctl00_ContentPlaceHolder1_cbExtraPowerCord");

    var cb11 = document.getElementById("ctl00_ContentPlaceHolder1_cbServiceTag");

    var cb12 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesMSProject");
    var cb13 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmMSProject");
    var cb14 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesMSVisio");
    var cb15 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmMSVisio");

    var cb16 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesAPStylebook");
    var cb17 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmAPStylebook");
    var cb18 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSalesforce");
    var cb19 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmSalesforce");
    var cb20 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesInsideView");
    var cb21 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmInsideView");
    var cb22 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesPowerDialer");
    var cb23 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmPowerDialer");
    var cb24 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesRRUS");
    var cb25 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmRRUS");
    var cb26 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesDiscoverOrg");
    var cb27 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmDiscoverOrg");
    var cb28 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesAlsbridgesalesMail");
    var cb29 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmAlsbridgesalesMail");
    var cb30 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesPbsalesMail");
    var cb31 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmPbsalesMail");
    var cb32 = document.getElementById("ctl00_ContentPlaceHolder1_cbITCheklistComp");
    var cb33 = document.getElementById("ctl00_ContentPlaceHolder1_cbITOpearationSession");
    var cb34 = document.getElementById("ctl00_ContentPlaceHolder1_cbOfficeLocationRemote");

    var t8 = document.getElementById("ctl00_ContentPlaceHolder1_txtPCShippedDate");
    var ddl1 = document.getElementById("ctl00_ContentPlaceHolder1_ddlLaptopType");
    var ddl2 = document.getElementById("ctl00_ContentPlaceHolder1_ddlOfficeLocation");

    if (t1.value == "" && t2.value == "" && t3.value == "" && t4.value == "" && t5.value == "" && t6.value == "" && t7.value == "" && t8.value == "") {
        if (cb1.checked == false && cb2.checked == false && cb3.checked == false && cb4.checked == false && cb5.checked == false && cb6.checked == false
            && cb7.checked == false && cb8.checked == false && cb9.checked == false && cb10.checked == false && cb11.checked == false && cb12.checked == false
            && cb13.checked == false && cb14.checked == false && cb15.checked == false && cb16.checked == false && cb17.checked == false && cb18.checked == false
            && cb19.checked == false && cb20.checked == false && cb21.checked == false && cb22.checked == false && cb23.checked == false && cb24.checked == false 
            && cb25.checked == false && cb26.checked == false && cb27.checked == false && cb28.checked == false && cb29.checked == false && cb30.checked == false
            && cb31.checked == false && cb32.checked == false && cb33.checked == false && cb34.checked == false && ddl1.options[ddl1.selectedIndex].value == "0"
            && ddl2.options[ddl2.selectedIndex].value == "0") {
            args.IsValid = false;
        }
    }
    else {
        args.IsValid = true;
    }
}

function CheckConfirmbyMe(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmbyMe");
    if (cb1.checked == false)
        args.IsValid = false;
    else
        args.IsValid = true;
}


//function CheckMandatoryFieldsVaule(source, args) {

//    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbAdobeReader");
//    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbMSOffice");
//    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbWiki");
//    var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbGTMmeeting");
//    var cb5 = document.getElementById("ctl00_ContentPlaceHolder1_cbAVG");
//    var cb6 = document.getElementById("ctl00_ContentPlaceHolder1_cbPrinters");
//    var cb7 = document.getElementById("ctl00_ContentPlaceHolder1_cbJungleDisk");
//    var cb8 = document.getElementById("ctl00_ContentPlaceHolder1_cbPDFCreator");
//    var cb9 = document.getElementById("ctl00_ContentPlaceHolder1_cbAddShortcuts");
//    var cb10 = document.getElementById("ctl00_ContentPlaceHolder1_cbMapJDdocsdesktop");
//    var cb11 = document.getElementById("ctl00_ContentPlaceHolder1_cbSupportMail");
//    var cb12 = document.getElementById("ctl00_ContentPlaceHolder1_cbSDcard");

//    //New added 170614
//    var cb13 = document.getElementById("ctl00_ContentPlaceHolder1_cbLync");

//    if (cb1.checked == true && cb2.checked == true && cb3.checked == true && cb4.checked == true && cb5.checked == true
//            && cb6.checked == true && cb7.checked == true && cb8.checked == true && cb9.checked == true && cb10.checked == true
//            && cb11.checked == true && cb12.checked == true && cb13.checked == true) {
//        args.IsValid = true;
//    }
//    else {
//        args.IsValid = false;
//    }
//}

function CheckYesConfirmFieldsVaule(source, args) {
    var flag = true;
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesMSProject");
    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmMSProject");
    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesMSVisio");
    var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmMSVisio");

    var cb5 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesAPStylebook");
    var cb6 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmAPStylebook");
    var cb7 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSalesforce");
    var cb8 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmSalesforce");
    var cb9 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesInsideView");
    var cb10 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmInsideView");
    var cb11 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesPowerDialer");
    var cb12 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmPowerDialer");
    var cb13 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesRRUS");
    var cb14 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmRRUS");
    var cb15 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesDiscoverOrg");
    var cb16 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmDiscoverOrg");
    var cb17 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesAlsbridgesalesMail");
    var cb18 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmAlsbridgesalesMail");
    var cb19 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesPbsalesMail");
    var cb20 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmPbsalesMail");

    if (cb1.checked == true) {
        if (cb2.checked == false) {
            flag = false;
        }
    }
    if (cb3.checked == true) {
        if (cb4.checked == false) {
            flag = false;
        }
    }
    if (cb5.checked == true) {
        if (cb6.checked == false) {
            flag = false;
        }
    }
    if (cb7.checked == true) {
        if (cb8.checked == false) {
            flag = false;
        }
    }
    if (cb9.checked == true) {
        if (cb10.checked == false) {
            flag = false;
        }
    }
    if (cb11.checked == true) {
        if (cb12.checked == false) {
            flag = false;
        }
    }
    if (cb13.checked == true) {
        if (cb14.checked == false) {
            flag = false;
        }
    }    
    if (cb15.checked == true) {
        if (cb16.checked == false) {
            flag = false;
        }
    }
    if (cb17.checked == true) {
        if (cb18.checked == false) {
            flag = false;
        }
    }    
    if (cb19.checked == true) {
        if (cb20.checked == false) {
            flag = false;
        }
    }
    if (flag == false)
        args.IsValid = false;
    else
        args.IsValid = true;
}


function enabledisableconfirm(checkboxid) {
    var confirmcheckboxid = checkboxid.id.replace("Yes", "Confirm");
    if (checkboxid.checked == true) {
        document.getElementById(confirmcheckboxid).disabled = false;
    }
    else {
        if (document.getElementById(confirmcheckboxid).isContentEditable == false) {
            try {
                document.getElementById(confirmcheckboxid).isContentEditable = true;
            }
            catch (e) { }
            document.getElementById(confirmcheckboxid).checked = false;
            document.getElementById(confirmcheckboxid).disabled = true;
        }
        else {
            document.getElementById(confirmcheckboxid).checked = false;
            document.getElementById(confirmcheckboxid).disabled = true;
        }
        //        document.getElementById(confirmcheckboxid).isContentEditable = true;
        //        document.getElementById(confirmcheckboxid).checked = false;
        //        document.getElementById(confirmcheckboxid).disabled = true;
    }
}

function disbaleconfirmcheckboxes() {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesMSProject");
    var cb2 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmMSProject");
    var cb3 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesMSVisio");
    var cb4 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmMSVisio");

    var cb5 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesAPStylebook");
    var cb6 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmAPStylebook");
    var cb7 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesSalesforce");
    var cb8 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmSalesforce");
    var cb9 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesInsideView");
    var cb10 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmInsideView");
    var cb11 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesPowerDialer");
    var cb12 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmPowerDialer");
    var cb13 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesRRUS");
    var cb14 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmRRUS");
    var cb15 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesDiscoverOrg");
    var cb16 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmDiscoverOrg");
    var cb17 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesAlsbridgesalesMail");
    var cb18 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmAlsbridgesalesMail");
    var cb19 = document.getElementById("ctl00_ContentPlaceHolder1_cbYesPbsalesMail");
    var cb20 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmPbsalesMail");

    if (cb1.checked == false) {
        document.getElementById(cb2.id).disabled = true;
    }
    if (cb3.checked == false) {
        document.getElementById(cb4.id).disabled = true;
    }
    if (cb5.checked == false) {
        document.getElementById(cb6.id).disabled = true;
    }
    if (cb7.checked == false) {
        document.getElementById(cb8.id).disabled = true;
    }
    if (cb9.checked == false) {
        document.getElementById(cb10.id).disabled = true;
    }
    if (cb11.checked == false) {
        document.getElementById(cb12.id).disabled = true;
    }
    if (cb13.checked == false) {
        document.getElementById(cb14.id).disabled = true;
    }
    if (cb15.checked == false) {
        document.getElementById(cb16.id).disabled = true;
    }
    if (cb17.checked == false) {
        document.getElementById(cb18.id).disabled = true;
    }    
    if (cb19.checked == false) {
        document.getElementById(cb20.id).disabled = true;
    }
}

function checkdate(input) {
    var validformat = /^\d{2}\/\d{2}\/\d{4}$/ //Basic check for format validity
    var returnval = false
    if (input.value == "") {
        returnval = true
    }
    else {
        if (!validformat.test(input.value))
            alert("Invalid Date Format. Please correct and submit again.")
        else { //Detailed check for valid date ranges
            var monthfield = input.value.split("/")[0]
            var dayfield = input.value.split("/")[1]
            var yearfield = input.value.split("/")[2]
            var dayobj = new Date(yearfield, monthfield - 1, dayfield)
            if ((dayobj.getDate() != dayfield) || (dayobj.getMonth() + 1 != monthfield) || (dayobj.getFullYear() != yearfield))
                alert("Invalid Day, Month, or Year range detected. Please correct date format (MM/DD/YYYY)")
            else
                returnval = true
        }
        if (returnval == false)
        //input.select()
            setTimeout(function() { document.getElementById(input.id).focus(); }, 1);
        return returnval
    }
}

