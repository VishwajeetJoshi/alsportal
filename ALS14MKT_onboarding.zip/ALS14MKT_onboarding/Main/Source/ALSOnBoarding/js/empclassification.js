﻿function CheckConfirmbyMe(source, args) {
    var cb1 = document.getElementById("ctl00_ContentPlaceHolder1_cbConfirmbyMe");
    if (cb1.checked == false)
        args.IsValid = false;
    else
        args.IsValid = true;
}

function CheckMandatory(source, args) {
    var ddl1 = document.getElementById("ctl00_ContentPlaceHolder1_ddlEmployementType");
    var txt1 = document.getElementById("ctl00_ContentPlaceHolder1_txtTitle");
    var txt2 = document.getElementById("ctl00_ContentPlaceHolder1_txtStartDate");
    var ddl2 = document.getElementById("ctl00_ContentPlaceHolder1_ddlDepartment");

    if (ddl1.options[ddl1.selectedIndex].value == "0") {
        args.IsValid = false;
    }
    else if (ddl2.options[ddl2.selectedIndex].value == "0") {
        args.IsValid = false;
    }
    else if (txt1.value == false) {
        args.IsValid = false;
    }
    else if (txt2.value == false) {
        args.IsValid = false;
    }
    else {
        args.IsValid = true;
    }
}

function validateMessage() {
    var oldDepartment = document.getElementById("ctl00_ContentPlaceHolder1_hDepartmentValue");
    var ddlDepartment = document.getElementById("ctl00_ContentPlaceHolder1_ddlDepartment");
    var newDepartment = ddlDepartment.options[ddlDepartment.selectedIndex].value;
    var IsSecurityFix = document.getElementById("ctl00_ContentPlaceHolder1_hSecurityFix");
    if (IsSecurityFix.value == "1") {
        if (oldDepartment.value != newDepartment) {
            alert("The security process has already been completed for this employee, changing the department will NOT reset the meetings invitations. Please contact security directly.");
        }
    }
}

function checkdate(input) {
    var validformat = /^\d{2}\/\d{2}\/\d{4}$/ //Basic check for format validity
    var returnval = false
    if (input.value == "") {
        returnval = true
    }
    else {
        if (!validformat.test(input.value))
            alert("Invalid Date Format. Please correct and submit again.")
        else { //Detailed check for valid date ranges
            var monthfield = input.value.split("/")[0]
            var dayfield = input.value.split("/")[1]
            var yearfield = input.value.split("/")[2]
            var dayobj = new Date(yearfield, monthfield - 1, dayfield)
            if ((dayobj.getDate() != dayfield) || (dayobj.getMonth() + 1 != monthfield) || (dayobj.getFullYear() != yearfield))
                alert("Invalid Day, Month, or Year range detected. Please correct date format (MM/DD/YYYY)")
            else
                returnval = true
        }
        if (returnval == false)
        //input.select()
            setTimeout(function() { document.getElementById(input.id).focus(); }, 1);
        return returnval
    }
}