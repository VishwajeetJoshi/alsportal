﻿function pwdcheck() {
    var str = document.getElementById("ctl00_header_txtNewPwd").value;
    
    if (str == "") {
        return true;
    }
    var ck_pwd2 = /^[^\s]{6,20}/;
    var ck_pwd3 = /^.*[A-Z].*/;
    var ck_pwd4 = /^.*[0-9].*/;
  
    if (!ck_pwd2.test(str)) {
        alert("Password must be at least 6 charactor with combination of number and letter and at least one uppercase");
        setTimeout(function() { document.getElementById("ctl00_header_txtNewPwd").focus(); }, 1);
        return false;
    }
    else if (!ck_pwd3.test(str)) {
        alert("Password must be at least 6 charactor with combination of number and letter and at least one uppercase");
        setTimeout(function() { document.getElementById("ctl00_header_txtNewPwd").focus(); }, 1);
        return false;
    }
    else if (!ck_pwd4.test(str)) {
        alert("Password must be at least 6 charactor with combination of number and letter and at least one uppercase");
        setTimeout(function() { document.getElementById("ctl00_header_txtNewPwd").focus(); }, 1);
        return false;
    }
    return true
}

function pwdconfirm() {
    var str = document.getElementById("ctl00_header_txtNewPwd").value;
    var str1 = document.getElementById("ctl00_header_txtConfirmPwd").value;
    
    if (str1 == "") {
        return true;
    }
    if (str == str1) {
        return true
    }
    else {
        alert("Password does not match.");
        document.getElementById("ctl00_header_txtConfirmPwd").value = "";
        setTimeout(function() { document.getElementById("ctl00_header_txtConfirmPwd").focus(); }, 1);
        return false;
    }
}

function reset() {
    document.getElementById("ctl00_header_txtNewPwd").value = "";
    document.getElementById("ctl00_header_txtConfirmPwd").value = "";
}


//function pwdcheck() {
//    var str = document.getElementById("ContentPlaceHolder1_right_txtNewPwd").value;

//    if (str == "") {
//        return true;
//    }
//    var ck_pwd2 = /^[^\s]{6,20}/;
//    var ck_pwd3 = /^.*[A-Z].*/;
//    var ck_pwd4 = /^.*[0-9].*/;

//    if (!ck_pwd2.test(str)) {
//        alert("Password must be at least 6 charactor with combination of number and letter and at least one uppercase");
//        setTimeout(function() { document.getElementById("ContentPlaceHolder1_right_txtNewPwd").focus(); }, 1);
//        return false;
//    }
//    else if (!ck_pwd3.test(str)) {
//        alert("Password must be at least 6 charactor with combination of number and letter and at least one uppercase");
//        setTimeout(function() { document.getElementById("ContentPlaceHolder1_right_txtNewPwd").focus(); }, 1);
//        return false;
//    }
//    else if (!ck_pwd4.test(str)) {
//        alert("Password must be at least 6 charactor with combination of number and letter and at least one uppercase");
//        setTimeout(function() { document.getElementById("ContentPlaceHolder1_right_txtNewPwd").focus(); }, 1);
//        return false;
//    }
//    return true
//}

//function pwdconfirm() {
//    var str = document.getElementById("ContentPlaceHolder1_right_txtNewPwd").value;
//    var str1 = document.getElementById("ContentPlaceHolder1_right_txtConfirmPwd").value;

//    if (str1 == "") {
//        return true;
//    }
//    if (str == str1) {
//        return true
//    }
//    else {
//        alert("Password does not match.");
//        document.getElementById("ContentPlaceHolder1_right_txtConfirmPwd").value = "";
//        setTimeout(function() { document.getElementById("ContentPlaceHolder1_right_txtConfirmPwd").focus(); }, 1);
//        return false;
//    }
//}

//function reset() {
//    document.getElementById("ContentPlaceHolder1_right_txtNewPwd").value = "";
//    document.getElementById("ContentPlaceHolder1_right_txtConfirmPwd").value = "";
//}