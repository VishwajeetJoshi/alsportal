﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;

public partial class employeereport : System.Web.UI.Page
{
    CommonClass CC = new CommonClass();
    private string m_Mode = string.Empty;
    private bool FixMode = false;
    PagedDataSource pgsource = new PagedDataSource();
    int findex, lindex;
    DataRow dr;
    private string m_UserName = string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        if (Session["UserRole"] != null)
        {
            if (Session["UserRole"].ToString().ToLower().Contains("system admin") || Session["UserRole"].ToString().ToLower().Contains("hr"))
            { }
            else { Response.Redirect("~/loginpage.aspx?Mode=3"); }       
        }
        SetQueryStringValue();        
        if (!IsPostBack)
        {
           
        }        
    }

    private void SetQueryStringValue()
    {
        try
        {
            if (Request.QueryString["username"] != null)
            {
                m_UserName = Request.QueryString["username"];
            }           
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("employeereport.aspx", "SetQueryStringValue", ex.Message);
            m_UserName = string.Empty;
        }
    }    

    protected override void Render(HtmlTextWriter writer)
    {
        //if (Convert.ToInt32(ViewState["totpage"]) <= 1)
        //{
        //    divPaging.Visible = false;
        //}
        base.Render(writer);
    }
    protected void btnGenerateReport_Click(object sender, EventArgs e)
    {

    }
}
