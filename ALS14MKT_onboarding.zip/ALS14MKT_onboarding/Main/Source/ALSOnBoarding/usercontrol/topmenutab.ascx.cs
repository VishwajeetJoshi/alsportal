﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;


public partial class usercontrol_topmenutab : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SetUserRole();
    }

    protected void lbEmpDetails_Click(object sender, EventArgs e)
    {
        Response.Redirect("employeedetail.aspx?EmployeeID=" + Request.QueryString["EmployeeID"]);
    }
    protected void lbEmpClassification_Click(object sender, EventArgs e)
    {
        Response.Redirect("employeeclassification.aspx?EmployeeID=" + Request.QueryString["EmployeeID"]);
    }
    protected void lbIT_Click(object sender, EventArgs e)
    {
        Response.Redirect("informationtechnology.aspx?EmployeeID=" + Request.QueryString["EmployeeID"]);
    }
    protected void lbAdmin_Click(object sender, EventArgs e)
    {
        Response.Redirect("administrative.aspx?EmployeeID=" + Request.QueryString["EmployeeID"]);
    }
    protected void lbSecurity_Click(object sender, EventArgs e)
    {
        Response.Redirect("security.aspx?EmployeeID=" + Request.QueryString["EmployeeID"]);
    }
    protected void lbPayroll_Click(object sender, EventArgs e)
    {
        Response.Redirect("payroll.aspx?EmployeeID=" + Request.QueryString["EmployeeID"]);
    }
    protected void lbHRProcess_Click(object sender, EventArgs e)
    {
        Response.Redirect("finalhrprocess.aspx?EmployeeID=" + Request.QueryString["EmployeeID"]);
    }

    private void SetUserRole()
    {
        if (Session["UserRole"] != null)
        {
            li1.Visible = false;
            li2.Visible = false;
            li3.Visible = false;
            li4.Visible = false;
            li5.Visible = false;
            li6.Visible = false;
            //li7.Visible = false;
            li8.Visible = false;
            li9.Visible = false;
            li10.Visible = false;

            List<string> roleList = Session["UserRole"].ToString().Split(',').ToList();
            foreach (string item in roleList)
            {
                if (item.ToLower().Trim() == "system admin")
                {
                    li1.Visible = true;
                    li2.Visible = true;
                    li3.Visible = true;
                    li4.Visible = true;
                    li5.Visible = true;
                    li6.Visible = true;
                    //li7.Visible = true;
                    li8.Visible = true;
                    li9.Visible = true;
                    li10.Visible = true;
                }
                if (item.ToLower().Trim() == "administrative")
                {
                    li1.Visible = true;
                    li2.Visible = true;
                    li4.Visible = true;
                }
                if (item.ToLower().Trim() == "it")
                {
                    li1.Visible = true;
                    li2.Visible = true;
                    li3.Visible = true;
                }
                if (item.ToLower().Trim() == "hr")
                {
                    li1.Visible = true;
                    li2.Visible = true;
                    li3.Visible = true;
                    li4.Visible = true;
                    li5.Visible = true;
                    li6.Visible = true;
                    //li7.Visible = true;
                    li8.Visible = true;
                    li9.Visible = true;
                    li10.Visible = true;
                }
                if (item.ToLower().Trim() == "payroll")
                {
                    li1.Visible = true;
                    li2.Visible = true;
                    //li7.Visible = true;
                }
                if (item.ToLower().Trim() == "security")
                {
                    li1.Visible = true;
                    li2.Visible = true;                
                    li5.Visible = true;
                }
                if (item.ToLower().Trim() == "meeting")
                {
                    li1.Visible = true;
                    li2.Visible = true;
                    li6.Visible = true;
                }
                if (item.ToLower().Trim() == "sales & marketing")
                {
                    li1.Visible = true;
                    li2.Visible = true;
                    li9.Visible = true;
                }
                if (item.ToLower().Trim() == "performance management")
                {
                    li1.Visible = true;
                    li2.Visible = true;
                    li10.Visible = true;
                }
            }

            //if (Session["UserRole"].ToString().ToLower() == "system admin")
            //{

            //}
            //else if (Session["UserRole"].ToString().ToLower() == "hr")
            //{

            //}
            //else if (Session["UserRole"].ToString().ToLower() == "it")
            //{
            //    li4.Visible = false;
            //    li5.Visible = false;
            //    li6.Visible = false;
            //    li7.Visible = false;
            //}
            //else if (Session["UserRole"].ToString().ToLower() == "administrative")
            //{
            //    li3.Visible = false;
            //    li5.Visible = false;
            //    li6.Visible = false;
            //    li7.Visible = false;
            //}
            //else if (Session["UserRole"].ToString().ToLower() == "security")
            //{
            //    li3.Visible = false;
            //    li4.Visible = false;
            //    li6.Visible = false;
            //    li7.Visible = false;
            //}
            //else if (Session["UserRole"].ToString().ToLower() == "payroll")
            //{
            //    li3.Visible = false;
            //    li4.Visible = false;
            //    li5.Visible = false;
            //    li7.Visible = false;
            //}
        }
    }

    protected void lbMeeting_Click(object sender, EventArgs e)
    {
        Response.Redirect("Meeting.aspx?EmployeeID=" + Request.QueryString["EmployeeID"]);
    }

    protected void lbMarketing_Click(object sender, EventArgs e)
    {
        Response.Redirect("marketing.aspx?EmployeeID=" + Request.QueryString["EmployeeID"]);
    }

    protected void lbPerformance_Click(object sender, EventArgs e)
    {
        Response.Redirect("performance.aspx?EmployeeID=" + Request.QueryString["EmployeeID"]);
    }
}

