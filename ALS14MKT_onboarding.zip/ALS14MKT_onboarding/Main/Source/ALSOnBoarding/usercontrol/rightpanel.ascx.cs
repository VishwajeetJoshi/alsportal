﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;

public partial class usercontrol_rightpanel : System.Web.UI.UserControl
{
    CommonClass CC = new CommonClass();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        //lblUserName.Text = Session["UserName"].ToString();

        if (Request.RawUrl.Contains("createemployee.aspx") || Request.RawUrl.Contains("employeelisting.aspx") || Request.RawUrl.Contains("createuserview.aspx") || Request.RawUrl.Contains("createuser.aspx") || Request.RawUrl.Contains("createdepartment.aspx"))// || Request.RawUrl.Contains("createdepartmentview.aspx")
        {
            divEmpDetails.Visible = false;
        }
        else
        {
            if (Request.QueryString["EmployeeID"] != null)
            {
                FillEmployeeDetails(Request.QueryString["EmployeeID"]);
            }
        }
        if (Request.RawUrl.Contains("createuser.aspx"))
        {
            divLinkToUserListing.Visible = true;
            //divLinkToDepartmentListing.Visible = true;
        }
        if (Request.RawUrl.Contains("employeelisting.aspx"))
        {
            divLinkToEmpListing.Visible = false;
        }
        if (Request.RawUrl.Contains("createdepartment.aspx"))
        {
            divLinkToDepartmentListing.Visible = true;
            //divLinkToUserListing.Visible = true;
        }       
        //
        //ErrorMsgDiv.Visible = false;
    }

    private void FillEmployeeDetails(string empid)
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@EmployeeID", Convert.ToInt32(Server.HtmlEncode(empid)));
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetEmployeeDetails", sqlparam).Tables[0];
            if (odt.Rows.Count > 0)
            {
                sFirstName.InnerText = IfNullThenBlank(odt.Rows[0]["FirstName"].ToString());
                sLastName.InnerText = IfNullThenBlank(odt.Rows[0]["LastName"].ToString());
                sTitle.InnerText = IfNullThenBlank(odt.Rows[0]["Title"].ToString());
                sDepart.InnerText = IfNullThenBlank(odt.Rows[0]["DepartmentName"].ToString());
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("rightpanel.ascx", "FillEmployeeDetails", ex.Message);
            sFirstName.InnerText = "";
            sLastName.InnerText = "";
            sTitle.InnerText = "";
            sDepart.InnerText = "";
        }
        finally
        { con.Close(); }
    }

    private string IfNullThenBlank(string value)
    {
        if (value == null)
        {
            return "";
        }
        else if (value == "")
        {
            return "";
        }
        else
        {
            return Server.HtmlDecode(value);
        }
    }

    
    
}
