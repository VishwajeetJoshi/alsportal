﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;


public partial class usercontrol_offbdmenutab : System.Web.UI.UserControl
{
    private int m_EmployeeID;
    protected void Page_Load(object sender, EventArgs e)
    {
        SetUserRole();
        if (Request.QueryString["EmployeeID"] != null)
        {
            try
            {
                m_EmployeeID = Convert.ToInt32(Request.QueryString["EmployeeID"]);
                hlkoffbdEmpInfo.NavigateUrl = "~/offbdemployeeinfo.aspx?EmployeeID=" + m_EmployeeID;
                hlkHR.NavigateUrl = "~/offbdhr.aspx?EmployeeID=" + m_EmployeeID;
                hlkAdmin.NavigateUrl = "~/offbdadmin.aspx?EmployeeID=" + m_EmployeeID;
                hlkSalesMktg.NavigateUrl = "~/offbdsalesmktg.aspx?EmployeeID=" + m_EmployeeID;
                hlkIT.NavigateUrl = "~/offbdit.aspx?EmployeeID=" + m_EmployeeID;
                hlkFinalHRProcess.NavigateUrl = "~/offbdfinalhrprocess.aspx?EmployeeID=" + m_EmployeeID;
            }
            catch
            {
                hlkoffbdEmpInfo.NavigateUrl = "~/offbdemployeeinfo.aspx";
                hlkHR.NavigateUrl = "~/offbdhr.aspx";
                hlkAdmin.NavigateUrl = "~/offbdadmin.aspx";
                hlkSalesMktg.NavigateUrl = "~/offbdsalesmktg.aspx";
                hlkIT.NavigateUrl = "~/offbdit.aspx";
                hlkFinalHRProcess.NavigateUrl = "~/offbdfinalhrprocess.aspx";
            }

        }
        else
        {
            hlkoffbdEmpInfo.NavigateUrl = "~/offbdemployeeinfo.aspx";
            hlkHR.NavigateUrl = "~/offbdhr.aspx";
            hlkAdmin.NavigateUrl = "~/offbdadmin.aspx";
            hlkSalesMktg.NavigateUrl = "~/offbdsalesmktg.aspx";
            hlkIT.NavigateUrl = "~/offbdit.aspx";
            hlkFinalHRProcess.NavigateUrl = "~/offbdfinalhrprocess.aspx";
        }
    }

    private void SetUserRole()
    {
        if (Session["UserRole"] != null)
        {
            li1.Visible = false;
            li2.Visible = false;
            li3.Visible = false;
            li4.Visible = false;
            li5.Visible = false;
            li6.Visible = false;

            List<string> roleList = Session["UserRole"].ToString().Split(',').ToList();
            foreach (string item in roleList)
            {
                if (item.ToLower().Trim() == "system admin")
                {
                    li1.Visible = true;
                    li2.Visible = true;
                    li3.Visible = true;
                    li4.Visible = true;
                    li5.Visible = true;
                    li6.Visible = true;
                }
                else if (item.ToLower().Trim() == "administrative")
                {
                    li1.Visible = true;
                    li3.Visible = true;
                }
                else if (item.ToLower().Trim() == "it")
                {
                    li1.Visible = true;
                    li5.Visible = true;
                }
                else if (item.ToLower().Trim() == "hr")
                {
                    li1.Visible = true;
                    li2.Visible = true;
                    li3.Visible = true;
                    li4.Visible = true;
                    li5.Visible = true;
                    li6.Visible = true;
                }
                else if (item.ToLower().Trim() == "sales & marketing")
                {
                    li1.Visible = true;
                    li4.Visible = true;
                }
                else
                {
                    li1.Visible = true;
                }
            }
        }
    }
}

