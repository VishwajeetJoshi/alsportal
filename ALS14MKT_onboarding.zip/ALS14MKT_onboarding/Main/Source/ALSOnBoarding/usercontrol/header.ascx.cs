﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;
using System.Data;

public partial class usercontrol_header : System.Web.UI.UserControl
{
    CommonClass CC = new CommonClass();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.Url.ToString().Contains("offbd"))
        {
            imgOnOffbd.Src = "~/images/offboarding.png";
        }
        if (Session["UserName"] != null)
        {
            divUserInfo.Visible = true;
            sWelcome.Visible = true;
            lblUserName.Text = Session["UserName"].ToString();
        }
        else
        { divUserInfo.Visible = false; }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            string pwd = CommonClass.Encrypt(txtNewPwd.Text.Trim());
            SqlParameter[] sqlparam = new SqlParameter[]{
                                        new SqlParameter("@NewPassword", pwd),
                                        new SqlParameter("@ModifiedBy", Session["UserName"])};
            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_UpdatePassword", sqlparam);
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("rightpanel.ascx", "btnSave_Click", ex.Message);
            //lblErrorMsg.Text = "Password didn't changed due to server problem.";
            //ErrorMsgDiv.Visible = true;
        }
        finally
        {
            con.Close();
        }
    }

    protected void lbLogout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("loginpage.aspx?Mode=1");
    }
}
