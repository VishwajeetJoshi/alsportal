﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class OnBoardingMasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Request.ServerVariables["URL"].Contains("loginpage.aspx"))
        //{
        //    right.Visible = false;
        //}
        //if (Request.ServerVariables["URL"].Contains("maintabpage.aspx"))
        //{
        //    tabmenu.Visible = true;
        //}
    }
}
