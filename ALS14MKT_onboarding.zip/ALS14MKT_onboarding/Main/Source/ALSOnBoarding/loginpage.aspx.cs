﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;

public partial class loginpage : System.Web.UI.Page
{
    MailSender oMailSender = new MailSender();
    private string m_Module = string.Empty;
    private int m_EmployeeID;

    protected void Page_Load(object sender, EventArgs e)
    {       
        txtUserName.Focus();
        MsgDiv.Visible = false;
        MsgDiv1.Visible = false;

        SetQueryStringValue();
        if (!IsPostBack)
        {
            txtUserName.Focus();
            if (Request.QueryString["Mode"] == "1")
            {
                LblMsg.Text = "You are successfully logout.";
                MsgDiv.Visible = true;
                Session.Abandon();
            }
            if (Request.QueryString["Mode"] == "2")
            {
                LblMsg.Text = "Your session has expired. Please login again.";
                MsgDiv.Visible = true;
                Session.Abandon();
            }
            if (Request.QueryString["Mode"] == "3")
            {
                LblMsg.Text = "You are not authorised user to use this module.";
                MsgDiv.Visible = true;
                Session.Abandon();
            }
        }
    }

    private void SetQueryStringValue()
    {
        if (Request.QueryString["module"] != null)
        {
            m_Module = Request.QueryString["module"].ToString();
        }
        try
        {
            if (Request.QueryString["employeeid"] != null)
            {
                m_EmployeeID = Convert.ToInt32(Request.QueryString["employeeid"].ToString());
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("loginPage.aspx", "SetQueryStringValue", ex.Message);
            m_EmployeeID = 0;
        }
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter p = new SqlParameter("@UserName", Server.HtmlEncode(txtUserName.Text));
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetUserDetails", p).Tables[0];

            if (odt.Rows.Count == 0)
            {
                LblMsg.Text = "Wrong User Name or Password";
                MsgDiv.Visible = true;
            }
            else
            {
                if (odt.Rows.Count <= 0)
                {
                    LblMsg.Text = "Wrong User Name or Password";
                    MsgDiv.Visible = true;
                }
                else if (odt.Rows[0]["Password"].ToString() != CommonClass.Encrypt(Server.HtmlEncode(txtPassword.Text.Trim())))
                {
                    LblMsg.Text = "Wrong User Name or Password";
                    MsgDiv.Visible = true;
                }
                else
                {
                    Session["UserName"] = txtUserName.Text.Trim();
                    Session["UserRole"] = odt.Rows[0]["Role"].ToString();
                    Session["UserFirstLastName"] = odt.Rows[0]["FirstName"].ToString() + " " + odt.Rows[0]["LastName"].ToString();
                    if (m_Module != string.Empty)
                    {
                        if (m_EmployeeID != 0)
                        {
                            Response.Redirect(m_Module + "?EmployeeID=" + m_EmployeeID, false);
                        }
                        else
                        {
                            Response.Redirect("~/employeelisting.aspx", false);
                        }
                    }
                    else
                    {
                        Response.Redirect("~/employeelisting.aspx", false);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("loginPage.aspx", "btnLogin_Click", ex.Message);
            LblMsg.Text = "Wrong User Name or Password";
            MsgDiv.Visible = true;
        }
        finally { con.Close(); }
    }
    protected void lbforgetPwd_Click(object sender, EventArgs e)
    {
        divLoginDetails.Visible = false;
        divForgetPwd.Visible = true;
        //lblHeaderText.InnerText = "";
    }
    protected void btnSendPwd_Click(object sender, EventArgs e)
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter p = new SqlParameter("@UserName", Server.HtmlEncode(txtUserNameVerif.Text));
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetUserDetails", p).Tables[0];
            if (odt.Rows.Count > 0)
            {
                string pwd = CommonClass.Decrypt(odt.Rows[0]["Password"].ToString());
                string Name = Server.HtmlDecode(odt.Rows[0]["FirstName"].ToString()) + " " + Server.HtmlDecode(odt.Rows[0]["LastName"].ToString());

                SendMail(txtUserNameVerif.Text, pwd, Name);

                divEmailSent.Visible = true;
                divForgetPwd.Visible = false;
                divLoginDetails.Visible = false;
            }
            else
            {
                LblMsg1.Text = "This is not a valid user name.";
                MsgDiv1.Visible = true;
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("LoginPage.aspx", "btnSendPwd_Click", ex.Message);
        }
        finally
        { con.Close(); }
    }

    private void SendMail(string UserID, string Pwd, string name)
    {
        string subject = string.Empty;
        string body = string.Empty;

        //subject = "<p style='font-size:10pt;font-family:Arial;'>OnBoarding application Login Details</p>";
        subject = "OnBoarding application Login Details";
        body = "<p style='font-size:10pt;font-family:Arial;'>";
        body += "Hi " + name + ",<br />";
        body += "<br />";
        body += "Your OnBoarding application login details.<br />";
        body += "<br />";
        body += "    User Name: " + UserID + " <br />";
        body += "    Password: " + Pwd + "<br />";
        body += "<br />";
        body += "Thanks and Regards<br />";
        //body += "<br />";
        body += "Admin<br />";
        body += "</p>";
        //body += "OnBoarding Team<br />";
        //oMailSender.SendMailMessage("from", "to", "bcc", "cc", "subject", "body");
        oMailSender.SendMailMessage("support@alsbridge.com", UserID, "", "", subject, body);
    }

    protected void btnTest_Click(object sender, EventArgs e)
    {
        oMailSender.SendMailMessage("", "sandeep.kumar@bluent.net", "", "", "Test after move to live", "Testing after move to live.");
    }
}
