﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;

public partial class employeedetail : System.Web.UI.Page
{
    CommonClass CC = new CommonClass();
    private string m_Mode = string.Empty;
    private int m_EmployeeID;
    private bool FixMode = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        SetQueryStringValue();
        if (!IsPostBack)
        {
            FillDropDownList();
            FillEmployeeDetails();
        }
        MsgDiv.Visible = false;
    }

    private void FillEmployeeDetails()
    {
        PopulateDetails();

        //if (FixMode == true)
        //{
        //    EnableDisable(true);
        //    divSave.Visible = false;
        //    divBack.Visible = true;
        //}
    }

    private void SetUserRole()
    {
        if (Session["UserRole"] != null)
        {
            if (Session["UserRole"].ToString().ToLower().Contains("system admin") || Session["UserRole"].ToString().ToLower().Contains("hr"))
            {
                if (m_EmployeeID > 0)
                { divSave.Visible = true; }
                else
                { divSave.Visible = false; }
            }
            else
            { divSave.Visible = false; }            
        }
    }

    protected override void Render(HtmlTextWriter writer)
    {
        SetUserRole();
        base.Render(writer);
    }

    private void PopulateDetails()
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            if (m_EmployeeID > 0)
            {
                SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
                odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetEmployeeDetails", sqlparam).Tables[0];
                if (odt.Rows.Count > 0)
                {
                    txtLastName.Text = IfNullThenBlank(odt.Rows[0]["LastName"].ToString());
                    txtFirstName.Text = IfNullThenBlank(odt.Rows[0]["FirstName"].ToString());
                    txtMiddleInitial.Text = IfNullThenBlank(odt.Rows[0]["MiddleInitial"].ToString());
                    txtStreet.Text = IfNullThenBlank(odt.Rows[0]["StreetAddress"].ToString());
                    txtAptUnit.Text = IfNullThenBlank(odt.Rows[0]["AptUnit"].ToString());
                    txtCity.Text = IfNullThenBlank(odt.Rows[0]["City"].ToString());

                    ddlCountry.SelectedIndex = ddlCountry.Items.IndexOf(ddlCountry.Items.FindByText(odt.Rows[0]["Country"].ToString()));
                    ddlState.SelectedIndex = ddlState.Items.IndexOf(ddlState.Items.FindByText(odt.Rows[0]["State"].ToString()));
                    if (ddlState.SelectedIndex == 0 && odt.Rows[0]["State"].ToString() != "")
                    {
                        ddlState.Items.Clear();
                        ddlState.Items.Insert(0, new ListItem("-- Select One --", "0"));
                        divState.Visible = true;
                        txtOtherState.Text = odt.Rows[0]["State"].ToString();
                    }

                    txtZip.Text = IfNullThenBlank(odt.Rows[0]["PostalCode"].ToString());
                    txtHomePhone.Text = IfNullThenBlank(odt.Rows[0]["HomePhone"].ToString());
                    txtCellPhone.Text = IfNullThenBlank(odt.Rows[0]["CellPhone"].ToString());
                    txtBusinessCard.Text = IfNullThenBlank(odt.Rows[0]["BusinessCardName"].ToString());
                    txtCoEmailId.Text = IfNullThenBlank(odt.Rows[0]["CompanyEmailID"].ToString());
                    txtPerEmailId.Text = IfNullThenBlank(odt.Rows[0]["PerEmailID"].ToString());
                    txtRefLastName.Text = IfNullThenBlank(odt.Rows[0]["ConFirstName"].ToString());
                    txtRefFirstName.Text = IfNullThenBlank(odt.Rows[0]["ConLastName"].ToString());
                    txtRefMiddleInitial.Text = IfNullThenBlank(odt.Rows[0]["ConMiddleInitials"].ToString());
                    txtRefStreet.Text = IfNullThenBlank(odt.Rows[0]["ConStreetAddress"].ToString());
                    txtRefAptUnit.Text = IfNullThenBlank(odt.Rows[0]["ConAptUnit"].ToString());
                    txtRefCity.Text = IfNullThenBlank(odt.Rows[0]["ConCity"].ToString());

                    ddlRefCountry.SelectedIndex = ddlRefCountry.Items.IndexOf(ddlRefCountry.Items.FindByText(odt.Rows[0]["ConCountry"].ToString()));
                    ddlRefState.SelectedIndex = ddlRefState.Items.IndexOf(ddlRefState.Items.FindByText(odt.Rows[0]["ConState"].ToString()));
                    if (ddlRefState.SelectedIndex == 0 && odt.Rows[0]["ConState"].ToString() != "")
                    {
                        ddlRefState.Items.Clear();
                        ddlRefState.Items.Insert(0, new ListItem("-- Select One --", "0"));
                        divRefState.Visible = true;
                        txtRefOtherState.Text = odt.Rows[0]["ConState"].ToString();
                    }

                    txtRefZip.Text = IfNullThenBlank(odt.Rows[0]["ConZip"].ToString());
                    txtRefPriPhone.Text = IfNullThenBlank(odt.Rows[0]["PrimaryPhone"].ToString());
                    txtRefAltPhone.Text = IfNullThenBlank(odt.Rows[0]["AlternatePhone"].ToString());
                    txtRelationship.Text = IfNullThenBlank(odt.Rows[0]["Relationship"].ToString());

                    FixMode = (bool)odt.Rows[0]["FixMode"];
                }
            }

        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("employeedetail.aspx", "PopulateDetails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    private string IfNullThenBlank(string value)
    {
        if (value == null)
        {
            return "";
        }
        else if (value == "")
        {
            return "";
        }
        else
        {
            return Server.HtmlDecode(value);
        }
    }

    private void FillDropDownList()
    {
        //-------Fill Country
        ddlCountry.DataSource = CC.AllCountry();
        ddlCountry.DataTextField = "CountryName";
        ddlCountry.DataValueField = "CountryName";
        ddlCountry.DataBind();
        ddlCountry.Items.Insert(0, new ListItem("-- Select One --", "0"));

        //-------Fill RefCountry
        ddlRefCountry.DataSource = CC.AllCountry();
        ddlRefCountry.DataTextField = "CountryName";
        ddlRefCountry.DataValueField = "CountryName";
        ddlRefCountry.DataBind();
        ddlRefCountry.Items.Insert(0, new ListItem("-- Select One --", "0"));

        //-------Fill State
        ddlState.DataSource = CC.USState();
        ddlState.DataTextField = "StateName";
        ddlState.DataValueField = "StateID";
        ddlState.DataBind();
        ddlState.Items.Insert(0, new ListItem("-- Select One --", "0"));

        //-------Fill RefState
        ddlRefState.DataSource = CC.USState();
        ddlRefState.DataTextField = "StateName";
        ddlRefState.DataValueField = "StateID";
        ddlRefState.DataBind();
        ddlRefState.Items.Insert(0, new ListItem("-- Select One --", "0"));
    }

    private void SetQueryStringValue()
    {
        try
        {
            if (Request.QueryString["EmployeeID"] != null)
            {
                m_EmployeeID = Convert.ToInt32(Request.QueryString["EmployeeID"]);
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("employeedetail.aspx", "SetQueryStringValue", ex.Message);
            m_Mode = "Add";
            m_EmployeeID = 0;
        }
    }

    private void Reset()
    {
        txtLastName.Text = "";
        txtFirstName.Text = "";
        txtMiddleInitial.Text = "";
        txtStreet.Text = "";
        txtAptUnit.Text = "";
        txtCity.Text = "";
        ddlCountry.SelectedIndex = 0;
        ddlState.SelectedIndex = 0;
        divState.Visible = false;
        txtZip.Text = "";
        txtHomePhone.Text = "";
        txtCellPhone.Text = "";
        txtBusinessCard.Text = "";
        txtCoEmailId.Text = "";
        txtPerEmailId.Text = "";
        txtRefLastName.Text = "";
        txtRefFirstName.Text = "";
        txtRefMiddleInitial.Text = "";
        txtRefStreet.Text = "";
        txtRefAptUnit.Text = "";
        txtRefCity.Text = "";
        ddlRefCountry.SelectedIndex = 0;
        ddlRefState.SelectedIndex = 0;
        divRefState.Visible = false;
        txtRefZip.Text = "";
        txtRefPriPhone.Text = "";
        txtRefAltPhone.Text = "";
        txtRelationship.Text = "";
    }

    private void EnableDisable(bool boolValue)
    {
        txtLastName.ReadOnly = boolValue;
        txtFirstName.ReadOnly = boolValue;
        txtMiddleInitial.ReadOnly = boolValue;
        txtStreet.ReadOnly = boolValue;
        txtAptUnit.ReadOnly = boolValue;
        txtCity.ReadOnly = boolValue;
        //txtState.ReadOnly = boolValue;
        txtZip.ReadOnly = boolValue;
        txtHomePhone.ReadOnly = boolValue;
        txtCellPhone.ReadOnly = boolValue;
        txtBusinessCard.ReadOnly = boolValue;
        txtCoEmailId.ReadOnly = boolValue;
        txtPerEmailId.ReadOnly = boolValue;
        txtRefLastName.ReadOnly = boolValue;
        txtRefFirstName.ReadOnly = boolValue;
        txtRefMiddleInitial.ReadOnly = boolValue;
        txtRefStreet.ReadOnly = boolValue;
        txtRefAptUnit.ReadOnly = boolValue;
        txtRefCity.ReadOnly = boolValue;
        //txtRefState.ReadOnly = boolValue;
        txtRefZip.ReadOnly = boolValue;
        txtRefPriPhone.ReadOnly = boolValue;
        txtRefAltPhone.ReadOnly = boolValue;
        txtRelationship.ReadOnly = boolValue;
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        string state = string.Empty;
        string refState = string.Empty;
        string country = string.Empty;
        string refcountry = string.Empty;

        if (ValidateRecord() == false)
        {
            MsgDiv.Visible = true;
            return;
        }

        if (ddlCountry.SelectedIndex != 0)
        {
            country = ddlCountry.SelectedItem.ToString();
            if (ddlCountry.SelectedItem.ToString().ToUpper() == "USA")
            {
                if (ddlState.SelectedIndex != 0)
                {
                    state = ddlState.SelectedItem.ToString();
                }
            }
            else
            {
                if (txtOtherState.Text != "")
                {
                    state = txtOtherState.Text;
                }
            }
        }
        else
        {
            if (ddlState.SelectedIndex != 0)
            {
                state = ddlState.SelectedItem.ToString();
            }
        }

        if (ddlRefCountry.SelectedIndex != 0)
        {
            refcountry = ddlRefCountry.SelectedItem.ToString();
            if (ddlRefCountry.SelectedItem.ToString().ToUpper() == "USA")
            {
                if (ddlRefState.SelectedIndex != 0)
                {
                    refState = ddlRefState.SelectedItem.ToString();
                }
            }
            else
            {
                if (txtRefOtherState.Text != "")
                {
                    refState = txtRefOtherState.Text;
                }
            }
        }
        else
        {
            if (ddlRefState.SelectedIndex != 0)
            {
                refState = ddlRefState.SelectedItem.ToString();
            }
        }

        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@Mode", "edit"),
                                    new SqlParameter("@EmployeeID", m_EmployeeID),
                                    new SqlParameter("@FirstName", Server.HtmlEncode(txtFirstName.Text)),
                                    new SqlParameter("@LastName", Server.HtmlEncode(txtLastName.Text)),
                                    new SqlParameter("@MiddleInitial", Server.HtmlEncode(txtMiddleInitial.Text)),
                                    new SqlParameter("@Street", Server.HtmlEncode(txtStreet.Text)),
                                    new SqlParameter("@AptUnit", Server.HtmlEncode(txtAptUnit.Text)),
                                    new SqlParameter("@City", Server.HtmlEncode(txtCity.Text)),
                                    new SqlParameter("@Country", country),                                    
                                    new SqlParameter("@State", state),
                                    new SqlParameter("@PostalCode", Server.HtmlEncode(txtZip.Text)),
                                    new SqlParameter("@HomePhone", Server.HtmlEncode(txtHomePhone.Text)),
                                    new SqlParameter("@CellPhone", Server.HtmlEncode(txtCellPhone.Text)),
                                    new SqlParameter("@BusinessCardName", Server.HtmlEncode(txtBusinessCard.Text)),
                                    new SqlParameter("@PerEmailID", Server.HtmlEncode(txtPerEmailId.Text)),
                                    new SqlParameter("@CompanyEmailID", Server.HtmlEncode(txtCoEmailId.Text)),
                                    new SqlParameter("@ConFirstName", Server.HtmlEncode(txtRefFirstName.Text)),
                                    new SqlParameter("@ConLastName", Server.HtmlEncode(txtRefLastName.Text)),
                                    new SqlParameter("@ConMiddleInitial", Server.HtmlEncode(txtRefMiddleInitial.Text)),
                                    new SqlParameter("@ConStreet", Server.HtmlEncode(txtRefStreet.Text)),
                                    new SqlParameter("@ConAptUnit", Server.HtmlEncode(txtRefAptUnit.Text)),
                                    new SqlParameter("@ConCity", Server.HtmlEncode(txtRefCity.Text)),
                                    new SqlParameter("@ConCountry", refcountry),            
                                    new SqlParameter("@ConState", refState),
                                    new SqlParameter("@ConPostalCode", Server.HtmlEncode(txtRefZip.Text)),
                                    new SqlParameter("@ConPriPhone", Server.HtmlEncode(txtRefPriPhone.Text)),
                                    new SqlParameter("@ConAltPhone", Server.HtmlEncode(txtRefAltPhone.Text)),
                                    new SqlParameter("@Relationship", Server.HtmlEncode(txtRelationship.Text)),
                                    new SqlParameter("@FixMode", false),
                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEmployeeDetails", sqlparam);
            LblMsg.Text = "Record was updated successfully";
            MsgDiv.Visible = true;
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("employeedetail.aspx", "btnSave_Click", ex.Message);
            LblMsg.Text = "Oops! Server problem....try after some time";
            MsgDiv.Visible = true;
        }
        finally { con.Close(); }
    }

    private bool ValidateRecord()
    {
        if (txtPerEmailId.Text != "")
        {
            SqlConnection sqlcon = SqlHelper.GetConnection();
            sqlcon.Open();
            try
            {
                DataTable odt = new DataTable();
                odt = SqlHelper.ExecuteDataset(sqlcon, CommandType.Text, "Select * from Employee.EmployeeDetails Where EmployeeID <> '" + m_EmployeeID + "' and PerEmailID = '" + Server.HtmlEncode(txtPerEmailId.Text.Trim()) + "'").Tables[0];
                if (odt.Rows.Count > 0)
                {
                    LblMsg.Text = "This emailid already exist. You cannot enter duplicate emailid.";
                    return false;
                }
            }
            catch (Exception ex)
            { }
            finally { sqlcon.Close(); }
            return true;
        }
        else
        {
            return true;
        }
    }

    //protected void btnSaveSubmit_Click(object sender, EventArgs e)
    //{
    //    string state = string.Empty;
    //    string refState = string.Empty;

    //    if (ddlState.SelectedIndex != 0)
    //    {
    //        state = ddlState.SelectedItem.ToString();
    //    }
    //    if (ddlRefState.SelectedIndex != 0)
    //    {
    //        refState = ddlRefState.SelectedItem.ToString();
    //    }

    //    SqlConnection con = SqlHelper.GetConnection();
    //    con.Open();
    //    try
    //    {
    //        SqlParameter[] sqlparam = new SqlParameter[] { 
    //                                new SqlParameter("@Mode", "edit"),
    //                                new SqlParameter("@EmployeeID", m_EmployeeID),
    //                                new SqlParameter("@FirstName", Server.HtmlEncode(txtFirstName.Text)),
    //                                new SqlParameter("@LastName", Server.HtmlEncode(txtLastName.Text)),
    //                                new SqlParameter("@MiddleInitial", Server.HtmlEncode(txtMiddleInitial.Text)),
    //                                new SqlParameter("@Street", Server.HtmlEncode(txtStreet.Text)),
    //                                new SqlParameter("@AptUnit", Server.HtmlEncode(txtAptUnit.Text)),
    //                                new SqlParameter("@City", Server.HtmlEncode(txtCity.Text)),                                    
    //                                new SqlParameter("@State", state),
    //                                new SqlParameter("@PostalCode", Server.HtmlEncode(txtZip.Text)),
    //                                new SqlParameter("@HomePhone", Server.HtmlEncode(txtHomePhone.Text)),
    //                                new SqlParameter("@CellPhone", Server.HtmlEncode(txtCellPhone.Text)),
    //                                new SqlParameter("@BusinessCardName", Server.HtmlEncode(txtBusinessCard.Text)),
    //                                new SqlParameter("@PerEmailID", Server.HtmlEncode(txtPerEmailId.Text)),
    //                                new SqlParameter("@CompanyEmailID", Server.HtmlEncode(txtCoEmailId.Text)),
    //                                new SqlParameter("@ConFirstName", Server.HtmlEncode(txtRefFirstName.Text)),
    //                                new SqlParameter("@ConLastName", Server.HtmlEncode(txtRefLastName.Text)),
    //                                new SqlParameter("@ConMiddleInitial", Server.HtmlEncode(txtRefMiddleInitial.Text)),
    //                                new SqlParameter("@ConStreet", Server.HtmlEncode(txtRefStreet.Text)),
    //                                new SqlParameter("@ConAptUnit", Server.HtmlEncode(txtRefAptUnit.Text)),
    //                                new SqlParameter("@ConCity", Server.HtmlEncode(txtRefCity.Text)),
    //                                new SqlParameter("@ConState", refState),
    //                                new SqlParameter("@ConPostalCode", Server.HtmlEncode(txtRefZip.Text)),
    //                                new SqlParameter("@ConPriPhone", Server.HtmlEncode(txtRefPriPhone.Text)),
    //                                new SqlParameter("@ConAltPhone", Server.HtmlEncode(txtRefAltPhone.Text)),
    //                                new SqlParameter("@Relationship", Server.HtmlEncode(txtRelationship.Text)),
    //                                new SqlParameter("@FixMode", 1),
    //                                new SqlParameter("@CreatedBy", Session["UserName"]),
    //                                new SqlParameter("@ModifiedBy", Session["UserName"])};

    //        SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEmployeeDetails", sqlparam);
    //        LblMsg.Text = "Record was updated successfully";
    //        MsgDiv.Visible = true;

    //        //if (m_Mode.ToLower() == "edit")
    //        //    FillEmployeeDetails("edit");
    //        //else if (m_Mode.ToLower() == "add")
    //        //    FillEmployeeDetails("add");
    //    }
    //    catch (Exception ex)
    //    {
    //        CommonClass.AddErrorTrail("employeedetail.aspx", "btnSave_Click", ex.Message);
    //        LblMsg.Text = "Oops! Server problem....try after some time";
    //        MsgDiv.Visible = true;
    //    }
    //    finally { con.Close(); }
    //}

    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("employeelisting.aspx");
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Reset();
    }

    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        string state = string.Empty;
        if (ddlCountry.SelectedIndex != 0)
        {
            if (ddlCountry.SelectedItem.ToString().ToUpper() == "USA")
            {
                if (ddlState.SelectedIndex != 0)
                {
                    state = ddlState.SelectedItem.ToString();
                }
                ddlState.DataSource = CC.USState();
                ddlState.DataTextField = "StateName";
                ddlState.DataValueField = "StateID";
                ddlState.DataBind();
                ddlState.Items.Insert(0, new ListItem("-- Select One --", "0"));
                if (state != string.Empty)
                {
                    ddlState.SelectedIndex = ddlState.Items.IndexOf(ddlState.Items.FindByText(state));
                }
                divState.Visible = false;
                txtOtherState.Text = "";
            }
            else
            {
                ddlState.Items.Clear();
                ddlState.Items.Insert(0, new ListItem("-- Select One --", "0"));
                divState.Visible = true;
            }
        }
        else
        {
            ddlState.SelectedIndex = 0;
            divState.Visible = false;
            txtOtherState.Text = "";
        }
    }

    protected void ddlRefCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        string state = string.Empty;
        if (ddlRefCountry.SelectedIndex != 0)
        {
            if (ddlRefCountry.SelectedItem.ToString().ToUpper() == "USA")
            {
                if (ddlRefState.SelectedIndex != 0)
                {
                    state = ddlRefState.SelectedItem.ToString();
                }
                ddlRefState.DataSource = CC.USState();
                ddlRefState.DataTextField = "StateName";
                ddlRefState.DataValueField = "StateID";
                ddlRefState.DataBind();
                ddlRefState.Items.Insert(0, new ListItem("-- Select One --", "0"));
                if (state != string.Empty)
                {
                    ddlRefState.SelectedIndex = ddlRefState.Items.IndexOf(ddlState.Items.FindByText(state));
                }
                divRefState.Visible = false;
                txtRefOtherState.Text = "";
            }
            else
            {
                ddlRefState.Items.Clear();
                ddlRefState.Items.Insert(0, new ListItem("-- Select One --", "0"));
                divRefState.Visible = true;
            }
        }
        else
        {
            ddlRefState.SelectedIndex = 0;
            divRefState.Visible = false;
            txtRefOtherState.Text = "";
        }
    }
}
