﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;
using System.Globalization;

public partial class marketing : System.Web.UI.Page
{
    CommonClass CC = new CommonClass();
    private string m_Mode = string.Empty;
    private int m_EmployeeID;
    private bool FixMode = false;
    MailSender oMailSender = new MailSender();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        SetQueryStringValue();

        if (!IsPostBack)
        {
            FillMarketingDetails();
        }
        MsgDiv.Visible = false;
        MsgDiv1.Visible = false;
    }

    private void SetQueryStringValue()
    {
        try
        {
            if (Request.QueryString["EmployeeID"] != null)
            {
                m_EmployeeID = Convert.ToInt32(Request.QueryString["EmployeeID"]);
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("marketing.aspx", "SetQueryStringValue", ex.Message);
            m_Mode = "Add";
            m_EmployeeID = 0;
        }
    }

    private void SetUserRole()
    {
        if (Session["UserRole"] != null)
        {
            if (m_EmployeeID > 0)
            {
                divSave.Visible = true;
                divSaveSales.Visible = true;
            }
            else
            { divSave.Visible = false; divSaveSales.Visible = false; }
        }
    }

    protected override void Render(HtmlTextWriter writer)
    {
        SetUserRole();
        base.Render(writer);
    }

    private void FillMarketingDetails()
    {
        PopulateDetails();
        if (FixMode == true)
        {
            EnableDisable(true);
            divSave.Visible = false;
        }
    }

    private void PopulateDetails()
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetMarketingDetails", sqlparam).Tables[0];
            if (odt.Rows.Count > 0)
            {
                //cbYesSubscribeSL.Checked = CC.IfNullThenZero(odt.Rows[0]["YesSubscribeSL"].ToString());
                //cbYesSubscribeOC.Checked = CC.IfNullThenZero(odt.Rows[0]["YesSubscribeOC"].ToString());
                //cbYesBIOWebsite.Checked = CC.IfNullThenZero(odt.Rows[0]["YesBIOWebsite"].ToString());

                cbYesBIOUpload.Checked = CC.IfNullThenZero(odt.Rows[0]["YesBIOUpload"].ToString());
                cbConfirmBIOUpload.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmBIOUpload"].ToString());
                cbDeclinedBIOUpload.Checked = CC.IfNullThenZero(odt.Rows[0]["DeclinedBIOUpload"].ToString());

                cbYesPressRelease.Checked = CC.IfNullThenZero(odt.Rows[0]["YesPressRelease"].ToString());
                cbConfirmPressRelease.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmPressRelease"].ToString());
                cbDeclinedPressRelease.Checked = CC.IfNullThenZero(odt.Rows[0]["DeclinedPressRelease"].ToString());

                cbYesImportSF.Checked = CC.IfNullThenZero(odt.Rows[0]["YesImportSF"].ToString());
                cbConfirmImportSF.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmImportSF"].ToString());
                cbDeclinedImportSF.Checked = CC.IfNullThenZero(odt.Rows[0]["DeclinedImportSF"].ToString());

                //cbConfirmSubscribeSL.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmSubscribeSL"].ToString());
                //cbConfirmSubscribeOC.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmSubscribeOC"].ToString());
                //if (CC.CheckDDLValue(odt.Rows[0]["ConfirmBIOWebsite"].ToString()) != "")
                //{ ddlBIOWebsite.SelectedIndex = Convert.ToInt32(CC.CheckDDLValue(odt.Rows[0]["ConfirmBIOWebsite"].ToString())); }
                
                cbYesSalesforceTraining.Checked = CC.IfNullThenZero(odt.Rows[0]["YesSalesforceTraining"].ToString());
                cbConfirmSalesforceTraining.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmSalesforceTraining"].ToString());
                cbDeclinedSalesforceTraining.Checked = CC.IfNullThenZero(odt.Rows[0]["DeclinedSalesforceTraining"].ToString());

                //cbYesWikiTraining.Checked = CC.IfNullThenZero(odt.Rows[0]["YesWikiTraining"].ToString());
                //cbConfirmWikiTraining.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmWikiTraining"].ToString());
                //cbDeclinedWikiTraining.Checked = CC.IfNullThenZero(odt.Rows[0]["DeclinedWikiTraining"].ToString());

                //New fields added on 140814
                //cbYesPhotoUploaded.Checked = CC.IfNullThenZero(odt.Rows[0]["YesPhotoUploaded"].ToString());
                //cbConfirmPhotoUploaded.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmPhotoUploaded"].ToString());
                //cbDeclinedPhotoUploaded.Checked = CC.IfNullThenZero(odt.Rows[0]["DeclinedPhotoUploaded"].ToString());

                cbYesMarketingOverview.Checked = CC.IfNullThenZero(odt.Rows[0]["YesMarketingOverview"].ToString());
                cbConfirmMarketingOverview.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmMarketingOverview"].ToString());
                cbDeclinedMarketingOverview.Checked = CC.IfNullThenZero(odt.Rows[0]["DeclinedMarketingOverview"].ToString());

                cbYesLinkedinProfile.Checked = CC.IfNullThenZero(odt.Rows[0]["YesLinkedinProfile"].ToString());
                cbConfirmLinkedinProfile.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmLinkedinProfile"].ToString());
                cbDeclinedLinkedinProfile.Checked = CC.IfNullThenZero(odt.Rows[0]["DeclinedLinkedinProfile"].ToString());

                cbYesSalesSupportTraining.Checked = CC.IfNullThenZero(odt.Rows[0]["YesSalesSupportTraining"].ToString());
                cbConfirmSalesSupportTraining.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmSalesSupportTraining"].ToString());
                cbDeclinedSalesSupportTraining.Checked = CC.IfNullThenZero(odt.Rows[0]["DeclinedSalesSupportTraining"].ToString());

                cbYesSolutionsDevOverview.Checked = CC.IfNullThenZero(odt.Rows[0]["YesSolutionsDevOverview"].ToString());
                cbConfirmSolutionsDevOverview.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmSolutionsDevOverview"].ToString());
                cbDeclinedSolutionsDevOverview.Checked = CC.IfNullThenZero(odt.Rows[0]["DeclinedSolutionsDevOverview"].ToString());

                //FixMode = (bool)odt.Rows[0]["FixMode"];
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("marketing.aspx", "PopulateDetails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    private string IfNullThenBlank(string value)
    {
        if (value == null)
        {
            return "";
        }
        else if (value == "")
        {
            return "";
        }
        else
        {
            return Server.HtmlDecode(value);
        }
    }

    private void Reset()
    {
        cbYesBIOUpload.Checked = false;
        cbYesImportSF.Checked = false;
        cbConfirmBIOUpload.Checked = false;
        cbConfirmImportSF.Checked = false;
        cbYesPressRelease.Checked = false;
        cbConfirmPressRelease.Checked = false;
        //cbYesSalesforceTraining.Checked = false;
        //cbConfirmSalesforceTraining.Checked = false;
        //cbYesWikiTraining.Checked = false;
        //cbConfirmWikiTraining.Checked = false;
        cbDeclinedBIOUpload.Checked = false;
        cbDeclinedPressRelease.Checked = false;
        cbDeclinedImportSF.Checked = false;

        //cbYesPhotoUploaded.Checked = false;
        //cbConfirmPhotoUploaded.Checked = false;
        //cbDeclinedPhotoUploaded.Checked = false;

        cbYesMarketingOverview.Checked = false;
        cbConfirmMarketingOverview.Checked = false;
        cbDeclinedMarketingOverview.Checked = false;

        cbYesLinkedinProfile.Checked = false;
        cbConfirmLinkedinProfile.Checked = false;
        cbDeclinedLinkedinProfile.Checked = false;

    }

    private void EnableDisable(bool boolValue)
    {
        //cbSubscribeSL.Checked = false;
        //cbSubscribeOC.Checked = false;
        //ddlBIOWebsite.SelectedIndex = 0;
        //cbBIOUpload.Checked = false;
        //cbImportSF.Checked = false;
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        //new SqlParameter("@YesSalesforceTraining", CC.CheckBoxValue(cbYesSalesforceTraining)),
        //new SqlParameter("@ConfirmSalesforceTraining", CC.CheckBoxValue(cbConfirmSalesforceTraining)),
        //new SqlParameter("@YesWikiTraining", CC.CheckBoxValue(cbYesWikiTraining)),
        //new SqlParameter("@ConfirmWikiTraining", CC.CheckBoxValue(cbConfirmWikiTraining)),

        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@Mode", "marketing"),
                                    new SqlParameter("@EmployeeID", m_EmployeeID),
                                    new SqlParameter("@YesBIOUpload", CC.CheckBoxValue(cbYesBIOUpload)),
                                    new SqlParameter("@YesImportSF", CC.CheckBoxValue(cbYesImportSF)),
                                    new SqlParameter("@ConfirmBIOUpload", CC.CheckBoxValue(cbConfirmBIOUpload)),
                                    new SqlParameter("@ConfirmImportSF", CC.CheckBoxValue(cbConfirmImportSF)),
                                    new SqlParameter("@YesPressRelease", CC.CheckBoxValue(cbYesPressRelease)),
                                    new SqlParameter("@ConfirmPressRelease", CC.CheckBoxValue(cbConfirmPressRelease)),
                                    new SqlParameter("@DeclinedBIOUpload", CC.CheckBoxValue(cbDeclinedBIOUpload)),
                                    new SqlParameter("@DeclinedImportSF", CC.CheckBoxValue(cbDeclinedImportSF)),
                                    new SqlParameter("@DeclinedPressRelease", CC.CheckBoxValue(cbDeclinedPressRelease)),
                                    //new added fields on 140814
                                    //new SqlParameter("@YesPhotoUploaded", CC.CheckBoxValue(cbYesPhotoUploaded)),
                                    //new SqlParameter("@ConfirmPhotoUploaded", CC.CheckBoxValue(cbConfirmPhotoUploaded)),
                                    //new SqlParameter("@DeclinedPhotoUploaded", CC.CheckBoxValue(cbDeclinedPhotoUploaded)),

                                    new SqlParameter("@YesMarketingOverview", CC.CheckBoxValue(cbYesMarketingOverview)),
                                    new SqlParameter("@ConfirmMarketingOverview", CC.CheckBoxValue(cbConfirmMarketingOverview)),
                                    new SqlParameter("@DeclinedMarketingOverview", CC.CheckBoxValue(cbDeclinedMarketingOverview)),

                                    new SqlParameter("@YesLinkedinProfile", CC.CheckBoxValue(cbYesLinkedinProfile)),
                                    new SqlParameter("@ConfirmLinkedinProfile", CC.CheckBoxValue(cbConfirmLinkedinProfile)),
                                    new SqlParameter("@DeclinedLinkedinProfile", CC.CheckBoxValue(cbDeclinedLinkedinProfile)),                                    

                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditMarketingDetails", sqlparam);
            LblMsg.Text = "Record was updated successfully";
            MsgDiv.Visible = true;
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("marketing.aspx", "btnSave_Click", ex.Message);
            LblMsg.Text = "Oops! Server problem....try after some time";
            MsgDiv.Visible = true;
        }
        finally { con.Close(); }
    }
    protected void btnSaveSubmit_Click(object sender, EventArgs e)
    {
        //new SqlParameter("@YesSalesforceTraining", CC.CheckBoxValue(cbYesSalesforceTraining)),
        //new SqlParameter("@ConfirmSalesforceTraining", CC.CheckBoxValue(cbConfirmSalesforceTraining)),
        //new SqlParameter("@YesWikiTraining", CC.CheckBoxValue(cbYesWikiTraining)),
        //new SqlParameter("@ConfirmWikiTraining", CC.CheckBoxValue(cbConfirmWikiTraining)),
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@Mode", "marketing"),
                                    new SqlParameter("@EmployeeID", m_EmployeeID),
                                    new SqlParameter("@YesBIOUpload", CC.CheckBoxValue(cbYesBIOUpload)),
                                    new SqlParameter("@YesImportSF", CC.CheckBoxValue(cbYesImportSF)),
                                    new SqlParameter("@ConfirmBIOUpload", CC.CheckBoxValue(cbConfirmBIOUpload)),
                                    new SqlParameter("@ConfirmImportSF", CC.CheckBoxValue(cbConfirmImportSF)),
                                    new SqlParameter("@YesPressRelease", CC.CheckBoxValue(cbYesPressRelease)),
                                    new SqlParameter("@ConfirmPressRelease", CC.CheckBoxValue(cbConfirmPressRelease)),                                    
                                    new SqlParameter("@DeclinedBIOUpload", CC.CheckBoxValue(cbDeclinedBIOUpload)),
                                    new SqlParameter("@DeclinedImportSF", CC.CheckBoxValue(cbDeclinedImportSF)),
                                    new SqlParameter("@DeclinedPressRelease", CC.CheckBoxValue(cbDeclinedPressRelease)),
                                    //new added fields on 140814
                                    //new SqlParameter("@YesPhotoUploaded", CC.CheckBoxValue(cbYesPhotoUploaded)),
                                    //new SqlParameter("@ConfirmPhotoUploaded", CC.CheckBoxValue(cbConfirmPhotoUploaded)),
                                    //new SqlParameter("@DeclinedPhotoUploaded", CC.CheckBoxValue(cbDeclinedPhotoUploaded)),

                                    new SqlParameter("@YesMarketingOverview", CC.CheckBoxValue(cbYesMarketingOverview)),
                                    new SqlParameter("@ConfirmMarketingOverview", CC.CheckBoxValue(cbConfirmMarketingOverview)),
                                    new SqlParameter("@DeclinedMarketingOverview", CC.CheckBoxValue(cbDeclinedMarketingOverview)),

                                    new SqlParameter("@YesLinkedinProfile", CC.CheckBoxValue(cbYesLinkedinProfile)),
                                    new SqlParameter("@ConfirmLinkedinProfile", CC.CheckBoxValue(cbConfirmLinkedinProfile)),
                                    new SqlParameter("@DeclinedLinkedinProfile", CC.CheckBoxValue(cbDeclinedLinkedinProfile)),

                                    new SqlParameter("@FixMode", 1),
                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditMarketingDetails", sqlparam);
            LblMsg.Text = "Record was updated successfully";
            MsgDiv.Visible = true;
            AlertMails("Marketing");
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("marketing.aspx", "btnSave_Click", ex.Message);
            LblMsg.Text = "Oops! Server problem....try after some time";
            MsgDiv.Visible = true;
        }
        finally { con.Close(); }
    }

    private void AlertMails(string department)
    {
        string AbsoluteUri = string.Empty;
        string CurrentFilePath = string.Empty;
        string QueryString = string.Empty;
        string EmployeeName = string.Empty;
        //oMailSender
        DataTable odt = new DataTable();
        DataTable odt1 = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            AbsoluteUri = Request.Url.AbsoluteUri.ToString();
            CurrentFilePath = Request.AppRelativeCurrentExecutionFilePath.ToString();
            CurrentFilePath = CurrentFilePath.Remove(0, 2);
            QueryString = Request.QueryString.ToString();
            AbsoluteUri = AbsoluteUri.Replace(CurrentFilePath + "?" + QueryString, "");
            AbsoluteUri = AbsoluteUri + "loginpage.aspx?";

            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt1 = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetEmployeeDetails", sqlparam).Tables[0];
            if (odt1.Rows.Count > 0)
            {
                if (odt1.Rows[0]["Country"].ToString().ToLower() == "india")
                { return; }
                EmployeeName = odt1.Rows[0]["FirstName"].ToString() + " " + odt1.Rows[0]["LastName"].ToString();
            }
            else
            { return; }

            string query = string.Empty;
            query = "Select * from Users where Role = 'hr'";
            odt = SqlHelper.ExecuteDataset(con, CommandType.Text, query).Tables[0];

            if (odt.Rows.Count > 0)
            {
                for (int i = 0; i < odt.Rows.Count; i++)
                {
                    oMailSender.SendMailToHR(odt.Rows[i]["UserName"].ToString(), odt.Rows[i]["Role"].ToString(), AbsoluteUri, odt.Rows[i]["FirstName"].ToString() + " " + odt.Rows[i]["LastName"].ToString(), EmployeeName, department);
                }
            }
            //CC.SendMailToHrIfAllSectionComplete(m_EmployeeID, EmployeeName);
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("marketing.aspx", "AlertMails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Reset();
    }

    protected void btnSaveSales_Click(object sender, EventArgs e)
    {
        //new SqlParameter("@YesBIOUpload", CC.CheckBoxValue(cbYesBIOUpload)),
        //new SqlParameter("@YesImportSF", CC.CheckBoxValue(cbYesImportSF)),
        //new SqlParameter("@ConfirmBIOUpload", CC.CheckBoxValue(cbConfirmBIOUpload)),
        //new SqlParameter("@ConfirmImportSF", CC.CheckBoxValue(cbConfirmImportSF)),
        //new SqlParameter("@YesPressRelease", CC.CheckBoxValue(cbYesPressRelease)),
        //new SqlParameter("@ConfirmPressRelease", CC.CheckBoxValue(cbConfirmPressRelease)),
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@Mode", "sales"),
                                    new SqlParameter("@EmployeeID", m_EmployeeID),
                                    
                                    new SqlParameter("@YesSalesforceTraining", CC.CheckBoxValue(cbYesSalesforceTraining)),
                                    new SqlParameter("@ConfirmSalesforceTraining", CC.CheckBoxValue(cbConfirmSalesforceTraining)),
                                    //new SqlParameter("@YesWikiTraining", CC.CheckBoxValue(cbYesWikiTraining)),
                                    //new SqlParameter("@ConfirmWikiTraining", CC.CheckBoxValue(cbConfirmWikiTraining)),

                                    new SqlParameter("@DeclinedSalesforceTraining", CC.CheckBoxValue(cbDeclinedSalesforceTraining)),
                                    //new SqlParameter("@DeclinedWikiTraining", CC.CheckBoxValue(cbDeclinedWikiTraining)),

                                    new SqlParameter("@YesSalesSupportTraining", CC.CheckBoxValue(cbYesSalesSupportTraining)),
                                    new SqlParameter("@ConfirmSalesSupportTraining", CC.CheckBoxValue(cbConfirmSalesSupportTraining)),
                                    new SqlParameter("@DeclinedSalesSupportTraining", CC.CheckBoxValue(cbDeclinedSalesSupportTraining)),

                                    new SqlParameter("@YesSolutionsDevOverview", CC.CheckBoxValue(cbYesSolutionsDevOverview)),
                                    new SqlParameter("@ConfirmSolutionsDevOverview", CC.CheckBoxValue(cbConfirmSolutionsDevOverview)),
                                    new SqlParameter("@DeclinedSolutionsDevOverview", CC.CheckBoxValue(cbDeclinedSolutionsDevOverview)),

                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditMarketingDetails", sqlparam);
            LblMsg1.Text = "Record was updated successfully";
            MsgDiv1.Visible = true;
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("marketing.aspx", "btnSave_Click", ex.Message);
            LblMsg.Text = "Oops! Server problem....try after some time";
            MsgDiv1.Visible = true;
        }
        finally { con.Close(); }
    }

    protected void btnSaveSubmitSales_Click(object sender, EventArgs e)
    {
        //new SqlParameter("@YesBIOUpload", CC.CheckBoxValue(cbYesBIOUpload)),
        //new SqlParameter("@YesImportSF", CC.CheckBoxValue(cbYesImportSF)),
        //new SqlParameter("@ConfirmBIOUpload", CC.CheckBoxValue(cbConfirmBIOUpload)),
        //new SqlParameter("@ConfirmImportSF", CC.CheckBoxValue(cbConfirmImportSF)),
        //new SqlParameter("@YesPressRelease", CC.CheckBoxValue(cbYesPressRelease)),
        //new SqlParameter("@ConfirmPressRelease", CC.CheckBoxValue(cbConfirmPressRelease)),
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@Mode", "sales"),
                                    new SqlParameter("@EmployeeID", m_EmployeeID),
                                   
                                    new SqlParameter("@YesSalesforceTraining", CC.CheckBoxValue(cbYesSalesforceTraining)),
                                    new SqlParameter("@ConfirmSalesforceTraining", CC.CheckBoxValue(cbConfirmSalesforceTraining)),
                                    //new SqlParameter("@YesWikiTraining", CC.CheckBoxValue(cbYesWikiTraining)),
                                    //new SqlParameter("@ConfirmWikiTraining", CC.CheckBoxValue(cbConfirmWikiTraining)),

                                    new SqlParameter("@DeclinedSalesforceTraining", CC.CheckBoxValue(cbDeclinedSalesforceTraining)),
                                    //new SqlParameter("@DeclinedWikiTraining", CC.CheckBoxValue(cbDeclinedWikiTraining)),

                                    new SqlParameter("@YesSalesSupportTraining", CC.CheckBoxValue(cbYesSalesSupportTraining)),
                                    new SqlParameter("@ConfirmSalesSupportTraining", CC.CheckBoxValue(cbConfirmSalesSupportTraining)),
                                    new SqlParameter("@DeclinedSalesSupportTraining", CC.CheckBoxValue(cbDeclinedSalesSupportTraining)),

                                    new SqlParameter("@YesSolutionsDevOverview", CC.CheckBoxValue(cbYesSolutionsDevOverview)),
                                    new SqlParameter("@ConfirmSolutionsDevOverview", CC.CheckBoxValue(cbConfirmSolutionsDevOverview)),
                                    new SqlParameter("@DeclinedSolutionsDevOverview", CC.CheckBoxValue(cbDeclinedSolutionsDevOverview)),
                                    
                                    new SqlParameter("@FixMode", 1),
                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditMarketingDetails", sqlparam);
            LblMsg1.Text = "Record was updated successfully";
            MsgDiv1.Visible = true;
            AlertMails("Sales");
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("marketing.aspx", "btnSave_Click", ex.Message);
            LblMsg1.Text = "Oops! Server problem....try after some time";
            MsgDiv1.Visible = true;
        }
        finally { con.Close(); }
    }

    protected void btnClearSales_Click(object sender, EventArgs e)
    {
        cbYesSalesforceTraining.Checked = false;
        cbConfirmSalesforceTraining.Checked = false;
        //cbYesWikiTraining.Checked = false;
        //cbConfirmWikiTraining.Checked = false;
        cbDeclinedSalesforceTraining.Checked = false;
        //cbDeclinedWikiTraining.Checked = false;

        cbYesSalesSupportTraining.Checked = false;
        cbConfirmSalesSupportTraining.Checked = false;
        cbDeclinedSalesSupportTraining.Checked = false;

        cbYesSolutionsDevOverview.Checked = false;
        cbConfirmSolutionsDevOverview.Checked = false;
        cbDeclinedSolutionsDevOverview.Checked = false;
    }
}
