﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;
using iTextSharp;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;
using myApp.ns.pages;

public partial class employeelisting : System.Web.UI.Page
{
    CommonClass CC = new CommonClass();
    PagedDataSource pgsource = new PagedDataSource();
    int findex, lindex;
    DataRow dr;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        lblNoData.Visible = false;
        if (!IsPostBack)
        {
            if (Session["RecordPerPage"] != null)
            {
                ddlRecordPerPage.SelectedIndex = ddlRecordPerPage.Items.IndexOf(ddlRecordPerPage.Items.FindByText(Session["RecordPerPage"].ToString()));
            }
            else
            {
                Session["RecordPerPage"] = "10";
            }
            FillGridView();
        }
    }

    private void FillGridView()
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            //string strQuery = string.Empty;
            //strQuery += " select EE.EmployeeID, (EE.FirstName +' ' + EE.LastName) as FirstName, EC.Title, ED.DepartmentName, EC.EmploymentType, ISNULL(EC.StartDate, '01/01/1900') as StartDate,  ISNULL(EC.LaptopDate, '01/01/1900') as LaptopDate , EE.CreatedBy, ";
            //strQuery += " EE.CreatedDate,  ISNULL(EE.LastUpdatedBy, EE.CreatedBy) AS LastUpdatedBy, ISNULL(EE.LastUpdatedDate, EE.CreatedDate) AS LastUpdatedDate,";
            //strQuery += " ISNULL(EM.Code, '') as code, ISNULL(EM.isSaved, 0) as isSaved, ISNULL(EOD.EmployeeID, 0) as OffBoardingEmployeeID ";
            //strQuery += " FROM Employee.EmployeeDetails EE ";
            //strQuery += " Left Join Employee.Classification EC on EC.EmployeeID = EE.EmployeeID";
            //strQuery += " Left Join Employee.Department ED on ED.DepartmentID = EC.DepartmentID";
            //strQuery += " Left Join Employee.EmailCode EM on EM.EmployeeID = EE.EmployeeID";
            //strQuery += " Left Join Employee.OffBoardingDetails EOD on EOD.EmployeeID = EE.EmployeeID";
            //strQuery += " Order By EE.LastUpdatedDate desc";
            if (ViewState["SearchText"] != null && ViewState["SearchText"] != "")
            {
                SqlParameter[] sqlParam = new SqlParameter[]{
                                        new SqlParameter("@SearchString",ViewState["SearchText"].ToString())};
                odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_SearchEmployeesForEmployeeListing", sqlParam).Tables[0];
            }
            else
            {
                odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetEmployeeListing").Tables[0];
            }
            if (odt.Rows.Count > 0)
            {
                DataView sortedView = new DataView();
                sortedView = odt.DefaultView;

                if (ViewState["SortText"] != null && ViewState["SortValue"] != null)
                {
                    sortedView.Sort = ViewState["SortText"] + " " + ViewState["SortValue"];
                }

                pgsource.DataSource = odt.DefaultView;
                pgsource.AllowPaging = true;
                if (Convert.ToString(Session["RecordPerPage"].ToString()) != "All")
                {
                    pgsource.PageSize = Convert.ToInt32(Session["RecordPerPage"].ToString());
                }
                else
                {
                    pgsource.PageSize = pgsource.DataSourceCount;
                }

                //Store it Total pages value in View state
                ViewState["totpage"] = pgsource.PageCount;

                if (CurrentPage > Convert.ToInt32(ViewState["totpage"]) - 1)
                {
                    CurrentPage = Convert.ToInt32(ViewState["totpage"]) - 1;
                }

                pgsource.CurrentPageIndex = CurrentPage;

                //Enabled true Link button previous when current page is not equal first page 
                //Enabled false Link button previous when current page is first page
                lbPrev.Enabled = !pgsource.IsFirstPage;

                //Enabled true Link button Next when current page is not equal last page 
                //Enabled false Link button Next when current page is last page
                lbNext.Enabled = !pgsource.IsLastPage;

                //Bind resulted PageSource into the DataList
                gvEmpListing.DataSource = pgsource;
                gvEmpListing.DataBind();

                doPaging();
                lblNoData.Visible = false;
                divPaging.Visible = true;
            }
            else
            {
                DataTable tempdt = new DataTable();
                tempdt.Columns.Add("EmployeeID");
                tempdt.Columns.Add("FirstName");
                tempdt.Columns.Add("Title");
                tempdt.Columns.Add("DepartmentName");
                tempdt.Columns.Add("EmploymentType");
                tempdt.Columns.Add("StartDate");
                tempdt.Columns.Add("LaptopDate");
                tempdt.Columns.Add("isSaved");
                tempdt.Columns.Add("code");
                tempdt.Columns.Add("OffBoardingEmployeeID");
                tempdt.Rows.Add("");
                gvEmpListing.DataSource = tempdt;
                gvEmpListing.DataBind();
                gvEmpListing.Rows[0].Visible = false;
                lblNoData.Visible = true;
                divPaging.Visible = false;
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("employeelisting.aspx", "FillGridView", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    private void SetUserRole()
    {
        if (Session["UserRole"] != null)
        {
            if (Session["UserRole"].ToString().ToLower().Contains("system admin") || Session["UserRole"].ToString().ToLower().Contains("hr"))
            {
                sCreateEmployee.Visible = true;
                sCreateUser.Visible = true;
                sCreateDeapartment.Visible = true;
                gvEmpListing.Columns[9].Visible = true;
            }
            else
            {
                sCreateEmployee.Visible = false;
                sCreateUser.Visible = false;
                sCreateDeapartment.Visible = false;
                gvEmpListing.Columns[9].Visible = false;
            }
            //if (Session["UserRole"].ToString().ToLower() == "system admin")
            //{

            //}
            //else if (Session["UserRole"].ToString().ToLower() == "hr")
            //{
            //    //sCreateUser.Visible = false;
            //}
            //else if (Session["UserRole"].ToString().ToLower() == "it")
            //{
            //    sCreateEmployee.Visible = false;
            //    sCreateUser.Visible = false;
            //    gvEmpListing.Columns[6].Visible = false;
            //}
            //else if (Session["UserRole"].ToString().ToLower() == "administrative")
            //{
            //    sCreateEmployee.Visible = false;
            //    sCreateUser.Visible = false;
            //    gvEmpListing.Columns[6].Visible = false;
            //}
            //else if (Session["UserRole"].ToString().ToLower() == "security")
            //{
            //    sCreateEmployee.Visible = false;
            //    sCreateUser.Visible = false;
            //    gvEmpListing.Columns[6].Visible = false;
            //}
            //else if (Session["UserRole"].ToString().ToLower() == "payroll")
            //{
            //    sCreateEmployee.Visible = false;
            //    sCreateUser.Visible = false;
            //    gvEmpListing.Columns[6].Visible = false;
            //}
        }
    }

    protected override void Render(HtmlTextWriter writer)
    {
        SetUserRole();
        base.Render(writer);
    }

    private void doPaging()
    {
        DataTable dt = new DataTable();
        dt.Columns.Add("Index");

        findex = 1;
        lindex = Convert.ToInt32(ViewState["totpage"]);

        int i = 1;
        if ((CurrentPage == 0 || CurrentPage == 1 || CurrentPage == 2 || CurrentPage == 3) && lindex <= 5)
        {
            i = 1;
            //lindex = 5;
        }
        else if ((CurrentPage == 0 || CurrentPage == 1 || CurrentPage == 2 || CurrentPage == 3) && lindex >= 5)
        {
            i = 1;
            lindex = 5;
        }
        else if (CurrentPage >= 4)
        {
            if (lindex != CurrentPage + 1)
            {
                i = (CurrentPage + 2) - 4;
                if (lindex > lindex - 4)
                    lindex = i + 4;
                else
                    lindex = CurrentPage + 1;
            }
            else
            {
                i = CurrentPage - 3;
                lindex = CurrentPage + 1;
            }
        }

        while (i <= lindex)
        {
            DataRow dr = dt.NewRow();
            dr[0] = i;
            //dr[1] = i + 1;
            dt.Rows.Add(dr);
            i++;
        }

        if (dt.Rows.Count > 0)
        {
            rptPaging.DataSource = dt;
            rptPaging.DataBind();
        }

    }
    private int CurrentPage
    {
        get
        {   //Check view state is null if null then return current index value as "0" else return specific page viewstate value
            if (ViewState["CurrentPage"] == null)
            {
                return 0;
            }
            else
            {
                return ((int)ViewState["CurrentPage"]);
            }
        }
        set
        {
            ViewState["CurrentPage"] = value;
        }
    }


    protected void gvEmpListing_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.ToLower() == "onboarding")
        {
            string empID = e.CommandArgument.ToString();
            Response.Redirect("employeedetail.aspx?Mode=Edit&EmployeeID=" + empID);
        }
        if (e.CommandName.ToLower() == "report")
        {
            string empID = e.CommandArgument.ToString();
            GeneratePDF(Convert.ToInt32(empID));
        }
        if (e.CommandName.ToLower() == "offboarding")
        {
            string empID = e.CommandArgument.ToString();
            Response.Redirect("offbdemployeeinfo.aspx?EmployeeID=" + empID);
        }
        if (e.CommandName.ToLower() == "offboardingreport")
        {
            string empID = e.CommandArgument.ToString();
            GenerateOffBoardingEmpPDF(Convert.ToInt32(empID));
        }
    }

    protected void gvEmpListing_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        Label id = (Label)gvEmpListing.Rows[e.RowIndex].FindControl("lblEmployeeID");
        string empID = id.Text;
        SqlConnection con = SqlHelper.GetConnection();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@EmployeeID", empID);
            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_DeleteEmployeeDetails", sqlparam);
            FillGridView();
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("employeelisting.aspx", "gvEmpListing_RowDeleting", ex.Message);
        }
        finally { con.Close(); }
    }
    protected void rptPaging_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            LinkButton lbIndex = (LinkButton)e.Item.FindControl("lbIndexing");
            if (Convert.ToInt32(lbIndex.Text) == (CurrentPage + 1))
            {
                lbIndex.CssClass = "activepagination";
            }
        }
    }
    protected void rptPaging_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        LinkButton lbIndex = (LinkButton)e.Item.FindControl("lbIndexing");
        CurrentPage = Convert.ToInt32(lbIndex.Text) - 1;
        FillGridView();
    }
    protected void lbPrev_Click(object sender, EventArgs e)
    {
        CurrentPage -= 1;
        FillGridView();
    }
    protected void lbNext_Click(object sender, EventArgs e)
    {
        CurrentPage += 1;
        FillGridView();
    }
    protected void gvEmpListing_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            LinkButton id = (LinkButton)e.Row.FindControl("lbDelete");
            string cid = id.Text;
            id.Attributes.Add("onclick", "return alertuserfordelete();");

            System.Web.UI.WebControls.ImageButton imgOnboarding = (System.Web.UI.WebControls.ImageButton)e.Row.FindControl("imgbtnOnboarding");

            Label code = (Label)e.Row.FindControl("lblCode");
            Label isSaved = (Label)e.Row.FindControl("lblIsSaved");
            if (code.Text != "")
            {
                if (isSaved.Text == "False")
                {
                    imgOnboarding.ImageUrl = "images/icon-hold.png";
                }
            }

            Label lblStartDate = (Label)e.Row.FindControl("lblStartDate");
            if (lblStartDate.Text == "01/01/1900")
            {
                lblStartDate.Text = "";
            }
            //Laptop date start
            Label lblLaptopDate = (Label)e.Row.FindControl("lblLaptopDate");
            if (lblLaptopDate.Text == "01/01/1900")
            {
                lblLaptopDate.Text = "";
            }
            //Laptop date end

            //Change color of offboarding employee row start
            Label lblOffBoardingEmpID = (Label)e.Row.FindControl("lblOffBoardingEmpID");
            if (lblOffBoardingEmpID.Text != "0")
            {
                e.Row.BackColor = System.Drawing.Color.Red;
            }
            //Change color of offboarding employee row end
        }
    }

    private void GeneratePDF(int EmployeeID)
    {

        //ods.Columns.Remove("Employee_Id");
        pdfPageHeaderFooter page = new pdfPageHeaderFooter();

        //int EmployeeID = 1;
        string EmployementType = string.Empty;
        DataTable odtEmpDetails = new DataTable("empdetails");
        DataTable odtEmergencyContact = new DataTable("emergencycontact");
        DataTable odtEmpClassification = new DataTable("empclassification");
        DataTable odtEmpIT = new DataTable("empit");
        DataTable odtEmpAdmin = new DataTable("empadmin");
        DataTable odtEmpSecurity = new DataTable("empsecurity");
        DataTable odtEmpPayroll = new DataTable("emppayroll");
        DataTable odtEmpHRProcess = new DataTable("emphrprocess");
        DataTable odtEmpMeeting = new DataTable("empmeeting");
        DataTable odtEmpMarketing = new DataTable("empmarketing");
        DataTable odtEmpPerformance = new DataTable("empperformance");

        odtEmpDetails = GetEmpDetails(EmployeeID, odtEmpDetails);
        odtEmergencyContact = GetEmpEmergencyDetails(EmployeeID, odtEmergencyContact);
        odtEmpClassification = GetEmpClassificationDetails(EmployeeID, odtEmpClassification);
        odtEmpIT = GetEmpITDetails(EmployeeID, odtEmpIT);
        odtEmpMarketing = GetEmpMarketingDetails(EmployeeID, odtEmpMarketing);
        odtEmpAdmin = GetEmpAdminDetails(EmployeeID, odtEmpAdmin);
        odtEmpSecurity = GetEmpSecurityDetails(EmployeeID, odtEmpSecurity);
        odtEmpMeeting = GetEmpMeetingDetails(EmployeeID, odtEmpMeeting);
        odtEmpPayroll = GetEmpPayrollDetails(EmployeeID, odtEmpPayroll);
        odtEmpHRProcess = GetEmpHRProcessDetails(EmployeeID, odtEmpHRProcess);
        odtEmpPerformance = GetEmpPerformanceDetails(EmployeeID, odtEmpPerformance);

        page.ReportHeader = "Resource OnBoarding";
        if (odtEmpClassification.Rows.Count > 0)
        {
            EmployementType = odtEmpClassification.Rows[0]["EmploymentType"].ToString();
        }
        if (odtEmpDetails.Rows.Count > 0)
        {
            page.EmployeeName = odtEmpDetails.Rows[0]["FirstName"].ToString() + " " + odtEmpDetails.Rows[0]["MiddleInitial"].ToString() + " " + odtEmpDetails.Rows[0]["LastName"].ToString();
            page.EmployementType = EmployementType;
            page.Address = odtEmpDetails.Rows[0]["StreetAddress"].ToString() + " " + odtEmpDetails.Rows[0]["AptUnit"].ToString();
            if (page.Address.Length > 95)
            {
                page.Address = page.Address.Substring(0, 94);
            }
            page.City = odtEmpDetails.Rows[0]["City"].ToString();
            if (odtEmpDetails.Rows[0]["Country"].ToString() != "")
            {
                page.State = odtEmpDetails.Rows[0]["Country"].ToString() + ", " + odtEmpDetails.Rows[0]["State"].ToString() + " " + odtEmpDetails.Rows[0]["PostalCode"].ToString();
            }
            else
            {
                page.State = odtEmpDetails.Rows[0]["State"].ToString() + " " + odtEmpDetails.Rows[0]["PostalCode"].ToString();
            }

            page.Home = odtEmpDetails.Rows[0]["HomePhone"].ToString();
            page.Cell = odtEmpDetails.Rows[0]["CellPhone"].ToString();
            page.BusinessCard = odtEmpDetails.Rows[0]["BusinessCardName"].ToString();
            page.EmailName = odtEmpDetails.Rows[0]["CompanyEmailID"].ToString();
            page.PersonalEmail = odtEmpDetails.Rows[0]["PerEmailID"].ToString();
        }

        try
        {
            string filename = "Onboarding Resource.pdf";


            //modified for open direct without saving on server used memory stream insted of filestream start

            using (var ms = new MemoryStream())
            {
                Document document = new Document(PageSize.A4, 10, 10, 110, 110);
                PdfWriter writer = PdfWriter.GetInstance(document, ms);


                writer.PageEvent = page;
                // Open the document to enable you to write to the document
                document.Open();
                // Makes it possible to add text to a specific place in the document using 
                // a X & Y placement syntax.
                PdfContentByte cb = writer.DirectContent;

                cb.BeginText();
                cb.MoveTo(25, 735);
                Font arial = FontFactory.GetFont("Arial", 7, Font.NORMAL, new Color(0, 0, 0));
                Font arial1 = FontFactory.GetFont("Arial", 7, Font.BOLD, new Color(0, 0, 0));

                int row_height = 700;
                //========Code of Print Emergency Contacts Start
                if (odtEmergencyContact.Rows.Count > 0)
                {
                    string name = odtEmergencyContact.Rows[0]["ConFirstName"].ToString() + " " + odtEmergencyContact.Rows[0]["ConMiddleInitials"].ToString() + " " + odtEmergencyContact.Rows[0]["ConLastName"].ToString();
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Emergency Contact", 15, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, name, 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Primary Phone:  " + odtEmergencyContact.Rows[0]["PrimaryPhone"].ToString(), 350, row_height, 0);

                    string address = string.Empty;
                    address = odtEmergencyContact.Rows[0]["ConStreetAddress"].ToString() + " " + odtEmergencyContact.Rows[0]["ConAptUnit"].ToString();
                    if (address.Length > 95)
                    {
                        address = address.Substring(0, 94);
                    }

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 8);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, address, 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Alternate Phone:  " + odtEmergencyContact.Rows[0]["AlternatePhone"].ToString(), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 8);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, odtEmergencyContact.Rows[0]["ConCity"].ToString(), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Relationship:  " + odtEmergencyContact.Rows[0]["Relationship"].ToString(), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 8);
                    if (odtEmergencyContact.Rows[0]["ConCountry"].ToString() != "")
                    {
                        cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, odtEmergencyContact.Rows[0]["ConCountry"].ToString() + ", " + odtEmergencyContact.Rows[0]["ConState"].ToString() + " " + odtEmergencyContact.Rows[0]["ConZip"].ToString(), 15, row_height, 0);
                    }
                    else
                    {
                        cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, odtEmergencyContact.Rows[0]["ConState"].ToString() + " " + odtEmergencyContact.Rows[0]["ConZip"].ToString(), 15, row_height, 0);
                    }

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                else
                {

                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Emergency Contact", 15, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Primary Phone: ", 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Alternate Phone: ", 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Relationship: ", 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "", 15, row_height, 0);
                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                //========Code of Print Emergency Contacts End

                //========Code of Print Employee Classification Start
                if (odtEmpClassification.Rows.Count > 0)
                {
                    row_height -= 15;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Employment Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Title:  " + Server.HtmlDecode(odtEmpClassification.Rows[0]["Title"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Start Date:  " + ConvertToStringDate(odtEmpClassification.Rows[0]["StartDate"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Department:  " + odtEmpClassification.Rows[0]["DepartmentName"].ToString(), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Laptop Date:  " + ConvertToStringDate(odtEmpClassification.Rows[0]["LaptopDate"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Role Type:  " + odtEmpClassification.Rows[0]["Role_Type"].ToString(), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "All Hands:  " + ConvertToYesNo(odtEmpClassification.Rows[0]["AllHands"].ToString()), 350, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Consulting Project:  " + odtEmpClassification.Rows[0]["ProposedConsProject"].ToString(), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Location:  " + Server.HtmlDecode(odtEmpClassification.Rows[0]["Location"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Laptop:  " + ConvertToYesNo(odtEmpClassification.Rows[0]["PCEquipment"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Ship Laptop:  " + ConvertToYesNo(odtEmpClassification.Rows[0]["LaptopShipAddress"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Salesforce login:  " + ConvertToYesNo(odtEmpClassification.Rows[0]["SalesforceLogin"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Conference/Video Bridge:  " + ConvertToYesNo(odtEmpClassification.Rows[0]["GTM"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "PrePipeline:  " + ConvertToYesNo(odtEmpClassification.Rows[0]["PPsalesCall"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Special Software needs:  " + Server.HtmlDecode(odtEmpClassification.Rows[0]["SpecialSoftware"].ToString()), 15, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Additional Access:  " + Server.HtmlDecode(odtEmpClassification.Rows[0]["AdditionalAccess"].ToString()), 15, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Other Location:  " + Server.HtmlDecode(odtEmpClassification.Rows[0]["OtherLocation"].ToString()), 15, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Manager:  " + Server.HtmlDecode(odtEmpClassification.Rows[0]["IsManager"].ToString()), 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Network Calls ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Operations:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpClassification.Rows[0]["NC_Operation"].ToString()), 125, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sales:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpClassification.Rows[0]["NC_Sales"].ToString()), 125, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "HSG:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpClassification.Rows[0]["NC_HSG"].ToString()), 125, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                else
                {
                    row_height -= 15;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Employment Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Title:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Start Date:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Department:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Laptop Date:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Role Type:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "All Hands:  ", 350, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Consulting Project:  " + odtEmpClassification.Rows[0]["ProposedConsProject"].ToString(), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Location:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Laptop:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Ship Laptop:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Salesforce login:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Conference/Video Bridge:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "PrePipeline:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Special Software needs:  ", 15, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Additional Access:  ", 15, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Other Location:  ", 15, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Manager:  ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Network Calls ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Operations:  ", 25, row_height, 0);

                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sales:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpClassification.Rows[0]["NC_Sales"].ToString()), 125, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "HSG:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpClassification.Rows[0]["NC_HSG"].ToString()), 125, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                //========Code of Print Employee Classification End

                //========Code of Print Employee IT Details Start
                if (odtEmpIT.Rows.Count > 0)
                {
                    row_height -= 15;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "IT Information", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Location ", 15, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Office Location: " + odtEmpIT.Rows[0]["OfficeLocation"].ToString(), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Remote:  " + ConvertToYesNo(odtEmpIT.Rows[0]["OfficeLocation_Remote"].ToString()), 350, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email ", 15, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email:  " + Server.HtmlDecode(odtEmpIT.Rows[0]["EmailAddress"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email/Sign Alsbridge:  " + ConvertToYesNo(odtEmpIT.Rows[0]["EmailSign_Alsbridge"].ToString()), 350, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Accessories ", 15, row_height, 0);

                    //////////////////////////////// chages required for dallas and remote locatioin///////////////

                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Office Location ", 15, row_height, 0);
                    //row_height -= 15;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Dallas Office:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["OfficeLocation_Dallas"].ToString()), 100, row_height, 0);

                    ////////////////////////////////
                    //row_height -= 15;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "IF DALLAS OFFICE ", 15, row_height, 0);
                    ////////////////////////////////

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Docking Station:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["WS_DockingStation"].ToString()), 125, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Stand:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["WS_Stand"].ToString()), 125, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Monitor:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["WS_Monitor"].ToString()), 125, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Keyboard:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["WS_Keyboard"].ToString()), 125, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Mouse:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["WS_Mouse"].ToString()), 125, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Phone:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["WS_Phone"].ToString()), 125, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Extra Battery:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ExtraBattery"].ToString()), 125, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Extra Power Cord:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ExtraPowerCord"].ToString()), 125, row_height, 0);
                    ////////////////////////////////

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Added to team list:  " + ConvertToYesNo(odtEmpIT.Rows[0]["TeamList"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Other lists:  " + Server.HtmlDecode(odtEmpIT.Rows[0]["TeamList_Other"].ToString()), 350, row_height, 0);
                    ////////////////////////////////

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "PHONES ", 15, row_height, 0);
                    ////////////////////////////////
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Extension:  " + odtEmpIT.Rows[0]["Dallas_PhyExtention"].ToString(), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Direct No:  " + odtEmpIT.Rows[0]["Dallas_DirectNo"].ToString(), 350, row_height, 0);
                    ////////////////////////////////
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Redirect No:  " + odtEmpIT.Rows[0]["Remote_RedirectNo"].ToString(), 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "LAPTOP ", 15, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Type:  " + odtEmpIT.Rows[0]["LaptopType"].ToString(), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Laptop Asset Id:  " + Server.HtmlDecode(odtEmpIT.Rows[0]["LaptopAssest"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Service Tag:  " + odtEmpIT.Rows[0]["ServiceTag"].ToString(), 15, row_height, 0);
                    /////////////IT CheckList//////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "IT Checklist ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);

                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Mandatory Software/Access list ", 15, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes/No ", 300, row_height, 0);
                    //row_height -= 15;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Adobe Reader:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["AdobeReader"].ToString()), 300, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Office 365:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["MSOffice"].ToString()), 300, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Lync:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["Lync"].ToString()), 300, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Wiki:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["Wiki"].ToString()), 300, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "GTM Meeting Loader:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["GTMmeeting"].ToString()), 300, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "AVG:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["AVG"].ToString()), 300, row_height, 0);

                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Printers:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["Printers"].ToString()), 300, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Jungle Dist:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["JungleDisk"].ToString()), 300, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "PDF Creator:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["PDFCreator"].ToString()), 300, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Add all shortcuts:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["AddShortcuts"].ToString()), 300, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Map JD my docs and desktop:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["MapJDdocsdesktop"].ToString()), 300, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email snapshot and keys to support@alsbridge.com:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["SupportMail"].ToString()), 300, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Install encrypted SD card and local script:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["SDcard"].ToString()), 300, row_height, 0);
                    ////////////////////////////////

                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Optional Software/Access confirm list ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirm ", 350, row_height, 0);
                    row_height -= 15;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "GTM License:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesGTMLicense"].ToString()), 300, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmGTMLicense"].ToString()), 350, row_height, 0);

                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Webex License:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesWebexLicense"].ToString()), 300, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmWebexLicense"].ToString()), 350, row_height, 0);
                    //row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "MS Project (needs Mgr approval):  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesMSProject"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmMSProject"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "MS Visio (needs Mgr approval):  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesMSVisio"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmMSVisio"].ToString()), 350, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "VPN:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesVPN"].ToString()), 300, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmVPN"].ToString()), 350, row_height, 0);
                    ////////////////////////////////
                    ///////////////// yes and Confirm ///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sales confirm list ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirm ", 350, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "AP Stylebook:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesAPStylebook"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmAPStylebook"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Salesforce:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesSalesforce"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmSalesforce"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Inside View:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesInsideView"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmInsideView"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "PowerDialer:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesPowerDialer"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmPowerDialer"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Radar Report US:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesRRUS"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmRRUS"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Discover Org:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesDiscoverOrg"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmDiscoverOrg"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "alsbridgesales@alsbridge.com:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesAlsbridgesalesMail"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmAlsbridgesalesMail"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "pbsales@alsbridge.com:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["YesPbsalesMail"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["ConfirmPbsalesMail"].ToString()), 350, row_height, 0);
                    ////////////////////////////////

                    ////////////////////////////////
                    cb.EndText();
                    document.NewPage();

                    row_height = 700;
                    cb.BeginText();
                    ////////////////////////////////                     
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "IT Checklist completed, on file and copy given w/PC:  " + odtEmpIT.Rows[0]["ITCheklistComp"].ToString(), 15, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "User contacted to for IT Operations session:  " + odtEmpIT.Rows[0]["ITOpearationSession"].ToString(), 15, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Date PC Shipped to user:  " + ConvertToStringDate(odtEmpIT.Rows[0]["PCShipped"].ToString()), 15, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Additional comment:  " + Server.HtmlDecode(odtEmpIT.Rows[0]["AdditionalComment"].ToString()), 15, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                }
                else
                {
                    row_height -= 15;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "IT Information", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Location ", 15, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Office Location: ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Remote:  ", 350, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email ", 15, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email/Sign Alsbridge:  ", 350, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Accessories ", 15, row_height, 0);

                    //////////////////////////////// chages required for dallas and remote locatioin///////////////

                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Office Location ", 15, row_height, 0);
                    //row_height -= 15;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Dallas Office:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpIT.Rows[0]["OfficeLocation_Dallas"].ToString()), 100, row_height, 0);

                    ////////////////////////////////
                    //row_height -= 15;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "IF DALLAS OFFICE ", 15, row_height, 0);
                    ////////////////////////////////

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Docking Station:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Stand:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Monitor:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Keyboard:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Mouse:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Phone:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Extra Battery:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Extra Power Cord:  ", 25, row_height, 0);
                    ////////////////////////////////

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Added to team list:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Other lists:  ", 350, row_height, 0);
                    ////////////////////////////////

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "PHONES ", 15, row_height, 0);
                    ////////////////////////////////
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Extension:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Direct No:  ", 350, row_height, 0);
                    ////////////////////////////////
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Redirect No:  ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "LAPTOP ", 15, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Type:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Laptop Asset Id:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Service Tag:  ", 15, row_height, 0);
                    /////////////IT CheckList//////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "IT Checklist ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);

                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Optional Software/Access confirm list ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirm ", 350, row_height, 0);
                    row_height -= 15;

                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "MS Project (needs Mgr approval):  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "MS Visio (needs Mgr approval):  ", 25, row_height, 0);
                    ///////////////// yes and Confirm ///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sales confirm list ", 15, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "AP Stylebook:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Salesforce:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Inside View:  ", 25, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "PowerDialer:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Radar Report US:  ", 25, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Discover Org:  ", 25, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "alsbridgesales@alsbridge.com:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "pbsales@alsbridge.com:  ", 25, row_height, 0);
                    ////////////////////////////////

                    ////////////////////////////////
                    cb.EndText();
                    document.NewPage();

                    row_height = 700;
                    cb.BeginText();
                    ////////////////////////////////                     
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "IT Checklist completed, on file and copy given w/PC:  ", 15, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "User contacted to for IT Operations session:  ", 15, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Date PC Shipped to user:  ", 15, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Additional comment:  ", 15, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                }
                //========Code of Print Employee IT Details End

                //========Code of Print Employee Marketing Details Start
                if (odtEmpMarketing.Rows.Count > 0)
                {
                    //cb.BeginText();
                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sales & Marketing Details", 15, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Marketing ", 15, row_height, 0);
                    ///////////////// yes and Confirm ///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Information ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Needed ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Completed ", 350, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Declined ", 415, row_height, 0);
                    row_height -= 15;

                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Bio/Photo uploaded to Alsbridge.com (Corporate Website):  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["YesBIOUpload"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["ConfirmBIOUpload"].ToString()), 350, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["DeclinedBIOUpload"].ToString()), 415, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Press Release:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["YesPressRelease"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["ConfirmPressRelease"].ToString()), 350, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["DeclinedPressRelease"].ToString()), 415, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Get contacts from MD/D and import into SF:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["YesImportSF"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["ConfirmImportSF"].ToString()), 350, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["DeclinedImportSF"].ToString()), 415, row_height, 0);

                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Photo Uploaded:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["YesPhotoUploaded"].ToString()), 300, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["ConfirmPhotoUploaded"].ToString()), 350, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["DeclinedPhotoUploaded"].ToString()), 415, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Marketing Overview:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["YesMarketingOverview"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["ConfirmMarketingOverview"].ToString()), 350, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["DeclinedMarketingOverview"].ToString()), 415, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Linkedin Profile:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["YesLinkedinProfile"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["ConfirmLinkedinProfile"].ToString()), 350, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["DeclinedLinkedinProfile"].ToString()), 415, row_height, 0);
                    //
                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sales ", 15, row_height, 0);
                    ///////////////// yes and Confirm ///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Information ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Needed ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Completed ", 350, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Declined ", 415, row_height, 0);
                    row_height -= 15;

                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Salesforce Training:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["YesSalesforceTraining"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["ConfirmSalesforceTraining"].ToString()), 350, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["DeclinedSalesforceTraining"].ToString()), 415, row_height, 0);

                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Wiki Training:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["YesWikiTraining"].ToString()), 300, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["ConfirmWikiTraining"].ToString()), 350, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["DeclinedWikiTraining"].ToString()), 415, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sales Support Training:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["YesSalesSupportTraining"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["ConfirmSalesSupportTraining"].ToString()), 350, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["DeclinedSalesSupportTraining"].ToString()), 415, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Solutions Development Overview:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["YesSolutionsDevOverview"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["ConfirmSolutionsDevOverview"].ToString()), 350, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMarketing.Rows[0]["DeclinedSolutionsDevOverview"].ToString()), 415, row_height, 0);

                    row_height -= 15;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                else
                {
                    //cb.BeginText();
                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sales & Marketing Details", 15, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Marketing ", 15, row_height, 0);
                    ///////////////// yes and Confirm ///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Information ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Needed ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Completed ", 350, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Declined ", 415, row_height, 0);
                    row_height -= 15;

                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Bio/Photo uploaded to Alsbridge.com (Corporate Website):  ", 25, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Press Release:  ", 25, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Get contacts from MD/D and import into SF:  ", 25, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Marketing Overview:  ", 25, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Linkedin Profile:  ", 25, row_height, 0);
                    //
                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sales ", 15, row_height, 0);
                    ///////////////// yes and Confirm ///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Information ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Needed ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Completed ", 350, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Declined ", 415, row_height, 0);
                    row_height -= 15;

                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Salesforce Training:  ", 25, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sales Support Training:  ", 25, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Solutions Development Overview:  ", 25, row_height, 0);

                    row_height -= 15;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                //========Code of Print Employee Marketing Details End

                //========Code of Print Employee Administrative Details Start
                if (odtEmpAdmin.Rows.Count > 0)
                {
                    row_height -= 15;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Administrative Details", 15, row_height, 0);

                    ///////////////// yes and Confirm ///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Information ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirm ", 350, row_height, 0);
                    row_height -= 15;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Business Cards:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesBusinessCard"].ToString()), 300, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmBusinessCard"].ToString()), 350, row_height, 0);
                    //row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Business Cards Ordered:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesBusinessCardOrder"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmBusinessCardOrder"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Business Cards Quantity:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesBCQty"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, odtEmpAdmin.Rows[0]["BCQty"].ToString(), 350, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Business Cards Confirm by HR:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesBusinessCardConfirmHR"].ToString()), 300, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmBusinessCardConfirmHR"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Orbitz Account Activation:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesOrbitzAccountActivation"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmOrbitzAccountActivation"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "FedEx Discount Cards:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesFedExDiscountCard"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmFedExDiscountCard"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sourcing Leadership Login:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesOSLeadershipLogin"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmOSLeadershipLogin"].ToString()), 350, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Outsourcing Center Login:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesOSCenterLogin"].ToString()), 300, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmOSCenterLogin"].ToString()), 350, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "NING Social Invite:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesNINGSocialInvite"].ToString()), 300, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmNINGSocialInvite"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Administration emails with information on logins:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesAdministrationEmail"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmAdministrationEmail"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Office space allocation:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesOfficeSpaceAllocation"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmOfficeSpaceAllocation"].ToString()), 350, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "INDIA", 15, row_height, 0);
                    row_height -= 15;
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Laptop and Phone Procurement:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesIndiaLaptopPhonePro"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmIndiaLaptopPhonePro"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "ID Card:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesIndiaIDCard"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmIndiaIDCard"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Joining Kit (Folder/Mug/Mouse Pad/Staionary):  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["YesIndiaJoiningKit"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpAdmin.Rows[0]["ConfirmIndiaJoiningKit"].ToString()), 350, row_height, 0);

                    row_height -= 15;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                }
                else
                {
                    row_height -= 15;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Administrative Details", 15, row_height, 0);

                    ///////////////// yes and Confirm ///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Information ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirm ", 350, row_height, 0);
                    row_height -= 15;

                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Business Cards Ordered:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Business Cards Quantity:  ", 25, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Orbitz Account Activation:  ", 25, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "FedEx Discount Cards:  ", 25, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sourcing Leadership Login:  ", 25, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Administration emails with information on logins:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Office space allocation:  ", 25, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "INDIA", 15, row_height, 0);
                    row_height -= 15;
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Laptop and Phone Procurement:  ", 25, row_height, 0);

                    row_height -= 10;
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "ID Card:  ", 25, row_height, 0);

                    row_height -= 10;
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Joining Kit (Folder/Mug/Mouse Pad/Staionary):  ", 25, row_height, 0);

                    row_height -= 15;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                }
                //========Code of Print Employee Administrative Details End

                //========Code of Print Employee Security Details Start
                if (odtEmpSecurity.Rows.Count > 0)
                {
                    row_height -= 15;
                    //cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Security Details", 15, row_height, 0);

                    ///////////////// yes and Confirm ///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Information ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirm ", 350, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Parking Entry:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["YesParkingEntry"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["ConfirmParkingEntry"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Entry Key:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["YesEntryKey"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["ConfirmEntryKey"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Security Code:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["YesSecurityCode"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["ConfirmSecurityCode"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Security Information Sent:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["YesSecurityInfoSent"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpSecurity.Rows[0]["ConfirmSecurityInfoSent"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                }
                else
                {
                    row_height -= 15;
                    //cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Security Details", 15, row_height, 0);

                    ///////////////// yes and Confirm ///////////////
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Information ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirm ", 350, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Parking Entry:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Entry Key:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Security Code:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Security Information Sent:  ", 25, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                }
                //========Code of Print Employee Security Details End

                //========Code of Print Employee Meeting Details Start
                if (odtEmpMeeting.Rows.Count > 0)
                {
                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Meeting Details", 15, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Meetings Invite ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirm ", 350, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Pipeline Call - Early Stage:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["YesConsulting_ESP"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["ConfirmConsulting_ESP"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Pipeline Call - Proposal Stage:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["YesConsulting_PP"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["ConfirmConsulting_PP"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Consulting Operations:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["YesConsulting_OP"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["ConfirmConsulting_OP"].ToString()), 350, row_height, 0);
                    //row_height -= 10;                    
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Vendor Early Stage Pipeling:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["YesVendor_ESP"].ToString()), 300, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["ConfirmVendor_ESP"].ToString()), 350, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Vendor Proposal Pipeline:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["YesVendor_PP"].ToString()), 300, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["ConfirmVendor_PP"].ToString()), 350, row_height, 0);                    
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "NSG Operations:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["YesNSG_OP"].ToString()), 300, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["ConfirmNSG_OP"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "ITAM Operations:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["YesHSG_OP"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["ConfirmHSG_OP"].ToString()), 350, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "US-UK Pipeline:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["YesUS_UK_P"].ToString()), 300, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["ConfirmUS_UK_P"].ToString()), 350, row_height, 0);
                    ////////////////////////////////

                    ////////////////////////////// 18/02/2014 Start ////////////////////////////////////////////////
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Network Services MC/C WIP Review:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["YesWIPReview"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["ConfirmWIPReview"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Network Services Consultant Deal Review:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["YesDealReview"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["ConfirmDealReview"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Monthly ProB team call:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["YesMnthProbCall"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["ConfirmMnthProbCall"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Weekly Europe update:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["YesWklEuropeUdt"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["ConfirmWklEuropeUdt"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Weekly vendor call:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["YesWklVendorCall"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["ConfirmWklVendorCall"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Weekly ITAM call:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["YesWklHWSWCall"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["ConfirmWklHWSWCall"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "SD Team Meeting:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["YesSDTeamMtg"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["ConfirmSDTeamMtg"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "SS Team Meeting:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["YesSSTeamMtg"].ToString()), 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpMeeting.Rows[0]["ConfirmSSTeamMtg"].ToString()), 350, row_height, 0);
                    ////////////////////////////// 18/02/2014 End ////////////////////////////////////////////////
                }
                else
                {
                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Meeting Details", 15, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Meetings Invite ", 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Yes ", 300, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirm ", 350, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Pipeline Call - Early Stage:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Pipeline Call - Proposal Stage:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Consulting Operations:  ", 25, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "ITAM Operations:  ", 25, row_height, 0);

                    ////////////////////////////// 18/02/2014 Start ////////////////////////////////////////////////
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Network Services MC/C WIP Review:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Network Services Consultant Deal Review:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Monthly ProB team call:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Weekly Europe update:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Weekly vendor call:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Weekly ITAM call:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "SD Team Meeting:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "SS Team Meeting:  ", 25, row_height, 0);
                    ////////////////////////////// 18/02/2014 End ////////////////////////////////////////////////
                }
                //========Code of Print Employee Meeting Details End

                ////========Code of Print Employee Payroll Details Start
                //if (odtEmpPayroll.Rows.Count > 0)
                //{
                //    row_height -= 15;
                //    cb.BeginText();
                //    cb.SetFontAndSize(f_cb1, 11);
                //    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Payroll Details", 15, row_height, 0);

                //    row_height -= 15;
                //    cb.SetFontAndSize(f_cn, 10);
                //    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Replicon Counsel & Project:  " + ConvertToYesNo(odtEmpPayroll.Rows[0]["RepliconCounselProject"].ToString()), 15, row_height, 0);
                //    cb.SetFontAndSize(f_cn, 10);
                //    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Add to ADP Payroll:  " + ConvertToYesNo(odtEmpPayroll.Rows[0]["ADPPayroll"].ToString()), 350, row_height, 0);

                //    row_height -= 10;
                //    cb.SetLineWidth(0f);
                //    cb.MoveTo(10, row_height);
                //    cb.LineTo(585, row_height);
                //    cb.Stroke();
                //    cb.EndText();
                //}
                //else
                //{
                //    row_height -= 15;
                //    cb.BeginText();
                //    cb.SetFontAndSize(f_cb1, 11);
                //    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Payroll Details", 15, row_height, 0);

                //    row_height -= 15;
                //    cb.SetFontAndSize(f_cn, 10);
                //    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Replicon Counsel & Project: ", 15, row_height, 0);
                //    cb.SetFontAndSize(f_cn, 10);
                //    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Add to ADP Payroll: ", 350, row_height, 0);

                //    row_height -= 10;
                //    cb.SetLineWidth(0f);
                //    cb.MoveTo(10, row_height);
                //    cb.LineTo(585, row_height);
                //    cb.Stroke();
                //    cb.EndText();
                //}
                ////========Code of Print Employee Payroll Details End

                //========Code of Print Employee Performance Details Start
                if (odtEmpPerformance.Rows.Count > 0)
                {
                    cb.EndText();
                    document.NewPage();
                    row_height = 700;
                    cb.BeginText();
                    //row_height -= 15;
                    //cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Performance Management Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Skills Database Entries:  " + ConvertToYesNo(odtEmpPerformance.Rows[0]["SkillsDBEntries"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Counsel Group Introduction Lead e-mail:  " + ConvertToYesNo(odtEmpPerformance.Rows[0]["CounselIntroEmail"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Curator Introduction e-mail:  " + ConvertToYesNo(odtEmpPerformance.Rows[0]["CuratorIntroEmail"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Update Counsel group lead chart:  " + ConvertToYesNo(odtEmpPerformance.Rows[0]["CounselGroupChart"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Update Curator group chart:  " + ConvertToYesNo(odtEmpPerformance.Rows[0]["CuratorGroupChart"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Peer Coach introductory e-mail:  " + ConvertToYesNo(odtEmpPerformance.Rows[0]["PeerCoachEmail"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirmation Form:  " + ConvertToYesNo(odtEmpPerformance.Rows[0]["ConfirmationForm"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "360/Assessments Overview:  " + ConvertToYesNo(odtEmpPerformance.Rows[0]["AssessmentsOverview"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Learning & Development Training:  " + ConvertToYesNo(odtEmpPerformance.Rows[0]["LearningDevTraining"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Performance Training:  " + ConvertToYesNo(odtEmpPerformance.Rows[0]["PerformanceTraining"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Counsel/Direct Report:  " + Server.HtmlDecode(odtEmpPerformance.Rows[0]["CounselDirectRpt"].ToString()), 15, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Peer Coach:  " + Server.HtmlDecode(odtEmpPerformance.Rows[0]["PeerCoach"].ToString()), 15, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Curator:  " + Server.HtmlDecode(odtEmpPerformance.Rows[0]["Curator"].ToString()), 15, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                }
                else
                {
                    cb.EndText();
                    document.NewPage();
                    row_height = 700;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Performance Management Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Skills Database Entries:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Counsel Group Introduction Lead e-mail:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Curator Introduction e-mail:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Update Counsel group lead chart:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Update Curator group chart:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Peer Coach introductory e-mail:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Confirmation Form:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "360/Assessments Overview:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Learning & Development Training:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Performance Training:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Counsel/Direct Report:  ", 15, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Peer Coach:  ", 15, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Curator:  ", 15, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                }
                //========Code of Print Employee Performance Details End

                //========Code of Print Employee HR Process Details Start
                if (odtEmpHRProcess.Rows.Count > 0)
                {
                    row_height -= 15;
                    //cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Final HR Process", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Pre-Onboarding ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Welcome Email sent with documents ", 15, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "W4/W9:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpHRProcess.Rows[0]["WE_W4W9"].ToString()), 200, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "I9:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpHRProcess.Rows[0]["WE_I9"].ToString()), 200, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Direct Deposit Form:  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpHRProcess.Rows[0]["WE_DDForm"].ToString()), 200, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Policy Signature Pages(4):  ", 25, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpHRProcess.Rows[0]["WE_PolicySign"].ToString()), 200, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Schedule Onboarding:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["ScheduleOnboarding"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Onboarding Agenda:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["OnboardingAgenda"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Run eVerify:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["Run_e_verify"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Conduct Background check:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["BackgoundCheck"].ToString()), 350, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Agreement Executed by Chip:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["AgreementExecuted"].ToString()), 15, row_height, 0);
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "All documents gathered & confirm:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["DocumentsGathered"].ToString()), 350, row_height, 0);

                    ////////////////////////////////
                    //row_height -= 15;
                    //cb.SetFontAndSize(f_cb1, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Consulting ", 15, row_height, 0);

                    //row_height -= 15;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Counsel Group Lead Intro Sent:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["CounselGroupLeadIntroduction"].ToString()), 15, row_height, 0);
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Peer Coaching Intro sent:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["PeerCoachingIntroduction"].ToString()), 350, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Bio Updated and Posted on the Wiki:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["BioUpdatedPostedOnWiki"].ToString()), 15, row_height, 0);
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Contacts Meeting Set with Marketing:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["ContactsMeetingWithReaghan"].ToString()), 350, row_height, 0);

                    //////Two New Field Added
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "New Hire Test:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["HireTest"].ToString()), 15, row_height, 0);
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "LinkedIn Profile Updated:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["LinkedinUpdate"].ToString()), 350, row_height, 0);
                    ////////////////////////////////

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Offer Letter:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["OfferLetter"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Employment Agreement:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["AgreementExecuted"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Replicon counsel and internal projects:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["RepliconCounselProject"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Ordering an ALS Debit Card:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["AlsBridgeDebitCard"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Added to Payroll (ADP or Pierian (India)):  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["AddedToPayrollIndia"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "New Hire Kit:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["HireTest"].ToString()), 350, row_height, 0);


                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "First Week ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Added to Directory:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["AddToDirectory"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Welcome Lunch Scheduled:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["WelcomeLunchScheduled"].ToString()), 350, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Company Directory Provided:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["CompanyDirectoryProvided"].ToString()), 350, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Voicemail Instruction sent:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["VoicemailInstuctionSent"].ToString()), 15, row_height, 0);
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Vcf Created/Uploaded:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["VcfCreatedUploaded"].ToString()), 350, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Skills Database Completed:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["SkillDatabase"].ToString()), 15, row_height, 0);
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Welcome Lunch Scheduled:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["WelcomeLunchScheduled"].ToString()), 350, row_height, 0);

                    //row_height -= 15;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Added to Benefits Portal ", 15, row_height, 0);
                    //row_height -= 15;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Benefits Video Sent:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpHRProcess.Rows[0]["BenefitVideoSent"].ToString()), 200, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Benefits Overview Completed:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpHRProcess.Rows[0]["BenefitOverview"].ToString()), 200, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Benefits Enrollment Sent:  ", 25, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ConvertToYesNo(odtEmpHRProcess.Rows[0]["BenefitEnrollmentSent"].ToString()), 200, row_height, 0);


                    ///////////////////////////////////// New Page //////////////////////////////////
                    //cb.EndText();
                    //document.NewPage();
                    //row_height = 700;
                    //row_height -= 10;
                    //cb.BeginText();

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Benefits Overview:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["BenefitOverview"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Added to 401(k):  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["Added401k"].ToString()), 350, row_height, 0);
                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sales Support Training Completed:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["TrainingSalesSupport"].ToString()), 15, row_height, 0);
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "PB Training Completed:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["TrainingPBOC"].ToString()), 350, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Individual headshot:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["IndividualHeadshot"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Replicon Training Completed:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["TrainingReplicon"].ToString()), 350, row_height, 0);

                    //////////////////////////////////////////////////////////////////////////////////////////////
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Replicon counsel and projects:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["RepliconCounselProject"].ToString()), 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Alsbridge Overview Completed:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["AlsbridgeOverviewTraining"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "ADP Training:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["ADPPayroll"].ToString()), 350, row_height, 0);

                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Ordering an ALS Debit Card:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["AlsBridgeDebitCard"].ToString()), 15, row_height, 0);
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "References:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["Reference"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Resume:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["Resume"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Assessments:  " + ConvertToYesNo(odtEmpHRProcess.Rows[0]["Assessments"].ToString()), 350, row_height, 0);
                    ////////////////////////////////

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                else
                {
                    row_height -= 15;
                    //cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Final HR Process", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Pre-Onboarding ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Welcome Email sent with documents ", 15, row_height, 0);
                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "W4/W9:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "I9:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Direct Deposit Form:  ", 25, row_height, 0);
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Policy Signature Pages(4):  ", 25, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Schedule Onboarding:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Onboarding Agenda:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Run eVerify:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Conduct Background check:  ", 350, row_height, 0);
                    
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Offer Letter:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Employment Agreement:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Replicon counsel and internal projects:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Ordering an ALS Debit Card:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Added to Payroll (ADP or Pierian (India)):  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "New Hire Kit:  ", 350, row_height, 0);


                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "First Week ", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Added to Directory:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Welcome Lunch Scheduled:  ", 350, row_height, 0);
                   
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Benefits Overview:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Added to 401(k):  ", 350, row_height, 0);
                    
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Individual headshot:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Replicon Training Completed:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Alsbridge Overview Completed:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "ADP Training:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Resume:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Assessments:  ", 350, row_height, 0);
                    ////////////////////////////////

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                //========Code of Print Employee HR Process Details End

                // Close the document, the writer and the filestream!
                document.Close();
                writer.Close();
                //fs.Close();

                Response.Clear();
                Response.ClearHeaders();
                Response.Buffer = true;
                Response.Charset = "";
                //Response.ContentType = "application/excel";                
                this.EnableViewState = false;
                //Code to generate chart at excel file at client side              

                //modified for open direct without saving on server start

                Response.ContentType = "application/octet-stream";
                Response.AddHeader("content-disposition", "attachment;filename=" + filename);
                Response.Buffer = true;
                Response.Clear();
                var bytes = ms.ToArray();
                Response.OutputStream.Write(bytes, 0, bytes.Length);
                Response.OutputStream.Flush();

                //LblMsg.Text = "Invoiced saved to the invoice folder. Good job!";
            }
        }
        catch (Exception rror)
        {
            //LblMsg.Text = rror.Message;
            //MsgDiv.Visible = true;
            throw;
        }
    }

    private void GenerateOffBoardingEmpPDF(int EmployeeID)
    {

        //ods.Columns.Remove("Employee_Id");
        pdfPageHeaderFooter page = new pdfPageHeaderFooter();

        //int EmployeeID = 1;
        string EmployementType = string.Empty;
        DataTable odtEmpBasicDetails = new DataTable("offboardingEmpBasicDetails");
        DataTable odtOffBoardingEmpDetails = new DataTable("offboardingEmpDetails");

        odtEmpBasicDetails = GetEmpBasicDetails(EmployeeID, odtEmpBasicDetails);
        odtOffBoardingEmpDetails = GetOffBoardingEmpDetails(EmployeeID, odtOffBoardingEmpDetails);
        page.ReportHeader = "Resource OffBoarding";
        if (odtEmpBasicDetails.Rows.Count > 0)
        {
            EmployementType = odtEmpBasicDetails.Rows[0]["EmploymentType"].ToString();
        }
        if (odtEmpBasicDetails.Rows.Count > 0)
        {
            page.EmployeeName = odtEmpBasicDetails.Rows[0]["FirstName"].ToString() + " " + odtEmpBasicDetails.Rows[0]["MiddleInitial"].ToString() + " " + odtEmpBasicDetails.Rows[0]["LastName"].ToString();
            page.EmployementType = EmployementType;
            page.Address = odtEmpBasicDetails.Rows[0]["StreetAddress"].ToString() + " " + odtEmpBasicDetails.Rows[0]["AptUnit"].ToString();
            if (page.Address.Length > 95)
            {
                page.Address = page.Address.Substring(0, 94);
            }
            page.City = odtEmpBasicDetails.Rows[0]["City"].ToString();
            if (odtEmpBasicDetails.Rows[0]["Country"].ToString() != "")
            {
                page.State = odtEmpBasicDetails.Rows[0]["Country"].ToString() + ", " + odtEmpBasicDetails.Rows[0]["State"].ToString() + " " + odtEmpBasicDetails.Rows[0]["PostalCode"].ToString();
            }
            else
            {
                page.State = odtEmpBasicDetails.Rows[0]["State"].ToString() + " " + odtEmpBasicDetails.Rows[0]["PostalCode"].ToString();
            }

            page.Home = odtEmpBasicDetails.Rows[0]["HomePhone"].ToString();
            page.Cell = odtEmpBasicDetails.Rows[0]["CellPhone"].ToString();
            page.BusinessCard = odtEmpBasicDetails.Rows[0]["BusinessCardName"].ToString();
            page.EmailName = odtEmpBasicDetails.Rows[0]["CompanyEmailID"].ToString();
            page.PersonalEmail = odtEmpBasicDetails.Rows[0]["PerEmailID"].ToString();
        }

        try
        {
            string filename = "Offboarding Resource.pdf";


            //modified for open direct without saving on server used memory stream insted of filestream start

            using (var ms = new MemoryStream())
            {
                Document document = new Document(PageSize.A4, 10, 10, 110, 110);
                PdfWriter writer = PdfWriter.GetInstance(document, ms);


                writer.PageEvent = page;
                // Open the document to enable you to write to the document
                document.Open();
                // Makes it possible to add text to a specific place in the document using 
                // a X & Y placement syntax.
                PdfContentByte cb = writer.DirectContent;

                cb.BeginText();
                cb.MoveTo(25, 735);
                Font arial = FontFactory.GetFont("Arial", 7, Font.NORMAL, new Color(0, 0, 0));
                Font arial1 = FontFactory.GetFont("Arial", 7, Font.BOLD, new Color(0, 0, 0));

                int row_height = 700;
                //========Code of Print Employee Classification Start
                if (odtOffBoardingEmpDetails.Rows.Count > 0)
                {
                    //row_height -= 15;
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Employment Separation Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Last Day Worked:  " + ConvertToStringDate(odtOffBoardingEmpDetails.Rows[0]["LastDay"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Date of Separation:  " + ConvertToStringDate(odtOffBoardingEmpDetails.Rows[0]["SeparationDate"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Reason for Dismissal:  " + odtOffBoardingEmpDetails.Rows[0]["ReasonDismissal"].ToString(), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Forward email address to:  " + Server.HtmlDecode(odtOffBoardingEmpDetails.Rows[0]["ForwardEmailAddress"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "HR Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Select Source:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["SelectSource"].ToString()), 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Fidelity:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["Fidelity"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "ADP (Payroll & COBRA):  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["ADP"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Company Directory:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["CompanyDirectory"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Replicon:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["Replicon"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Headshot:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["HeadshotWiki"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Exit Interview:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["ExitInterview"].ToString()), 350, row_height, 0);

                    //New Changes
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Final Pay Review:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["FinalPayReview"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Termination Agreement (if applicable):  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["TerminationAgreement"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Enter final Pay into ADP:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["FinalPayADP"].ToString()), 15, row_height, 0);
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ":  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["FinalPayADP"].ToString()), 350, row_height, 0);

                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Notify Benefits team for COBRA:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["NotifyCOBRA"].ToString()), 15, row_height, 0);
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Disable from Benefits portal:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["DisablePortal"].ToString()), 350, row_height, 0);
                    //

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Admin Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Key Fob:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["KeyFob"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Key Card:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["KeyCard"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Security Code:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["AlarmCode"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Travel Access:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["TravelAccess"].ToString()), 350, row_height, 0);

                    //New Changes
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Disable FedEx/Kinkos card:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["DisableFedExKinkosCard"].ToString()), 15, row_height, 0);
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Remove from NING:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["RemoveNING"].ToString()), 350, row_height, 0);
                    //

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);

                    cb.Stroke();
                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sales & Marketing Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Bio from website:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["BioWebsite"].ToString()), 15, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Information Technology Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email Password Change:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["EmailPwdChange"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email forwarded To:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["EmailForwarded"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email archived and mail box disabled:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["EmailArchived"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Level3 Web-Connect Account:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["GomeetingConference"].ToString()), 350, row_height, 0);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Wiki access removed:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["WikiAccessRemoved"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Salesforce login disabled (if applicable):  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["SalesforceLogin"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "VPN disabled (if applicable):  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["VPNdisabled"].ToString()), 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Removed from printer:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["RemovedPrinter"].ToString()), 15, row_height, 0);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Remove from email groups:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["RemoveEmailGroups"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Send box to recover laptop:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["SendboxRecoverLaptop"].ToString()), 350, row_height, 0);

                    //New Changes
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Laptop/Hardware recovered:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["LaptopHardwareRecovered"].ToString()), 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Data archived:  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["BackupConducted"].ToString()), 350, row_height, 0);

                    //row_height -= 10;
                    //cb.SetFontAndSize(f_cn, 10);
                    //cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, , 15, row_height, 0);
                    ////cb.SetFontAndSize(f_cn, 10);
                    ////cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, ":  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["BackupConducted"].ToString()), 350, row_height, 0);
                    ////

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Additional access removed:  " + Server.HtmlDecode(odtOffBoardingEmpDetails.Rows[0]["AdditionalAccessRemoved"].ToString()), 15, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Final HR Process Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Ensure all areas are complete, Print completed report (sign + date) and File away in terms files. :  " + ConvertToYesNo(odtOffBoardingEmpDetails.Rows[0]["BioWebsite"].ToString()), 15, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                else
                {
                    cb.BeginText();
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Employment Separation Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Last Day Worked:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Date of Separation:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Reason for Dismissal:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Forward email address to:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "HR Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Fidelity:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "ADP (Payroll & COBRA):  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Company Directory:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Replicon:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Headshot:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Exit Interview:  ", 350, row_height, 0);

                    //New Changes
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Final Pay Review:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Termination Agreement (if applicable):  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Enter final Pay into ADP:  ", 15, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Admin Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Key Fob:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Key Card:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Security Code:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Travel Access:  ", 350, row_height, 0);

                    //New Changes
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Disable FedEx/Kinkos card:  ", 15, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);

                    cb.Stroke();
                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Sales & Marketing Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Bio from website:  ", 15, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Information Technology Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email Password Change:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email forwarded To:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Email archived and mail box disabled:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Level3 Web-Connect Account:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Salesforce login disabled (if applicable):  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "VPN disabled (if applicable):  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Remove from email groups:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Send box to recover laptop:  ", 350, row_height, 0);

                    //New Changes
                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Laptop/Hardware recovered:  ", 15, row_height, 0);
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Data archived:  ", 350, row_height, 0);

                    row_height -= 10;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Additional access removed:  ", 15, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();

                    row_height -= 15;
                    cb.SetFontAndSize(f_cb1, 11);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Final HR Process Details", 15, row_height, 0);

                    row_height -= 15;
                    cb.SetFontAndSize(f_cn, 10);
                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Ensure all areas are complete, Print completed report (sign + date) and File away in terms files. :  ", 15, row_height, 0);

                    row_height -= 10;
                    cb.SetLineWidth(0f);
                    cb.MoveTo(10, row_height);
                    cb.LineTo(585, row_height);
                    cb.Stroke();
                    cb.EndText();
                }
                //========Code of Print Employee Classification End


                // Close the document, the writer and the filestream!
                document.Close();
                writer.Close();
                //fs.Close();

                Response.Clear();
                Response.ClearHeaders();
                Response.Buffer = true;
                Response.Charset = "";
                //Response.ContentType = "application/excel";                
                this.EnableViewState = false;
                //Code to generate chart at excel file at client side              

                //modified for open direct without saving on server start

                Response.ContentType = "application/octet-stream";
                Response.AddHeader("content-disposition", "attachment;filename=" + filename);
                Response.Buffer = true;
                Response.Clear();
                var bytes = ms.ToArray();
                Response.OutputStream.Write(bytes, 0, bytes.Length);
                Response.OutputStream.Flush();

                //LblMsg.Text = "Invoiced saved to the invoice folder. Good job!";
            }
        }
        catch (Exception rror)
        {
            //LblMsg.Text = rror.Message;
            //MsgDiv.Visible = true;
            throw;
        }
    }

    private string ConvertToYesNo(string strValue)
    {
        strValue = strValue.Trim();
        if (strValue == null)
            return "No";
        else if (strValue == "")
            return "No";
        else if (strValue == "0")
            return "No";
        else if (strValue.ToLower() == "false")
            return "No";
        else if (strValue.ToLower() == "true")
            return "Yes";
        else if (strValue == "1")
            return "Yes";
        else
            return "No";
    }

    private string ConvertToStringDate(string strValue)
    {
        if (strValue == null)
            return "";
        else if (strValue == "")
            return "";
        else
        {
            DateTime dt = Convert.ToDateTime(strValue);
            if (dt.ToString("MM/dd/yyyy") == "01/01/1900")
            {
                return "";
            }
            else
            {
                return dt.ToString("MM/dd/yyyy");
            }
        }
    }

    private static DataTable GetEmpDetails(int EmployeeID, DataTable odtEmpDetails)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            odtEmpDetails = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select * from Employee.EmployeeDetails Where EmployeeID='" + EmployeeID + "'").Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmpDetails;
    }

    private static DataTable GetEmpBasicDetails(int EmployeeID, DataTable odtEmpDetails)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            string strquery = string.Empty;
            strquery = " Select ED.*, EC.* from Employee.EmployeeDetails ED ";
            strquery += " Left Join Employee.Classification EC on EC.EmployeeID = ED.EmployeeID ";
            strquery += " Where ED.EmployeeID=" + EmployeeID;
            odtEmpDetails = SqlHelper.ExecuteDataset(con, CommandType.Text, strquery).Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmpDetails;
    }//

    private static DataTable GetOffBoardingEmpDetails(int EmployeeID, DataTable odtEmpDetails)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            string strquery = string.Empty;
            strquery = " Select * from Employee.OffBoardingDetails Where EmployeeID=" + EmployeeID;
            odtEmpDetails = SqlHelper.ExecuteDataset(con, CommandType.Text, strquery).Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmpDetails;
    }

    private static DataTable GetEmpEmergencyDetails(int EmployeeID, DataTable odtEmergencyContact)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            odtEmergencyContact = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select * from Employee.EmergencyContact Where EmployeeID='" + EmployeeID + "'").Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmergencyContact;
    }
    private static DataTable GetEmpClassificationDetails(int EmployeeID, DataTable odtEmpClassification)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            string query = string.Empty;
            query = " Select ec.*, dd.DepartmentName from Employee.Classification ec";
            query += " left join Employee.Department dd on dd.DepartmentID = ec.DepartmentID";
            query += " Where EmployeeID='" + EmployeeID + "'";
            odtEmpClassification = SqlHelper.ExecuteDataset(con, CommandType.Text, query).Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmpClassification;
    }
    private static DataTable GetEmpITDetails(int EmployeeID, DataTable odtEmpIT)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            odtEmpIT = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select * from Employee.ITDetails Where EmployeeID='" + EmployeeID + "'").Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmpIT;
    }
    private static DataTable GetEmpMarketingDetails(int EmployeeID, DataTable odtEmpMarketing)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            odtEmpMarketing = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select * from Employee.Marketing Where EmployeeID='" + EmployeeID + "'").Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmpMarketing;
    }
    //
    private static DataTable GetEmpAdminDetails(int EmployeeID, DataTable odtEmpAdmin)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            odtEmpAdmin = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select * from Employee.Administrative Where EmployeeID='" + EmployeeID + "'").Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmpAdmin;
    }
    private static DataTable GetEmpSecurityDetails(int EmployeeID, DataTable odtEmpSecurity)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            odtEmpSecurity = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select * from Employee.Security Where EmployeeID='" + EmployeeID + "'").Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmpSecurity;
    }
    private static DataTable GetEmpMeetingDetails(int EmployeeID, DataTable odtEmpMeeting)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            odtEmpMeeting = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select * from Employee.Meeting Where EmployeeID='" + EmployeeID + "'").Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmpMeeting;
    }
    private static DataTable GetEmpPayrollDetails(int EmployeeID, DataTable odtEmpPayroll)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            odtEmpPayroll = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select * from Employee.Payroll Where EmployeeID='" + EmployeeID + "'").Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmpPayroll;
    }

    private static DataTable GetEmpPerformanceDetails(int EmployeeID, DataTable odtEmpPerformance)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            odtEmpPerformance = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select * from Employee.Performance Where EmployeeID='" + EmployeeID + "'").Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmpPerformance;
    }

    private static DataTable GetEmpHRProcessDetails(int EmployeeID, DataTable odtEmpHRProcess)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            odtEmpHRProcess = SqlHelper.ExecuteDataset(con, CommandType.Text, "Select * from Employee.HRProcess Where EmployeeID='" + EmployeeID + "'").Tables[0];
        }
        catch (Exception ex)
        {

        }
        return odtEmpHRProcess;
    }

    BaseFont f_cb1 = BaseFont.CreateFont("c:\\windows\\fonts\\calibrib.ttf", BaseFont.CP1257, BaseFont.NOT_EMBEDDED);
    BaseFont f_cb = BaseFont.CreateFont("c:\\windows\\fonts\\calibrib.ttf", BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
    BaseFont f_cn = BaseFont.CreateFont("c:\\windows\\fonts\\calibri.ttf", BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
    BaseFont f_ForColor = BaseFont.CreateFont("c:\\windows\\fonts\\calibri.ttf", BaseFont.CP1252, BaseFont.NOT_EMBEDDED);

    private void writeText(PdfContentByte cb, string Text, int X, int Y, BaseFont font, int Size)
    {
        cb.SetFontAndSize(font, Size);
        cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, Text, X, Y, 0);
    }

    public SortDirection dir
    {
        get
        {
            if (ViewState["dirState"] == null)
            {
                ViewState["dirState"] = SortDirection.Ascending;
            }
            return (SortDirection)ViewState["dirState"];
        }
        set
        {
            ViewState["dirState"] = value;
        }

    }
    protected void gvEmpListing_Sorting(object sender, GridViewSortEventArgs e)
    {
        string sortingDirection = string.Empty;
        if (dir == SortDirection.Ascending)
        {
            dir = SortDirection.Descending;
            sortingDirection = "Desc";
        }
        else
        {
            dir = SortDirection.Ascending;
            sortingDirection = "Asc";
        }

        ViewState["SortText"] = e.SortExpression;
        ViewState["SortValue"] = sortingDirection;
        FillGridView();
    }

    protected void ddlRecordPerPage_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["RecordPerPage"] = ddlRecordPerPage.SelectedItem.ToString();
        FillGridView();
    }

    protected void btnSearchResource_Click(object sender, EventArgs e)
    {
        if (txtSearchBox.Text.Trim() != "")
        {
            ViewState["SearchText"] = Server.HtmlEncode(txtSearchBox.Text);
            FillGridView();
        }
        else
        {
            txtSearchBox.Text = "";
            ViewState["SearchText"] = "";
            FillGridView();
        }
    }

    protected void lkbShowAll_Click(object sender, EventArgs e)
    {
        txtSearchBox.Text = "";
        ViewState["SearchText"] = "";
        FillGridView();
    }
}
