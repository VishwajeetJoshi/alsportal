﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;

public partial class createdepartment : System.Web.UI.Page
{
    CommonClass CC = new CommonClass();
    private string m_Mode = string.Empty;
    private string m_DepartmentID = string.Empty;
    private bool FixMode = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        if (Session["UserRole"] != null)
        {
            if (Session["UserRole"].ToString().ToLower().Contains("system admin") || Session["UserRole"].ToString().ToLower().Contains("hr"))
            { }
            else { Response.Redirect("~/loginpage.aspx?Mode=3"); }
        }

        SetQueryStringValue();

        if (!IsPostBack)
        {
            //FillDropDownList();
            Session["update"] = Server.UrlEncode(System.DateTime.Now.ToString());
            if (m_Mode == "edit")
            {
                PopulateDetails();
                lblHeaderText.InnerText = "Edit";
            }
            else
            {
                lblHeaderText.InnerText = "Add";
            }
        }
        MsgDiv.Visible = false;
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        ViewState["update"] = Session["update"];
    }

    private void PopulateDetails()
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@departmentid", Server.HtmlEncode(m_DepartmentID));
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetDepartmentViewDetails", sqlparam).Tables[0];
            if (odt.Rows.Count > 0)
            {
                txtDepartmentName.Text = IfNullThenBlank(odt.Rows[0]["DepartmentName"].ToString());
                cbConsultingESP.Checked = CC.IfNullThenZero(odt.Rows[0]["Consulting_ESP"].ToString());
                cbConsultingPP.Checked = CC.IfNullThenZero(odt.Rows[0]["Consulting_PP"].ToString());
                cbConsultingOp.Checked = CC.IfNullThenZero(odt.Rows[0]["Consulting_Op"].ToString());
                //cbVendorESP.Checked = CC.IfNullThenZero(odt.Rows[0]["Vendor_ESP"].ToString());
                //cbVendorPP.Checked = CC.IfNullThenZero(odt.Rows[0]["Vendor_PP"].ToString());
                
                //cbNSGOp.Checked = CC.IfNullThenZero(odt.Rows[0]["NSG_Op"].ToString());
                cbHSGOp.Checked = CC.IfNullThenZero(odt.Rows[0]["HSG_Op"].ToString());
                //cbUSUKP.Checked = CC.IfNullThenZero(odt.Rows[0]["US_UK_P"].ToString());

                cbWIPReview.Checked = CC.IfNullThenZero(odt.Rows[0]["WIPReview"].ToString());
                cbDealReview.Checked = CC.IfNullThenZero(odt.Rows[0]["DealReview"].ToString());
                cbMthlProbTeamCall.Checked = CC.IfNullThenZero(odt.Rows[0]["MnthProbCall"].ToString());
                cbWklEuropUdt.Checked = CC.IfNullThenZero(odt.Rows[0]["WklEuropeUdt"].ToString());
                cbWklVendorCall.Checked = CC.IfNullThenZero(odt.Rows[0]["WklVendorCall"].ToString());
                cbWklHWSWCall.Checked = CC.IfNullThenZero(odt.Rows[0]["WklHWSWCall"].ToString());
                cbSDTeamMtg.Checked = CC.IfNullThenZero(odt.Rows[0]["SDTeamMtg"].ToString());
                cbSSTeamMtg.Checked = CC.IfNullThenZero(odt.Rows[0]["SSTeamMtg"].ToString());
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("createuser.aspx", "PopulateDetails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    private string IfNullThenBlank(string value)
    {
        if (value == null)
        {
            return "";
        }
        else if (value == "")
        {
            return "";
        }
        else
        {
            return Server.HtmlDecode(value);
        }
    }

    private void SetQueryStringValue()
    {
        try
        {
            if (Request.QueryString["departmentid"] != null)
            {
                m_DepartmentID = Server.HtmlEncode(Request.QueryString["departmentid"]);
            }
            if (Request.QueryString["mode"] != null)
            {
                m_Mode = Request.QueryString["mode"];
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("createuser.aspx", "SetQueryStringValue", ex.Message);
            m_Mode = "add";
        }
    }

    private void Reset()
    {
        txtDepartmentName.Text = "";
        cbConsultingESP.Checked = false;
        cbConsultingOp.Checked = false;
        cbConsultingPP.Checked = false;
        cbHSGOp.Checked = false;
        
        //cbNSGOp.Checked = false;
        //cbVendorESP.Checked = false;
        //cbVendorPP.Checked = false;
        //cbUSUKP.Checked = false;

        cbWIPReview.Checked = false;
        cbDealReview.Checked = false;
        cbMthlProbTeamCall.Checked = false;
        cbWklEuropUdt.Checked = false;
        cbWklVendorCall.Checked = false;
        cbWklHWSWCall.Checked = false;
        cbSDTeamMtg.Checked = false;
        cbSSTeamMtg.Checked = false;
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (Session["update"].ToString() == ViewState["update"].ToString())
        {
            if (ValidateDetails() == false)
            {
                MsgDiv.Visible = true;
                return;
            }
            string role = string.Empty;
            if (m_Mode == "edit")
            {
                SqlConnection con = SqlHelper.GetConnection();
                con.Open();
                try
                {
                    SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@mode", "edit"),
                                    new SqlParameter("@Departmentid", m_DepartmentID),
                                    new SqlParameter("@DepartmentName", Server.HtmlEncode(txtDepartmentName.Text)),
                                    new SqlParameter("@ConsultingESP", CC.CheckBoxValue(cbConsultingESP)),
                                    new SqlParameter("@ConsultingPP", CC.CheckBoxValue(cbConsultingPP)),
                                    new SqlParameter("@ConsultingOp", CC.CheckBoxValue(cbConsultingOp)),                                  
                                    //new SqlParameter("@VendorESP", CC.CheckBoxValue(cbVendorESP)),
                                    //new SqlParameter("@VendorPP", CC.CheckBoxValue(cbVendorPP)),                                    
                                    //new SqlParameter("@NSGOp", CC.CheckBoxValue(cbNSGOp)),
                                    new SqlParameter("@HSGOp", CC.CheckBoxValue(cbHSGOp)),
                                    //new SqlParameter("@USUKP", CC.CheckBoxValue(cbUSUKP)),

                                    ////////////////////////////////////////////////////
                                    new SqlParameter("@WIPReview", CC.CheckBoxValue(cbWIPReview)),
                                    new SqlParameter("@DealReview", CC.CheckBoxValue(cbDealReview)),
                                    new SqlParameter("@MnthProbCall", CC.CheckBoxValue(cbMthlProbTeamCall)),
                                    new SqlParameter("@WklEuropeUdt", CC.CheckBoxValue(cbWklEuropUdt)),
                                    new SqlParameter("@WklVendorCall", CC.CheckBoxValue(cbWklVendorCall)),
                                    new SqlParameter("@WklHWSWCall", CC.CheckBoxValue(cbWklHWSWCall)),
                                    new SqlParameter("@SDTeamMtg", CC.CheckBoxValue(cbSDTeamMtg)),
                                    new SqlParameter("@SSTeamMtg", CC.CheckBoxValue(cbSSTeamMtg)),
                                    ////////////////////////////////////////////////////

                                    new SqlParameter("@CreatedBy", Session["UserName"])};

                    SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditDepartmentDetails", sqlparam);
                    Response.Redirect("createdepartmentview.aspx?departmentid=" + m_DepartmentID, false);
                }
                catch (Exception ex)
                {
                    CommonClass.AddErrorTrail("createdepartment.aspx", "btnSave_Click", ex.Message);
                    LblMsg.Text = "Oops! Server problem....try after some time";
                    MsgDiv.Visible = true;
                }
                finally { con.Close(); }
            }
            else
            {
                SqlConnection con = SqlHelper.GetConnection();
                con.Open();
                try
                {
                    SqlParameter[] sqlparam = new SqlParameter[] { 
                                     new SqlParameter("@mode", "add"),
                                    new SqlParameter("@DepartmentName", Server.HtmlEncode(txtDepartmentName.Text)),
                                    new SqlParameter("@ConsultingESP", CC.CheckBoxValue(cbConsultingESP)),
                                    new SqlParameter("@ConsultingPP", CC.CheckBoxValue(cbConsultingPP)),
                                    new SqlParameter("@ConsultingOp", CC.CheckBoxValue(cbConsultingOp)),                                  
                                    //new SqlParameter("@VendorESP", CC.CheckBoxValue(cbVendorESP)),
                                    //new SqlParameter("@VendorPP", CC.CheckBoxValue(cbVendorPP)),                                    
                                    //new SqlParameter("@NSGOp", CC.CheckBoxValue(cbNSGOp)),
                                    new SqlParameter("@HSGOp", CC.CheckBoxValue(cbHSGOp)),
                                    //new SqlParameter("@USUKP", CC.CheckBoxValue(cbUSUKP)),

                                     ////////////////////////////////////////////////////
                                    new SqlParameter("@WIPReview", CC.CheckBoxValue(cbWIPReview)),
                                    new SqlParameter("@DealReview", CC.CheckBoxValue(cbDealReview)),
                                    new SqlParameter("@MnthProbCall", CC.CheckBoxValue(cbMthlProbTeamCall)),
                                    new SqlParameter("@WklEuropeUdt", CC.CheckBoxValue(cbWklEuropUdt)),
                                    new SqlParameter("@WklVendorCall", CC.CheckBoxValue(cbWklVendorCall)),
                                    new SqlParameter("@WklHWSWCall", CC.CheckBoxValue(cbWklHWSWCall)),
                                    new SqlParameter("@SDTeamMtg", CC.CheckBoxValue(cbSDTeamMtg)),
                                    new SqlParameter("@SSTeamMtg", CC.CheckBoxValue(cbSSTeamMtg)),
                                    ////////////////////////////////////////////////////

                                    new SqlParameter("@CreatedBy", Session["UserName"])};

                    int i = SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditDepartmentDetails", sqlparam);
                    if (i > 0)
                    {
                        LblMsg.Text = "Record was added successfully";
                        Reset();
                    }
                    else
                    { LblMsg.Text = "Error in inserting department."; }
                    MsgDiv.Visible = true;
                }
                catch (Exception ex)
                {
                    CommonClass.AddErrorTrail("createdepartment.aspx", "btnSave_Click", ex.Message);
                    LblMsg.Text = "Oops! Server problem....try after some time";
                    MsgDiv.Visible = true;
                }
                finally { con.Close(); }
            }
            Session["update"] = Server.UrlEncode(System.DateTime.Now.ToString());
        }
        else
        {
            Reset();
        }
    }

    private bool ValidateDetails()
    {
        bool flag = true;
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@DepartmentName", Server.HtmlEncode(txtDepartmentName.Text.Trim()));
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_SearchExistDepartment", sqlparam).Tables[0];
            if (odt.Rows.Count > 0)
            {
                if (m_Mode == "edit")
                {
                    if (odt.Rows[0]["DepartmentID"].ToString() == m_DepartmentID)
                    {
                        flag = true;
                    }
                    else
                    {
                        LblMsg.Text = "Department already exits with the same name. Record can't be saved.";
                        flag = false;
                    }
                }
                else
                {
                    if (Convert.ToBoolean(odt.Rows[0]["IsDeleted"]) == false)
                    {
                        LblMsg.Text = "Department already exits with the same name. Record can't be saved.";
                        flag = false;
                    }
                    else
                    {
                        flag = true;
                    }
                }
            }
            else
            {
                flag = true;
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("createdepatment.aspx", "btnSave_Click", ex.Message);
            if (m_Mode == "add")
            {
                LblMsg.Text = "Error in inserting department details.";
            }
            else
            { LblMsg.Text = "Error in updating department details."; }
            flag = false;
        }
        finally
        { con.Close(); }

        return flag;
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Reset();
    }

    protected void btnBack_Click(object sender, EventArgs e)
    {
        if (m_Mode == "edit")
        {
            Response.Redirect("createdepartmentview.aspx?departmentid=" + m_DepartmentID);
        }
        else
        {
            Response.Redirect("createdepartmentview.aspx");
        }
    }


}
