﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;
using System.Globalization;

public partial class informationtechnology : System.Web.UI.Page
{
    CommonClass CC = new CommonClass();
    private string m_Mode = string.Empty;
    private int m_EmployeeID;
    private bool FixMode = false;
    MailSender oMailSender = new MailSender();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        SetQueryStringValue();

        if (!IsPostBack)
        {
            FillEmployeeClassification();
        }
        MsgDiv.Visible = false;
    }

    private void SetQueryStringValue()
    {
        try
        {
            if (Request.QueryString["EmployeeID"] != null)
            {
                m_EmployeeID = Convert.ToInt32(Request.QueryString["EmployeeID"]);
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("finalhrprocess.aspx", "SetQueryStringValue", ex.Message);
            m_Mode = "Add";
            m_EmployeeID = 0;
        }
    }

    private void SetUserRole()
    {
        if (Session["UserRole"] != null)
        {
            if (m_EmployeeID > 0)
            { divSave.Visible = true; }
            else
            { divSave.Visible = false; }
        }
    }

    protected override void Render(HtmlTextWriter writer)
    {
        SetUserRole();
        base.Render(writer);
    }

    private void FillEmployeeClassification()
    {
        PopulateDetails();
        if (FixMode == true)
        {
            EnableDisable(true);
            divSave.Visible = false;
        }
    }

    private void PopulateDetails()
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetITDetails", sqlparam).Tables[0];
            if (odt.Rows.Count > 0)
            {
                txtEmailAddress.Text = IfNullThenBlank(odt.Rows[0]["EmailAddress"].ToString());
                cbEmailSignatures.Checked = CC.IfNullThenZero(odt.Rows[0]["EmailSign_Alsbridge"].ToString());
                cbTeamList.Checked = CC.IfNullThenZero(odt.Rows[0]["TeamList"].ToString());
                txtOtherTeamList.Text = IfNullThenBlank(odt.Rows[0]["TeamList_Other"].ToString());
                //cbOfficeLocationDallas.Checked = CC.IfNullThenZero(odt.Rows[0]["OfficeLocation_Dallas"].ToString());
                cbOfficeLocationRemote.Checked = CC.IfNullThenZero(odt.Rows[0]["OfficeLocation_Remote"].ToString());
                txtDallasPhyExtention.Text = IfNullThenBlank(odt.Rows[0]["Dallas_PhyExtention"].ToString());
                txtDallasDirectNo.Text = IfNullThenBlank(odt.Rows[0]["Dallas_DirectNo"].ToString());
                txtRemoteRedirectNo.Text = IfNullThenBlank(odt.Rows[0]["Remote_RedirectNo"].ToString());
                txtLaptopAssest.Text = IfNullThenBlank(odt.Rows[0]["LaptopAssest"].ToString());
                //cbAdobeReader.Checked = CC.IfNullThenZero(odt.Rows[0]["AdobeReader"].ToString());
                //cbMSOffice.Checked = CC.IfNullThenZero(odt.Rows[0]["MSOffice"].ToString());
                //Added on 170614
                //cbLync.Checked = CC.IfNullThenZero(odt.Rows[0]["Lync"].ToString());
                //cbWiki.Checked = CC.IfNullThenZero(odt.Rows[0]["Wiki"].ToString());
                //cbGTMmeeting.Checked = CC.IfNullThenZero(odt.Rows[0]["GTMmeeting"].ToString());
                //cbAVG.Checked = CC.IfNullThenZero(odt.Rows[0]["AVG"].ToString());
                //cbPrinters.Checked = CC.IfNullThenZero(odt.Rows[0]["Printers"].ToString());
                //cbJungleDisk.Checked = CC.IfNullThenZero(odt.Rows[0]["JungleDisk"].ToString());
                //cbPDFCreator.Checked = CC.IfNullThenZero(odt.Rows[0]["PDFCreator"].ToString());
                //cbAddShortcuts.Checked = CC.IfNullThenZero(odt.Rows[0]["AddShortcuts"].ToString());
                //cbMapJDdocsdesktop.Checked = CC.IfNullThenZero(odt.Rows[0]["MapJDdocsdesktop"].ToString());
                //cbSupportMail.Checked = CC.IfNullThenZero(odt.Rows[0]["SupportMail"].ToString());
                //cbSDcard.Checked = CC.IfNullThenZero(odt.Rows[0]["SDcard"].ToString());
                //cbYesGTMLicense.Checked = CC.IfNullThenZero(odt.Rows[0]["YesGTMLicense"].ToString());
                //cbConfirmGTMLicense.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmGTMLicense"].ToString());                
                //cbYesWebexLicense.Checked = CC.IfNullThenZero(odt.Rows[0]["YesWebexLicense"].ToString());
                //cbConfirmWebexLicense.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmWebexLicense"].ToString());
                cbYesMSProject.Checked = CC.IfNullThenZero(odt.Rows[0]["YesMSProject"].ToString());
                cbConfirmMSProject.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmMSProject"].ToString());

                cbYesMSVisio.Checked = CC.IfNullThenZero(odt.Rows[0]["YesMSVisio"].ToString());
                cbConfirmMSVisio.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmMSVisio"].ToString());
                //cbYesVPN.Checked = CC.IfNullThenZero(odt.Rows[0]["YesVPN"].ToString());
                //cbConfirmVPN.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmVPN"].ToString());
                cbYesSalesforce.Checked = CC.IfNullThenZero(odt.Rows[0]["YesSalesforce"].ToString());
                cbConfirmSalesforce.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmSalesforce"].ToString());
                cbYesInsideView.Checked = CC.IfNullThenZero(odt.Rows[0]["YesInsideView"].ToString());
                cbConfirmInsideView.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmInsideView"].ToString());

                cbYesPowerDialer.Checked = CC.IfNullThenZero(odt.Rows[0]["YesPowerDialer"].ToString());
                cbConfirmPowerDialer.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmPowerDialer"].ToString());
                cbYesRRUS.Checked = CC.IfNullThenZero(odt.Rows[0]["YesRRUS"].ToString());
                cbConfirmRRUS.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmRRUS"].ToString());

                cbYesDiscoverOrg.Checked = CC.IfNullThenZero(odt.Rows[0]["YesDiscoverOrg"].ToString());
                cbConfirmDiscoverOrg.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmDiscoverOrg"].ToString());

                cbYesAlsbridgesalesMail.Checked = CC.IfNullThenZero(odt.Rows[0]["YesAlsbridgesalesMail"].ToString());
                cbConfirmAlsbridgesalesMail.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmAlsbridgesalesMail"].ToString());

                cbYesPbsalesMail.Checked = CC.IfNullThenZero(odt.Rows[0]["YesPbsalesMail"].ToString());
                cbConfirmPbsalesMail.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmPbsalesMail"].ToString());
                txtAdditionalComment.Text = IfNullThenBlank(odt.Rows[0]["AdditionalComment"].ToString());

                //new fields added 280912
                cbDockingStattion.Checked = CC.IfNullThenZero(odt.Rows[0]["WS_DockingStation"].ToString());
                cbStand.Checked = CC.IfNullThenZero(odt.Rows[0]["WS_Stand"].ToString());
                cbMonitor.Checked = CC.IfNullThenZero(odt.Rows[0]["WS_Monitor"].ToString());
                cbKeyboard.Checked = CC.IfNullThenZero(odt.Rows[0]["WS_Keyboard"].ToString());
                cbMouse.Checked = CC.IfNullThenZero(odt.Rows[0]["WS_Mouse"].ToString());
                cbPhone.Checked = CC.IfNullThenZero(odt.Rows[0]["WS_Phone"].ToString());

                //New fields added on 190814
                cbExtraBattery.Checked = CC.IfNullThenZero(odt.Rows[0]["ExtraBattery"].ToString());
                cbExtraPowerCord.Checked = CC.IfNullThenZero(odt.Rows[0]["ExtraPowerCord"].ToString());
                cbServiceTag.Checked = CC.IfNullThenZero(odt.Rows[0]["ServiceTag"].ToString());
                cbYesAPStylebook.Checked = CC.IfNullThenZero(odt.Rows[0]["YesAPStylebook"].ToString());
                cbConfirmAPStylebook.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmAPStylebook"].ToString());

                cbITCheklistComp.Checked = CC.IfNullThenZero(odt.Rows[0]["ITCheklistComp"].ToString());
                cbITOpearationSession.Checked = CC.IfNullThenZero(odt.Rows[0]["ITOpearationSession"].ToString());
                //cbPCShipped.Checked = CC.IfNullThenZero(odt.Rows[0]["PCShipped"].ToString());
                if (DBNull.Value != (odt.Rows[0]["PCShipped"]))
                {
                    DateTime dt;
                    dt = Convert.ToDateTime(odt.Rows[0]["PCShipped"].ToString());
                    txtPCShippedDate.Text = CC.checkdate(dt);
                }

                ListItem selectedListItem = ddlOfficeLocation.Items.FindByText(odt.Rows[0]["OfficeLocation"].ToString());
                if (selectedListItem != null)
                {
                    selectedListItem.Selected = true;
                }

                ListItem selectedLatopTypeItem = ddlLaptopType.Items.FindByText(odt.Rows[0]["LaptopType"].ToString());
                if (selectedLatopTypeItem != null)
                {
                    selectedLatopTypeItem.Selected = true;
                }
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("informationtechnology.aspx", "PopulateDetails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    private string IfNullThenBlank(string value)
    {
        if (value == null)
        {
            return "";
        }
        else if (value == "")
        {
            return "";
        }
        else
        {
            return Server.HtmlDecode(value);
        }
    }

    private void Reset()
    {
        txtEmailAddress.Text = "";
        cbEmailSignatures.Checked = false;

        cbTeamList.Checked = false;
        txtOtherTeamList.Text = "";
        //cbOfficeLocationDallas.Checked = false;
        cbOfficeLocationRemote.Checked = false;
        txtDallasPhyExtention.Text = "";
        txtDallasDirectNo.Text = "";
        txtRemoteRedirectNo.Text = "";
        txtLaptopAssest.Text = "";

        //cbAdobeReader.Checked = false;
        //cbMSOffice.Checked = false;
        //cbWiki.Checked = false;
        //cbGTMmeeting.Checked = false;
        //cbAVG.Checked = false;
        //cbPrinters.Checked = false;
        //cbJungleDisk.Checked = false;
        //cbPDFCreator.Checked = false;
        //cbAddShortcuts.Checked = false;
        //cbMapJDdocsdesktop.Checked = false;
        //cbSupportMail.Checked = false;
        //cbSDcard.Checked = false;
        //cbYesGTMLicense.Checked = false;
        //cbConfirmGTMLicense.Checked = false;

        //cbYesWebexLicense.Checked = false;
        //cbConfirmWebexLicense.Checked = false;
        cbYesMSProject.Checked = false;
        cbConfirmMSProject.Checked = false;
        cbYesMSVisio.Checked = false;
        cbConfirmMSVisio.Checked = false;
        //cbYesVPN.Checked = false;
        //cbConfirmVPN.Checked = false;
        cbYesSalesforce.Checked = false;
        cbConfirmSalesforce.Checked = false;
        cbYesInsideView.Checked = false;
        cbConfirmInsideView.Checked = false;

        cbYesPowerDialer.Checked = false;
        cbConfirmPowerDialer.Checked = false;
        cbYesRRUS.Checked = false;
        cbConfirmRRUS.Checked = false;

        cbYesDiscoverOrg.Checked = false;
        cbConfirmDiscoverOrg.Checked = false;

        cbYesAlsbridgesalesMail.Checked = false;
        cbConfirmAlsbridgesalesMail.Checked = false;
        cbYesPbsalesMail.Checked = false;
        cbConfirmPbsalesMail.Checked = false;
        txtAdditionalComment.Text = "";

        //New fields added 280912
        cbDockingStattion.Checked = false;
        cbStand.Checked = false;
        cbMonitor.Checked = false;
        cbKeyboard.Checked = false;
        cbMouse.Checked = false;
        cbPhone.Checked = false;

        //Added on 170614
        //cbLync.Checked = false;

        //New fields added on 190814
        cbExtraBattery.Checked = false;
        cbExtraPowerCord.Checked = false;
        cbServiceTag.Checked = false;
        cbYesAPStylebook.Checked = false;
        cbConfirmAPStylebook.Checked = false;

        cbITCheklistComp.Checked = false;
        cbITOpearationSession.Checked = false;
        //cbPCShipped.Checked = false;
        txtPCShippedDate.Text = "";
        ddlOfficeLocation.SelectedIndex = 0;
        ddlLaptopType.SelectedIndex = 0;
    }

    private void EnableDisable(bool boolValue)
    {
        //txtEmailAddress.Text = "";
        //txtReplicon.Text = "";
        //txtAIMID.Text = "";
        //txtSkypID.Text = "";
        //cbEmailSignAlsbridge.Checked = false;
        //cbEmailSignProbenchmark.Checked = false;
        //cbEmailSignNSG.Checked = false;
        //cbEmailSignOC.Checked = false;
        //cbMainExchangeAlsbridge.Checked = false;
        //cbMainExchangeProbenchmark.Checked = false;
        //cbMainExchangeOC.Checked = false;
        //cbPOPAlsbridge.Checked = false;
        //cbPOPProbenchmark.Checked = false;
        //cbEmailServer.Checked = false;
        //cbVoicemailLink.Checked = false;
        //cbTeamList.Checked = false;
        //txtOtherTeamList.Text = "";
        //cbOfficeLocationDallas.Checked = false;
        //cbOfficeLocationRemote.Checked = false;
        //txtDallasPhyExtention.Text = "";
        //txtDallasDirectNo.Text = "";
        //txtRemoteVirtExtention.Text = "";
        //txtRemoteRedirectNo.Text = "";
        //txtDirectDialNo.Text = "";
        //txtExtention.Text = "";
        //txtConferenceCallBridge.Text = "";
        //txtLaptopAssest.Text = "";
        //cbMessengerAIM.Checked = false;
        //cbMessengerSkype.Checked = false;
        //cbImportContactsAIM.Checked = false;
        //cbImportContactsSkype.Checked = false;
        //cbImportContactsNing.Checked = false;
        //cbOIAdobeReader.Checked = false;
        //cbOIOffice.Checked = false;
        //cbOIProject.Checked = false;
        //cbOIVisio.Checked = false;
        //cbOIWiki.Checked = false;
        //cbOIGTMLicense.Checked = false;
        //cbOIDedicatedConfNo.Checked = false;
        //cbOIAVG.Checked = false;
        //cbOIPrinters.Checked = false;
        //cbOIJungleDisk.Checked = false;
        //cbOIPDFCreator.Checked = false;
        //cbOIGTM.Checked = false;
        //cbOIVPN.Checked = false;
        //cbOISharePoint.Checked = false;
        //cbOIMyAlsbridge.Checked = false;
        //cbOIWebmail.Checked = false;
        //cbOIBackUp.Checked = false;
        //cbOIEmailSign.Checked = false;
        //cbOIGoToMeeting.Checked = false;
        //cbOIShortcuts.Checked = false;
        //cbOIMapJungleDisk.Checked = false;
        //cbOISDCard.Checked = false;
        //cbOICorporateWebsiteShortcut.Checked = false;
        //cbOIWikiRemoteWebmailShortcut.Checked = false;
        //cbOISendEmailActivationInfo.Checked = false;
        //cbOIAssociateWithURLLogins.Checked = false;
        //cbOISecurityCodeEnabled.Checked = false;
        //cbOIOutlookContLoaded.Checked = false;
        //cbOIITServiceEmailSent.Checked = false;
        //cbOIInfoSentToHR.Checked = false;
        //cbOISwInfoEmailedToSupport.Checked = false;
        //txtOIAdditionalComment.InnerText = "";
        //cbNameSalesforce.Checked = false;
        //cbNameInsideView.Checked = false;
        //cbRRUS.Checked = false;
        //cbRREU.Checked = false;
        //cbMailingListAlsbridgesales.Checked = false;
        //cbTitleLeadlander.Checked = false;
        //cbTitlePowerDialer.Checked = false;
        //cbRRDiscoverOrg.Checked = false;
        //cbRRAutoEmails.Checked = false;
        //cbMailingListpbsales.Checked = false;
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        string _OfficeLocation = string.Empty;
        if (ddlOfficeLocation.SelectedIndex != 0)
        {
            _OfficeLocation = ddlOfficeLocation.SelectedItem.ToString();
        }

        string _LaptopType = string.Empty;
        if (ddlLaptopType.SelectedIndex != 0)
        {
            _LaptopType = ddlLaptopType.SelectedItem.ToString();
        }

        //IT date start
        DateTime PCShippingDate;
        if (txtPCShippedDate.Text != "")
            PCShippingDate = DateTime.ParseExact(txtPCShippedDate.Text, "MM/dd/yyyy", CultureInfo.CurrentCulture);
        else
            PCShippingDate = Convert.ToDateTime("01/01/1900");
        //IT date end

        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@EmployeeID", m_EmployeeID),
                                    new SqlParameter("@EmailAddress", Server.HtmlEncode(txtEmailAddress.Text)),
                                    new SqlParameter("@EmailSign_Alsbridge", CC.CheckBoxValue(cbEmailSignatures)),
                                    new SqlParameter("@TeamList", CC.CheckBoxValue(cbTeamList)),
                                    new SqlParameter("@TeamList_Other", Server.HtmlEncode(txtOtherTeamList.Text)),
                                    //new SqlParameter("@OfficeLocation_Dallas", CC.CheckBoxValue(cbOfficeLocationDallas)),
                                    new SqlParameter("@OfficeLocation_Remote", CC.CheckBoxValue(cbOfficeLocationRemote)),
                                    new SqlParameter("@Dallas_PhyExtention", Server.HtmlEncode(txtDallasPhyExtention.Text)),
                                    new SqlParameter("@Dallas_DirectNo", Server.HtmlEncode(txtDallasDirectNo.Text)),
                                    new SqlParameter("@Remote_RedirectNo", Server.HtmlEncode(txtRemoteRedirectNo.Text)),
                                    new SqlParameter("@LaptopAssest", Server.HtmlEncode(txtLaptopAssest.Text)),
                                    //new SqlParameter("@AdobeReader", CC.CheckBoxValue(cbAdobeReader)),
                                    //new SqlParameter("@MSOffice", CC.CheckBoxValue(cbMSOffice)),
                                    //new SqlParameter("@Wiki", CC.CheckBoxValue(cbWiki)),
                                    //new SqlParameter("@GTMmeeting", CC.CheckBoxValue(cbGTMmeeting)),
                                    //new SqlParameter("@AVG", CC.CheckBoxValue(cbAVG)),
                                    //new SqlParameter("@Printers", CC.CheckBoxValue(cbPrinters)),
                                    //new SqlParameter("@JungleDisk", CC.CheckBoxValue(cbJungleDisk)),
                                    //new SqlParameter("@AddShortcuts", CC.CheckBoxValue(cbAddShortcuts)),
                                    //new SqlParameter("@PDFCreator", CC.CheckBoxValue(cbPDFCreator)),
                                    //new SqlParameter("@MapJDdocsdesktop", CC.CheckBoxValue(cbMapJDdocsdesktop)),
                                    //new SqlParameter("@SupportMail", CC.CheckBoxValue(cbSupportMail)),
                                    //new SqlParameter("@SDcard", CC.CheckBoxValue(cbSDcard)),
                                    //new SqlParameter("@YesGTMLicense", CC.CheckBoxValue(cbYesGTMLicense)),
                                    //new SqlParameter("@ConfirmGTMLicense", CC.CheckBoxValue(cbConfirmGTMLicense)),
                                    //new SqlParameter("@YesWebexLicense", CC.CheckBoxValue(cbYesWebexLicense)),
                                    //new SqlParameter("@ConfirmWebexLicense", CC.CheckBoxValue(cbConfirmWebexLicense)),
                                    new SqlParameter("@YesMSProject", CC.CheckBoxValue(cbYesMSProject)),
                                    new SqlParameter("@ConfirmMSProject", CC.CheckBoxValue(cbConfirmMSProject)),
                                    new SqlParameter("@YesMSVisio", CC.CheckBoxValue(cbYesMSVisio)),
                                    new SqlParameter("@ConfirmMSVisio", CC.CheckBoxValue(cbConfirmMSVisio)),
                                    //new SqlParameter("@YesVPN", CC.CheckBoxValue(cbYesVPN)),
                                    //new SqlParameter("@ConfirmVPN", CC.CheckBoxValue(cbConfirmVPN)),
                                    new SqlParameter("@YesSalesforce", CC.CheckBoxValue(cbYesSalesforce)),
                                    new SqlParameter("@ConfirmSalesforce", CC.CheckBoxValue(cbConfirmSalesforce)),
                                    new SqlParameter("@YesInsideView", CC.CheckBoxValue(cbYesInsideView)),
                                    new SqlParameter("@ConfirmInsideView", CC.CheckBoxValue(cbConfirmInsideView)),
                                    new SqlParameter("@YesPowerDialer", CC.CheckBoxValue(cbYesPowerDialer)),
                                    new SqlParameter("@ConfirmPowerDialer", CC.CheckBoxValue(cbConfirmPowerDialer)),
                                    new SqlParameter("@YesRRUS", CC.CheckBoxValue(cbYesRRUS)),
                                    new SqlParameter("@ConfirmRRUS", CC.CheckBoxValue(cbConfirmRRUS)),
                                    new SqlParameter("@YesDiscoverOrg", CC.CheckBoxValue(cbYesDiscoverOrg)),
                                    new SqlParameter("@ConfirmDiscoverOrg", CC.CheckBoxValue(cbConfirmDiscoverOrg)),
                                    new SqlParameter("@YesAlsbridgesalesMail", CC.CheckBoxValue(cbYesAlsbridgesalesMail)),
                                    new SqlParameter("@ConfirmAlsbridgesalesMail", CC.CheckBoxValue(cbConfirmAlsbridgesalesMail)),
                                    new SqlParameter("@YesPbsalesMail", CC.CheckBoxValue(cbYesPbsalesMail)),
                                    new SqlParameter("@ConfirmPbsalesMail", CC.CheckBoxValue(cbConfirmPbsalesMail)),
                                    new SqlParameter("@AdditionalComment", Server.HtmlEncode(txtAdditionalComment.Text)),
                                    new SqlParameter("@WS_DockingStation", CC.CheckBoxValue(cbDockingStattion)),
                                    new SqlParameter("@WS_Stand", CC.CheckBoxValue(cbStand)),
                                    new SqlParameter("@WS_Monitor", CC.CheckBoxValue(cbMonitor)),
                                    new SqlParameter("@WS_Keyboard", CC.CheckBoxValue(cbKeyboard)),
                                    new SqlParameter("@WS_Mouse", CC.CheckBoxValue(cbMouse)),
                                    new SqlParameter("@WS_Phone", CC.CheckBoxValue(cbPhone)),
                                    //Added on 170614 
                                    //new SqlParameter("@Lync", CC.CheckBoxValue(cbLync)),
                                    
                                    //New fields added on 190814
                                    new SqlParameter("@ExtraBattery", CC.CheckBoxValue(cbExtraBattery)),
                                    new SqlParameter("@ExtraPowerCord", CC.CheckBoxValue(cbExtraPowerCord)),
                                    new SqlParameter("@ServiceTag", CC.CheckBoxValue(cbServiceTag)),
                                    new SqlParameter("@YesAPStylebook", CC.CheckBoxValue(cbYesAPStylebook)),
                                    new SqlParameter("@ConfirmAPStylebook", CC.CheckBoxValue(cbConfirmAPStylebook)),
                                    new SqlParameter("@ITCheklistComp", CC.CheckBoxValue(cbITCheklistComp)),
                                    new SqlParameter("@ITOpearationSession", CC.CheckBoxValue(cbITOpearationSession)),
                                    new SqlParameter("@PCShipped", PCShippingDate),
                                    new SqlParameter("@OfficeLocation", _OfficeLocation),
                                    new SqlParameter("@LaptopType", _LaptopType),
                                    
                                    new SqlParameter("@FixMode", false),
                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditITDetails", sqlparam);
            LblMsg.Text = "Record was updated successfully";
            MsgDiv.Visible = true;
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("informationtechnology.aspx", "btnSave_Click", ex.Message);
            LblMsg.Text = "Oops! Server problem....try after some time";
            MsgDiv.Visible = true;
        }
        finally { con.Close(); }
    }
    protected void btnSaveSubmit_Click(object sender, EventArgs e)
    {
        string _OfficeLocation = string.Empty;
        if (ddlOfficeLocation.SelectedIndex != 0)
        {
            _OfficeLocation = ddlOfficeLocation.SelectedItem.ToString();
        }

        string _LaptopType = string.Empty;
        if (ddlLaptopType.SelectedIndex != 0)
        {
            _LaptopType = ddlLaptopType.SelectedItem.ToString();
        }
        
        //IT date start        
        DateTime PCShippingDate;
        if (txtPCShippedDate.Text != "")
            PCShippingDate = DateTime.ParseExact(txtPCShippedDate.Text, "MM/dd/yyyy", CultureInfo.CurrentCulture);
        else
            PCShippingDate = Convert.ToDateTime("01/01/1900");
        //IT date end

        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@EmployeeID", m_EmployeeID),
                                    new SqlParameter("@EmailAddress", Server.HtmlEncode(txtEmailAddress.Text)),
                                    new SqlParameter("@EmailSign_Alsbridge", CC.CheckBoxValue(cbEmailSignatures)),
                                    new SqlParameter("@TeamList", CC.CheckBoxValue(cbTeamList)),
                                    new SqlParameter("@TeamList_Other", Server.HtmlEncode(txtOtherTeamList.Text)),
                                    //new SqlParameter("@OfficeLocation_Dallas", CC.CheckBoxValue(cbOfficeLocationDallas)),
                                    new SqlParameter("@OfficeLocation_Remote", CC.CheckBoxValue(cbOfficeLocationRemote)),
                                    new SqlParameter("@Dallas_PhyExtention", Server.HtmlEncode(txtDallasPhyExtention.Text)),
                                    new SqlParameter("@Dallas_DirectNo", Server.HtmlEncode(txtDallasDirectNo.Text)),
                                    new SqlParameter("@Remote_RedirectNo", Server.HtmlEncode(txtRemoteRedirectNo.Text)),
                                    new SqlParameter("@LaptopAssest", Server.HtmlEncode(txtLaptopAssest.Text)),
                                    //new SqlParameter("@AdobeReader", CC.CheckBoxValue(cbAdobeReader)),
                                    //new SqlParameter("@MSOffice", CC.CheckBoxValue(cbMSOffice)),
                                    //new SqlParameter("@Wiki", CC.CheckBoxValue(cbWiki)),
                                    //new SqlParameter("@GTMmeeting", CC.CheckBoxValue(cbGTMmeeting)),
                                    //new SqlParameter("@AVG", CC.CheckBoxValue(cbAVG)),
                                    //new SqlParameter("@Printers", CC.CheckBoxValue(cbPrinters)),
                                    //new SqlParameter("@JungleDisk", CC.CheckBoxValue(cbJungleDisk)),
                                    //new SqlParameter("@AddShortcuts", CC.CheckBoxValue(cbAddShortcuts)),
                                    //new SqlParameter("@PDFCreator", CC.CheckBoxValue(cbPDFCreator)),
                                    //new SqlParameter("@MapJDdocsdesktop", CC.CheckBoxValue(cbMapJDdocsdesktop)),
                                    //new SqlParameter("@SupportMail", CC.CheckBoxValue(cbSupportMail)),
                                    //new SqlParameter("@SDcard", CC.CheckBoxValue(cbSDcard)),
                                    //new SqlParameter("@YesGTMLicense", CC.CheckBoxValue(cbYesGTMLicense)),
                                    //new SqlParameter("@ConfirmGTMLicense", CC.CheckBoxValue(cbConfirmGTMLicense)),
                                    //new SqlParameter("@YesWebexLicense", CC.CheckBoxValue(cbYesWebexLicense)),
                                    //new SqlParameter("@ConfirmWebexLicense", CC.CheckBoxValue(cbConfirmWebexLicense)),
                                    new SqlParameter("@YesMSProject", CC.CheckBoxValue(cbYesMSProject)),
                                    new SqlParameter("@ConfirmMSProject", CC.CheckBoxValue(cbConfirmMSProject)),
                                    new SqlParameter("@YesMSVisio", CC.CheckBoxValue(cbYesMSVisio)),
                                    new SqlParameter("@ConfirmMSVisio", CC.CheckBoxValue(cbConfirmMSVisio)),
                                    //new SqlParameter("@YesVPN", CC.CheckBoxValue(cbYesVPN)),
                                    //new SqlParameter("@ConfirmVPN", CC.CheckBoxValue(cbConfirmVPN)),
                                    new SqlParameter("@YesSalesforce", CC.CheckBoxValue(cbYesSalesforce)),
                                    new SqlParameter("@ConfirmSalesforce", CC.CheckBoxValue(cbConfirmSalesforce)),
                                    new SqlParameter("@YesInsideView", CC.CheckBoxValue(cbYesInsideView)),
                                    new SqlParameter("@ConfirmInsideView", CC.CheckBoxValue(cbConfirmInsideView)),
                                    new SqlParameter("@YesPowerDialer", CC.CheckBoxValue(cbYesPowerDialer)),
                                    new SqlParameter("@ConfirmPowerDialer", CC.CheckBoxValue(cbConfirmPowerDialer)),
                                    new SqlParameter("@YesRRUS", CC.CheckBoxValue(cbYesRRUS)),
                                    new SqlParameter("@ConfirmRRUS", CC.CheckBoxValue(cbConfirmRRUS)),
                                    new SqlParameter("@YesDiscoverOrg", CC.CheckBoxValue(cbYesDiscoverOrg)),
                                    new SqlParameter("@ConfirmDiscoverOrg", CC.CheckBoxValue(cbConfirmDiscoverOrg)),
                                    new SqlParameter("@YesAlsbridgesalesMail", CC.CheckBoxValue(cbYesAlsbridgesalesMail)),
                                    new SqlParameter("@ConfirmAlsbridgesalesMail", CC.CheckBoxValue(cbConfirmAlsbridgesalesMail)),
                                    new SqlParameter("@YesPbsalesMail", CC.CheckBoxValue(cbYesPbsalesMail)),
                                    new SqlParameter("@ConfirmPbsalesMail", CC.CheckBoxValue(cbConfirmPbsalesMail)),
                                    new SqlParameter("@AdditionalComment", Server.HtmlEncode(txtAdditionalComment.Text)),
                                    new SqlParameter("@WS_DockingStation", CC.CheckBoxValue(cbDockingStattion)),
                                    new SqlParameter("@WS_Stand", CC.CheckBoxValue(cbStand)),
                                    new SqlParameter("@WS_Monitor", CC.CheckBoxValue(cbMonitor)),
                                    new SqlParameter("@WS_Keyboard", CC.CheckBoxValue(cbKeyboard)),
                                    new SqlParameter("@WS_Mouse", CC.CheckBoxValue(cbMouse)),
                                    new SqlParameter("@WS_Phone", CC.CheckBoxValue(cbPhone)),  
                                    //Added on 170614 
                                    //new SqlParameter("@Lync", CC.CheckBoxValue(cbLync)),

                                    //New fields added on 190814
                                    new SqlParameter("@ExtraBattery", CC.CheckBoxValue(cbExtraBattery)),
                                    new SqlParameter("@ExtraPowerCord", CC.CheckBoxValue(cbExtraPowerCord)),
                                    new SqlParameter("@ServiceTag", CC.CheckBoxValue(cbServiceTag)),
                                    new SqlParameter("@YesAPStylebook", CC.CheckBoxValue(cbYesAPStylebook)),
                                    new SqlParameter("@ConfirmAPStylebook", CC.CheckBoxValue(cbConfirmAPStylebook)),
                                    new SqlParameter("@ITCheklistComp", CC.CheckBoxValue(cbITCheklistComp)),
                                    new SqlParameter("@ITOpearationSession", CC.CheckBoxValue(cbITOpearationSession)),
                                    new SqlParameter("@PCShipped", PCShippingDate),
                                    new SqlParameter("@OfficeLocation", _OfficeLocation),
                                    new SqlParameter("@LaptopType", _LaptopType),
                                    
                                    new SqlParameter("@FixMode", 1),
                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditITDetails", sqlparam);
            LblMsg.Text = "Record was updated successfully";
            MsgDiv.Visible = true;
            AlertMails();
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("informationtechnology.aspx", "btnSave_Click", ex.Message);
            LblMsg.Text = "Oops! Server problem....try after some time";
            MsgDiv.Visible = true;
        }
        finally { con.Close(); }
    }

    private void AlertMails()
    {
        string AbsoluteUri = string.Empty;
        string CurrentFilePath = string.Empty;
        string QueryString = string.Empty;
        string EmployeeName = string.Empty;
        //oMailSender
        DataTable odt = new DataTable();
        DataTable odt1 = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            AbsoluteUri = Request.Url.AbsoluteUri.ToString();
            CurrentFilePath = Request.AppRelativeCurrentExecutionFilePath.ToString();
            CurrentFilePath = CurrentFilePath.Remove(0, 2);
            QueryString = Request.QueryString.ToString();
            AbsoluteUri = AbsoluteUri.Replace(CurrentFilePath + "?" + QueryString, "");
            AbsoluteUri = AbsoluteUri + "loginpage.aspx?";

            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt1 = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetEmployeeDetails", sqlparam).Tables[0];
            if (odt1.Rows.Count > 0)
            {
                if (odt1.Rows[0]["Country"].ToString().ToLower() == "india")
                { return; }
                EmployeeName = odt1.Rows[0]["FirstName"].ToString() + " " + odt1.Rows[0]["LastName"].ToString();
            }
            else
            { return; }

            string query = string.Empty;
            query = "Select * from Users where Role = 'hr'";
            odt = SqlHelper.ExecuteDataset(con, CommandType.Text, query).Tables[0];

            if (odt.Rows.Count > 0)
            {
                for (int i = 0; i < odt.Rows.Count; i++)
                {
                    oMailSender.SendMailToHR(odt.Rows[i]["UserName"].ToString(), odt.Rows[i]["Role"].ToString(), AbsoluteUri, odt.Rows[i]["FirstName"].ToString() + " " + odt.Rows[i]["LastName"].ToString(), EmployeeName, "IT");
                }
            }
            //CC.SendMailToHrIfAllSectionComplete(m_EmployeeID, EmployeeName);
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("informationtechnology.aspx", "AlertMails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Reset();
    }
}
