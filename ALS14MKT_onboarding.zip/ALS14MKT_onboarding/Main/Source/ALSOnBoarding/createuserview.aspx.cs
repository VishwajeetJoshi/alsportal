﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;

public partial class createuserview : System.Web.UI.Page
{
    CommonClass CC = new CommonClass();
    private string m_Mode = string.Empty;
    private bool FixMode = false;
    PagedDataSource pgsource = new PagedDataSource();
    int findex, lindex;
    DataRow dr;
    private string m_UserName = string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        if (Session["UserRole"] != null)
        {
            if (Session["UserRole"].ToString().ToLower().Contains("system admin") || Session["UserRole"].ToString().ToLower().Contains("hr"))
            { }
            else { Response.Redirect("~/loginpage.aspx?Mode=3"); }
        }
        SetQueryStringValue();
        lblNoData.Visible = false;
        if (!IsPostBack)
        {
            FillGridView();
            if (m_UserName != string.Empty)
            {
                SetPageIndex();
            }
        }
    }

    private void SetQueryStringValue()
    {
        try
        {
            if (Request.QueryString["username"] != null)
            {
                m_UserName = Request.QueryString["username"];
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("createuserview.aspx", "SetQueryStringValue", ex.Message);
            m_UserName = string.Empty;
        }
    }

    private void SetPageIndex()
    {
        if (m_UserName != string.Empty)
        {
            int rowcount, columncount;
            rowcount = ((System.Data.DataView)pgsource.DataSource).Table.Rows.Count;
            columncount = ((System.Data.DataView)pgsource.DataSource).Table.Columns.Count;
            for (int i = 0; i <= rowcount - 1; i++)
            {
                if (((System.Data.DataView)pgsource.DataSource).Table.Rows[i][0].ToString() == m_UserName)
                {
                    int pagesize = 10;
                    if (i <= 10)
                        i = i + 1;
                    int a;
                    if (i <= pagesize)
                        a = 0;
                    else
                        a = i / pagesize;
                    CurrentPage = a;
                    FillGridView();
                    return;
                }
            }
        }

    }

    private void FillGridView()
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            string strQuery = string.Empty;
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetUserDetails").Tables[0];
            if (odt.Rows.Count > 0)
            {
                //gvUserListing.DataSource = odt;
                //gvUserListing.DataBind();

                pgsource.DataSource = odt.DefaultView;
                pgsource.AllowPaging = true;
                pgsource.PageSize = 10;

                //Store it Total pages value in View state
                ViewState["totpage"] = pgsource.PageCount;

                if (CurrentPage > Convert.ToInt32(ViewState["totpage"]) - 1)
                {
                    CurrentPage = Convert.ToInt32(ViewState["totpage"]) - 1;
                }

                pgsource.CurrentPageIndex = CurrentPage;

                //Enabled true Link button previous when current page is not equal first page 
                //Enabled false Link button previous when current page is first page
                lbPrev.Enabled = !pgsource.IsFirstPage;

                //Enabled true Link button Next when current page is not equal last page 
                //Enabled false Link button Next when current page is last page
                lbNext.Enabled = !pgsource.IsLastPage;

                //Bind resulted PageSource into the DataList
                gvUserListing.DataSource = pgsource;
                gvUserListing.DataBind();

                doPaging();
            }
            else
            {
                DataTable tempdt = new DataTable();
                tempdt.Columns.Add("UserName");
                tempdt.Columns.Add("FirstName");
                tempdt.Columns.Add("LastName");
                tempdt.Columns.Add("Role");
                tempdt.Rows.Add("");
                gvUserListing.DataSource = tempdt;
                gvUserListing.DataBind();
                gvUserListing.Rows[0].Visible = false;
                lblNoData.Visible = true;
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("createuserview.aspx", "FillGridView", ex.Message);
            //LblMsg.Text = "Wrong User Name or Password";
            //MsgDiv.Visible = true;
        }
        finally
        {
            con.Close();
        }
    }

    private void doPaging()
    {
        DataTable dt = new DataTable();
        dt.Columns.Add("Index");

        findex = 1;
        lindex = Convert.ToInt32(ViewState["totpage"]);

        if (lindex > (CurrentPage + 1))
        {
            if (CurrentPage >= 4)
            {
                lindex = CurrentPage + 2;
            }
        }
        int i;
        if (CurrentPage >= 4)
        { i = lindex - 4; }
        else
        {
            i = 1;
        }
        while (i <= lindex)
        {
            DataRow dr = dt.NewRow();
            dr[0] = i;
            dt.Rows.Add(dr);
            i++;
        }

        if (dt.Rows.Count > 0)
        {
            rptPaging.DataSource = dt;
            rptPaging.DataBind();
        }

    }
    private int CurrentPage
    {
        get
        {   //Check view state is null if null then return current index value as "0" else return specific page viewstate value
            if (ViewState["CurrentPage"] == null)
            {
                return 0;
            }
            else
            {
                return ((int)ViewState["CurrentPage"]);
            }
        }
        set
        {
            ViewState["CurrentPage"] = value;
        }
    }

    protected override void Render(HtmlTextWriter writer)
    {
        //if (Convert.ToInt32(ViewState["totpage"]) <= 1)
        //{
        //    divPaging.Visible = false;
        //}
        base.Render(writer);
    }
    protected void gvUserListing_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.ToLower() == "editdetails")
        {
            string username = e.CommandArgument.ToString();
            Response.Redirect("createuser.aspx?mode=edit&username=" + username);
        }
        if (e.CommandName.ToLower() == "resetpassword")
        {
            string username = e.CommandArgument.ToString();
            Response.Redirect("createuser.aspx?mode=editpwd&username=" + username);
        }
    }
    protected void rptPaging_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        LinkButton lbIndex = (LinkButton)e.Item.FindControl("lbIndexing");
        CurrentPage = Convert.ToInt32(lbIndex.Text) - 1;
        FillGridView();
    }
    protected void rptPaging_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            LinkButton lbIndex = (LinkButton)e.Item.FindControl("lbIndexing");
            if (Convert.ToInt32(lbIndex.Text) == (CurrentPage + 1))
            {
                lbIndex.CssClass = "activepagination";
            }
        }
    }
    protected void lbPrev_Click(object sender, EventArgs e)
    {
        CurrentPage -= 1;
        FillGridView();
    }
    protected void lbNext_Click(object sender, EventArgs e)
    {
        CurrentPage += 1;
        FillGridView();
    }
    protected void gvUserListing_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            LinkButton id = (LinkButton)e.Row.FindControl("lbDelete");
            string cid = id.Text;
            id.Attributes.Add("onclick", "return alertuserfordelete();");
        }
    }
    protected void gvUserListing_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        Label id = (Label)gvUserListing.Rows[e.RowIndex].FindControl("lblUserName");
        string empID = id.Text;
        SqlConnection con = SqlHelper.GetConnection();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@UserName", empID);
            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_DeleteUser", sqlparam);
            FillGridView();
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("createuserview.aspx", "gvUserListing_RowDeleting", ex.Message);
        }
        finally { con.Close(); }
    }
}
