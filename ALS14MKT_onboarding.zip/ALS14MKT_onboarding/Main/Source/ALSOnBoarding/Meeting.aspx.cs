﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;
using System.Globalization;

public partial class Meeting : System.Web.UI.Page
{
    CommonClass CC = new CommonClass();
    private string m_Mode = string.Empty;
    private int m_EmployeeID;
    private bool FixMode = false;
    MailSender oMailSender = new MailSender();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        SetQueryStringValue();

        if (!IsPostBack)
        {
            FillMeetingDetails();
        }
        MsgDiv.Visible = false;
    }

    private void SetQueryStringValue()
    {
        try
        {
            if (Request.QueryString["EmployeeID"] != null)
            {
                m_EmployeeID = Convert.ToInt32(Request.QueryString["EmployeeID"]);
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("Meeting.aspx", "SetQueryStringValue", ex.Message);
            m_Mode = "Add";
            m_EmployeeID = 0;
        }
    }

    private void SetUserRole()
    {
        if (Session["UserRole"] != null)
        {
            if (m_EmployeeID > 0)
            { divSave.Visible = true; }
            else
            { divSave.Visible = false; }
        }
    }

    protected override void Render(HtmlTextWriter writer)
    {
        SetUserRole();
        base.Render(writer);
    }

    private void FillMeetingDetails()
    {
        PopulateDetails();
        if (FixMode == true)
        {
            EnableDisable(true);
            divSave.Visible = false;
        }
    }

    private void PopulateDetails()
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetMeetingDetails", sqlparam).Tables[0];
            if (odt.Rows.Count > 0)
            {
                cbYesConsultingESP.Checked = CC.IfNullThenZero(odt.Rows[0]["YesConsulting_ESP"].ToString());
                cbConfirmConsultingESP.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmConsulting_ESP"].ToString());

                cbYesConsultingPP.Checked = CC.IfNullThenZero(odt.Rows[0]["YesConsulting_PP"].ToString());
                cbConfirmConsultingPP.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmConsulting_PP"].ToString());

                cbYesConsultingOP.Checked = CC.IfNullThenZero(odt.Rows[0]["YesConsulting_OP"].ToString());
                cbConfirmConsultingOP.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmConsulting_OP"].ToString());

                //cbYesVendorESP.Checked = CC.IfNullThenZero(odt.Rows[0]["YesVendor_ESP"].ToString());
                //cbConfirmVendorESP.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmVendor_ESP"].ToString());

                //cbYesVendorPP.Checked = CC.IfNullThenZero(odt.Rows[0]["YesVendor_PP"].ToString());
                //cbConfirmVendorPP.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmVendor_PP"].ToString());

                //cbYesNSG_OP.Checked = CC.IfNullThenZero(odt.Rows[0]["YesNSG_OP"].ToString());
                //cbConfirmNSG_OP.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmNSG_OP"].ToString());

                cbYesHSG_OP.Checked = CC.IfNullThenZero(odt.Rows[0]["YesHSG_OP"].ToString());
                cbConfirmHSG_OP.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmHSG_OP"].ToString());

                //cbYesUS_UK_P.Checked = CC.IfNullThenZero(odt.Rows[0]["YesUS_UK_P"].ToString());
                //cbConfirmUS_UK_P.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmUS_UK_P"].ToString());

                //////////////////////////////////////////////////////////////////////////////////////

                cbYesWIPReview.Checked = CC.IfNullThenZero(odt.Rows[0]["YesWIPReview"].ToString());
                cbConfirmWIPReview.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmWIPReview"].ToString());

                cbYesDealReview.Checked = CC.IfNullThenZero(odt.Rows[0]["YesDealReview"].ToString());
                cbConfirmDealReview.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmDealReview"].ToString());

                cbYesMonthlyProbCall.Checked = CC.IfNullThenZero(odt.Rows[0]["YesMnthProbCall"].ToString());
                cbConfirmMonthlyProbCall.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmMnthProbCall"].ToString());

                cbYesWklEuropeUdt.Checked = CC.IfNullThenZero(odt.Rows[0]["YesWklEuropeUdt"].ToString());
                cbConfirmWklEuropeUdt.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmWklEuropeUdt"].ToString());

                cbYesWklVendorCall.Checked = CC.IfNullThenZero(odt.Rows[0]["YesWklVendorCall"].ToString());
                cbConfirmWklVendorCall.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmWklVendorCall"].ToString());

                cbYesWklHWSWCall.Checked = CC.IfNullThenZero(odt.Rows[0]["YesWklHWSWCall"].ToString());
                cbConfirmWklHWSWCall.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmWklHWSWCall"].ToString());

                cbYesSDTeamMtg.Checked = CC.IfNullThenZero(odt.Rows[0]["YesSDTeamMtg"].ToString());
                cbConfirmSDTeamMtg.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmSDTeamMtg"].ToString());

                cbYesSSTeamMtg.Checked = CC.IfNullThenZero(odt.Rows[0]["YesSSTeamMtg"].ToString());
                cbConfirmSSTeamMtg.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmSSTeamMtg"].ToString());
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("Meeting.aspx", "PopulateDetails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    private string IfNullThenBlank(string value)
    {
        if (value == null)
        {
            return "";
        }
        else if (value == "")
        {
            return "";
        }
        else
        {
            return Server.HtmlDecode(value);
        }
    }

    private void Reset()
    {
        cbYesConsultingESP.Checked = false;
        cbConfirmConsultingESP.Checked = false;
        cbYesConsultingPP.Checked = false;
        cbConfirmConsultingPP.Checked = false;
        cbYesConsultingOP.Checked = false;
        cbConfirmConsultingOP.Checked = false;
        //cbYesVendorESP.Checked = false;
        //cbConfirmVendorESP.Checked = false;
        //cbYesVendorPP.Checked = false;
        //cbConfirmVendorPP.Checked = false;
        //cbYesNSG_OP.Checked = false;
        //cbConfirmNSG_OP.Checked = false;
        cbYesHSG_OP.Checked = false;
        cbConfirmHSG_OP.Checked = false;
        //cbYesUS_UK_P.Checked = false;
        //cbConfirmUS_UK_P.Checked = false;

        ///////////////////////////////////////

        cbYesWIPReview.Checked = false;
        cbConfirmWIPReview.Checked = false;
        cbYesDealReview.Checked = false;
        cbConfirmDealReview.Checked = false;
        cbYesMonthlyProbCall.Checked = false;
        cbConfirmMonthlyProbCall.Checked = false;
        cbYesWklEuropeUdt.Checked = false;
        cbConfirmWklEuropeUdt.Checked = false;
        cbYesWklVendorCall.Checked = false;
        cbConfirmWklVendorCall.Checked = false;
        cbYesWklHWSWCall.Checked = false;
        cbConfirmWklHWSWCall.Checked = false;
        cbYesSDTeamMtg.Checked = false;
        cbConfirmSDTeamMtg.Checked = false;
        cbYesSSTeamMtg.Checked = false;
        cbConfirmSSTeamMtg.Checked = false;
    }

    private void EnableDisable(bool boolValue)
    {
        //ddlParkingEntry.SelectedIndex = 0;
        //ddlEntryKey.SelectedIndex = 0;
        //ddlSecurityCode.SelectedIndex = 0;
        //ddlSecurityInfo.SelectedIndex = 0;
        //ddlAllHandsInvite.SelectedIndex = 0;
        //ddlMDDInvite.SelectedIndex = 0;
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@EmployeeID", m_EmployeeID),                                  
                                    new SqlParameter("@YesConsulting_ESP", CC.CheckBoxValue(cbYesConsultingESP)),
                                    new SqlParameter("@ConfirmConsulting_ESP", CC.CheckBoxValue(cbConfirmConsultingESP)),
                                    new SqlParameter("@YesConsulting_PP", CC.CheckBoxValue(cbYesConsultingPP)),
                                    new SqlParameter("@ConfirmConsulting_PP", CC.CheckBoxValue(cbConfirmConsultingPP)),
                                    new SqlParameter("@YesConsulting_OP", CC.CheckBoxValue(cbYesConsultingOP)),
                                    new SqlParameter("@ConfirmConsulting_OP", CC.CheckBoxValue(cbConfirmConsultingOP)),
                                    //new SqlParameter("@YesVendor_ESP", CC.CheckBoxValue(cbYesVendorESP)),
                                    //new SqlParameter("@ConfirmVendor_ESP", CC.CheckBoxValue(cbConfirmVendorESP)),
                                    //new SqlParameter("@YesVendor_PP", CC.CheckBoxValue(cbYesVendorPP)),
                                    //new SqlParameter("@ConfirmVendor_PP", CC.CheckBoxValue(cbConfirmVendorPP)),
                                    //new SqlParameter("@YesNSG_OP", CC.CheckBoxValue(cbYesNSG_OP)),
                                    //new SqlParameter("@ConfirmNSG_OP", CC.CheckBoxValue(cbConfirmNSG_OP)),
                                    new SqlParameter("@YesHSG_OP", CC.CheckBoxValue(cbYesHSG_OP)),
                                    new SqlParameter("@ConfirmHSG_OP", CC.CheckBoxValue(cbConfirmHSG_OP)),
                                    //new SqlParameter("@YesUS_UK_P", CC.CheckBoxValue(cbYesUS_UK_P)),
                                    //new SqlParameter("@ConfirmUS_UK_P", CC.CheckBoxValue(cbConfirmUS_UK_P)), 
                                   
                                    //////////////////////////////////////////////////////////////////////////////////
                                    new SqlParameter("@YesWIPReview", CC.CheckBoxValue(cbYesWIPReview)),
                                    new SqlParameter("@ConfirmWIPReview", CC.CheckBoxValue(cbConfirmWIPReview)),
                                    new SqlParameter("@YesDealReview", CC.CheckBoxValue(cbYesDealReview)),
                                    new SqlParameter("@ConfirmDealReview", CC.CheckBoxValue(cbConfirmDealReview)),
                                    new SqlParameter("@YesMnthProbCall", CC.CheckBoxValue(cbYesMonthlyProbCall)),
                                    new SqlParameter("@ConfirmMnthProbCall", CC.CheckBoxValue(cbConfirmMonthlyProbCall)),
                                    new SqlParameter("@YesWklEuropeUdt", CC.CheckBoxValue(cbYesWklEuropeUdt)),
                                    new SqlParameter("@ConfirmWklEuropeUdt", CC.CheckBoxValue(cbConfirmWklEuropeUdt)),
                                    new SqlParameter("@YesWklVendorCall", CC.CheckBoxValue(cbYesWklVendorCall)),
                                    new SqlParameter("@ConfirmWklVendorCall", CC.CheckBoxValue(cbConfirmWklVendorCall)),
                                    new SqlParameter("@YesWklHWSWCall", CC.CheckBoxValue(cbYesWklHWSWCall)),
                                    new SqlParameter("@ConfirmWklHWSWCall", CC.CheckBoxValue(cbConfirmWklHWSWCall)),
                                    new SqlParameter("@YesSDTeamMtg", CC.CheckBoxValue(cbYesSDTeamMtg)),
                                    new SqlParameter("@ConfirmSDTeamMtg", CC.CheckBoxValue(cbConfirmSDTeamMtg)),
                                    new SqlParameter("@YesSSTeamMtg", CC.CheckBoxValue(cbYesSSTeamMtg)),
                                    new SqlParameter("@ConfirmSSTeamMtg", CC.CheckBoxValue(cbConfirmSSTeamMtg)), 

                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditMeetingDetails", sqlparam);
            LblMsg.Text = "Record was updated successfully";
            MsgDiv.Visible = true;
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("Meeting.aspx", "btnSave_Click", ex.Message);
            LblMsg.Text = "Oops! Server problem....try after some time";
            MsgDiv.Visible = true;
        }
        finally { con.Close(); }
    }

    protected void btnSaveSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@EmployeeID", m_EmployeeID),                                   
                                    new SqlParameter("@YesConsulting_ESP", CC.CheckBoxValue(cbYesConsultingESP)),
                                    new SqlParameter("@ConfirmConsulting_ESP", CC.CheckBoxValue(cbConfirmConsultingESP)),
                                    new SqlParameter("@YesConsulting_PP", CC.CheckBoxValue(cbYesConsultingPP)),
                                    new SqlParameter("@ConfirmConsulting_PP", CC.CheckBoxValue(cbConfirmConsultingPP)),
                                    new SqlParameter("@YesConsulting_OP", CC.CheckBoxValue(cbYesConsultingOP)),
                                    new SqlParameter("@ConfirmConsulting_OP", CC.CheckBoxValue(cbConfirmConsultingOP)),
                                    //new SqlParameter("@YesVendor_ESP", CC.CheckBoxValue(cbYesVendorESP)),
                                    //new SqlParameter("@ConfirmVendor_ESP", CC.CheckBoxValue(cbConfirmVendorESP)),
                                    //new SqlParameter("@YesVendor_PP", CC.CheckBoxValue(cbYesVendorPP)),
                                    //new SqlParameter("@ConfirmVendor_PP", CC.CheckBoxValue(cbConfirmVendorPP)),
                                    //new SqlParameter("@YesNSG_OP", CC.CheckBoxValue(cbYesNSG_OP)),
                                    //new SqlParameter("@ConfirmNSG_OP", CC.CheckBoxValue(cbConfirmNSG_OP)),
                                    new SqlParameter("@YesHSG_OP", CC.CheckBoxValue(cbYesHSG_OP)),
                                    new SqlParameter("@ConfirmHSG_OP", CC.CheckBoxValue(cbConfirmHSG_OP)),
                                    //new SqlParameter("@YesUS_UK_P", CC.CheckBoxValue(cbYesUS_UK_P)),
                                    //new SqlParameter("@ConfirmUS_UK_P", CC.CheckBoxValue(cbConfirmUS_UK_P)),

                                    //////////////////////////////////////////////////////////////////////////////////
                                    new SqlParameter("@YesWIPReview", CC.CheckBoxValue(cbYesWIPReview)),
                                    new SqlParameter("@ConfirmWIPReview", CC.CheckBoxValue(cbConfirmWIPReview)),
                                    new SqlParameter("@YesDealReview", CC.CheckBoxValue(cbYesDealReview)),
                                    new SqlParameter("@ConfirmDealReview", CC.CheckBoxValue(cbConfirmDealReview)),
                                    new SqlParameter("@YesMnthProbCall", CC.CheckBoxValue(cbYesMonthlyProbCall)),
                                    new SqlParameter("@ConfirmMnthProbCall", CC.CheckBoxValue(cbConfirmMonthlyProbCall)),
                                    new SqlParameter("@YesWklEuropeUdt", CC.CheckBoxValue(cbYesWklEuropeUdt)),
                                    new SqlParameter("@ConfirmWklEuropeUdt", CC.CheckBoxValue(cbConfirmWklEuropeUdt)),
                                    new SqlParameter("@YesWklVendorCall", CC.CheckBoxValue(cbYesWklVendorCall)),
                                    new SqlParameter("@ConfirmWklVendorCall", CC.CheckBoxValue(cbConfirmWklVendorCall)),
                                    new SqlParameter("@YesWklHWSWCall", CC.CheckBoxValue(cbYesWklHWSWCall)),
                                    new SqlParameter("@ConfirmWklHWSWCall", CC.CheckBoxValue(cbConfirmWklHWSWCall)),
                                    new SqlParameter("@YesSDTeamMtg", CC.CheckBoxValue(cbYesSDTeamMtg)),
                                    new SqlParameter("@ConfirmSDTeamMtg", CC.CheckBoxValue(cbConfirmSDTeamMtg)),
                                    new SqlParameter("@YesSSTeamMtg", CC.CheckBoxValue(cbYesSSTeamMtg)),
                                    new SqlParameter("@ConfirmSSTeamMtg", CC.CheckBoxValue(cbConfirmSSTeamMtg)), 

                                    new SqlParameter("@FixMode", 1),
                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditMeetingDetails", sqlparam);
            LblMsg.Text = "Record was updated successfully";
            MsgDiv.Visible = true;
            AlertMails();
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("Meeting.aspx", "btnSave_Click", ex.Message);
            LblMsg.Text = "Oops! Server problem....try after some time";
            MsgDiv.Visible = true;
        }
        finally { con.Close(); }
    }

    private void AlertMails()
    {
        string AbsoluteUri = string.Empty;
        string CurrentFilePath = string.Empty;
        string QueryString = string.Empty;
        string EmployeeName = string.Empty;
        //oMailSender
        DataTable odt = new DataTable();
        DataTable odt1 = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            AbsoluteUri = Request.Url.AbsoluteUri.ToString();
            CurrentFilePath = Request.AppRelativeCurrentExecutionFilePath.ToString();
            CurrentFilePath = CurrentFilePath.Remove(0, 2);
            QueryString = Request.QueryString.ToString();
            AbsoluteUri = AbsoluteUri.Replace(CurrentFilePath + "?" + QueryString, "");
            AbsoluteUri = AbsoluteUri + "loginpage.aspx?";

            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt1 = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetEmployeeDetails", sqlparam).Tables[0];
            if (odt1.Rows.Count > 0)
            {
                if (odt1.Rows[0]["Country"].ToString().ToLower() == "india")
                { return; }
                EmployeeName = odt1.Rows[0]["FirstName"].ToString() + " " + odt1.Rows[0]["LastName"].ToString();
            }
            else
            { return; }

            string query = string.Empty;
            query = "Select * from Users where Role = 'hr'";
            odt = SqlHelper.ExecuteDataset(con, CommandType.Text, query).Tables[0];

            if (odt.Rows.Count > 0)
            {
                for (int i = 0; i < odt.Rows.Count; i++)
                {
                    oMailSender.SendMailToHR(odt.Rows[i]["UserName"].ToString(), odt.Rows[i]["Role"].ToString(), AbsoluteUri, odt.Rows[i]["FirstName"].ToString() + " " + odt.Rows[i]["LastName"].ToString(), EmployeeName, "Meeting");
                }
            }
            //CC.SendMailToHrIfAllSectionComplete(m_EmployeeID, EmployeeName);
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("Meeting.aspx", "AlertMails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Reset();
    }
}
