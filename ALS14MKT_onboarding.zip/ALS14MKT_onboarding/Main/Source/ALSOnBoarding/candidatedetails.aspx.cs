﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;
using System.Security.Cryptography;
using System.IO;
using System.Text;

public partial class candidatedetails : System.Web.UI.Page
{
    CommonClass CC = new CommonClass();
    private string m_Mode = string.Empty;
    private int m_EmployeeID;
    private bool FixMode = false;
    private string emailCode = string.Empty;
    
    protected void Page_Load(object sender, EventArgs e)
    {      
        SetQueryStringValue();

        if (!IsPostBack)
        {
            if (ValidateLink() == false)
            {
                Response.Redirect("message.aspx");
            }
            Session["update"] = Server.UrlEncode(System.DateTime.Now.ToString());
            FillDropDownList();
            PopulateDetails();
        }
        MsgDiv.Visible = false;
    }

    private void SetQueryStringValue()
    {
        try
        {
            //if (Request.QueryString["eid"] != null)
            //{
            //    m_EmployeeID = Convert.ToInt32(Decrypt(Request.QueryString["eid"].ToString()));
            //}
            if (Request.QueryString["code"] != null)
            {
                emailCode = Request.QueryString["code"].ToString();
            }
        }
        catch (Exception ex)
        {
            Session["message"] = "Invalid accss.";
            Response.Redirect("message.aspx");
        }
    }

    private bool ValidateLink()
    {
        SqlConnection sqlcon = SqlHelper.GetConnection();
        sqlcon.Open();
        try
        {
            //SP_GetEmailCodeDetails
            SqlParameter sqlparam = new SqlParameter("@code", emailCode);
            DataTable odt = new DataTable();
            odt = SqlHelper.ExecuteDataset(sqlcon, "SP_GetEmailCodeDetails", sqlparam).Tables[0];
            if (odt.Rows.Count > 0)
            {                
                    if (DateTime.Now <= Convert.ToDateTime(odt.Rows[0]["CreatedDate"]).AddDays(7))
                    {
                        m_EmployeeID = Convert.ToInt32(odt.Rows[0]["EmployeeID"]);
                        Session["EmployeeID"] = m_EmployeeID;
                        return true;
                    }
                    else
                    {
                        Session["message"] = "Link has been expired.";
                        return false;
                    }             
            }
            else
            {
                Session["message"] = "Invalid accss.";
                return false;
            }
        }
        catch (Exception ex)
        {
            Session["message"] = "Invalid accss.";
            return false;
        }
        return true;
    }

    private const string ENCRYPTION_KEY = "EncDec";
    private readonly static byte[] SALT = Encoding.ASCII.GetBytes(ENCRYPTION_KEY.Length.ToString());

    private static string Decrypt(string inputText)
    {
        RijndaelManaged rijndaelCipher = new RijndaelManaged();
        byte[] encryptedData = Convert.FromBase64String(inputText);
        PasswordDeriveBytes secretKey = new PasswordDeriveBytes(ENCRYPTION_KEY, SALT);
        using (ICryptoTransform decryptor = rijndaelCipher.CreateDecryptor(secretKey.GetBytes(32), secretKey.GetBytes(16)))
        {
            using (MemoryStream memoryStream = new MemoryStream(encryptedData))
            {
                using (CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
                {
                    byte[] plainText = new byte[encryptedData.Length];
                    int decryptedCount = cryptoStream.Read(plainText, 0, plainText.Length);
                    return Encoding.Unicode.GetString(plainText, 0, decryptedCount);
                }
            }
        }
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        ViewState["update"] = Session["update"];
    }

    private void FillDropDownList()
    {
        //-------Fill Country
        ddlCountry.DataSource = CC.AllCountry();
        ddlCountry.DataTextField = "CountryName";
        ddlCountry.DataValueField = "CountryName";
        ddlCountry.DataBind();
        ddlCountry.Items.Insert(0, new ListItem("-- Select One --", "0"));

        //-------Fill RefCountry
        ddlRefCountry.DataSource = CC.AllCountry();
        ddlRefCountry.DataTextField = "CountryName";
        ddlRefCountry.DataValueField = "CountryName";
        ddlRefCountry.DataBind();
        ddlRefCountry.Items.Insert(0, new ListItem("-- Select One --", "0"));

        //-------Fill State
        ddlState.DataSource = CC.USState();
        ddlState.DataTextField = "StateName";
        ddlState.DataValueField = "StateID";
        ddlState.DataBind();
        ddlState.Items.Insert(0, new ListItem("-- Select One --", "0"));

        //-------Fill RefState
        ddlRefState.DataSource = CC.USState();
        ddlRefState.DataTextField = "StateName";
        ddlRefState.DataValueField = "StateID";
        ddlRefState.DataBind();
        ddlRefState.Items.Insert(0, new ListItem("-- Select One --", "0"));
    }

    private void Reset()
    {
        //txtLastName.Text = "";
        //txtFirstName.Text = "";
        txtMiddleInitial.Text = "";
        txtStreet.Text = "";
        txtAptUnit.Text = "";
        txtCity.Text = "";
        ddlCountry.SelectedIndex = 0;
        ddlState.SelectedIndex = 0;
        divState.Visible = false;
        txtZip.Text = "";
        txtHomePhone.Text = "";
        txtCellPhone.Text = "";
        txtBusinessCard.Text = "";
        txtCoEmailId.Text = "";
        //txtPerEmailId.Text = "";
        txtRefLastName.Text = "";
        txtRefFirstName.Text = "";
        txtRefMiddleInitial.Text = "";
        txtRefStreet.Text = "";
        txtRefAptUnit.Text = "";
        txtRefCity.Text = "";
        ddlRefCountry.SelectedIndex = 0;
        ddlRefState.SelectedIndex = 0;
        divRefState.Visible = false;
        txtRefZip.Text = "";
        txtRefPriPhone.Text = "";
        txtRefAltPhone.Text = "";
        txtRelationship.Text = "";
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["update"].ToString() == ViewState["update"].ToString())
        {
            string state = string.Empty;
            string refState = string.Empty;
            string country = string.Empty;
            string refcountry = string.Empty;

            if (ddlCountry.SelectedIndex != 0)
            {
                country = ddlCountry.SelectedItem.ToString();
                if (ddlCountry.SelectedItem.ToString().ToUpper() == "USA")
                {
                    if (ddlState.SelectedIndex != 0)
                    {
                        state = ddlState.SelectedItem.ToString();
                    }
                }
                else
                {
                    if (txtOtherState.Text != "")
                    {
                        state = txtOtherState.Text;
                    }
                }
            }
            else
            {
                if (ddlState.SelectedIndex != 0)
                {
                    state = ddlState.SelectedItem.ToString();
                }
            }

            if (ddlRefCountry.SelectedIndex != 0)
            {
                refcountry = ddlRefCountry.SelectedItem.ToString();
                if (ddlRefCountry.SelectedItem.ToString().ToUpper() == "USA")
                {
                    if (ddlRefState.SelectedIndex != 0)
                    {
                        refState = ddlRefState.SelectedItem.ToString();
                    }
                }
                else
                {
                    if (txtRefOtherState.Text != "")
                    {
                        refState = txtRefOtherState.Text;
                    }
                }
            }
            else
            {
                if (ddlRefState.SelectedIndex != 0)
                {
                    refState = ddlRefState.SelectedItem.ToString();
                }
            }

            if (Session["EmployeeID"] != null)
            {
                m_EmployeeID = Convert.ToInt32(Session["EmployeeID"]);
            }

            SqlConnection con = SqlHelper.GetConnection();
            con.Open();
            try
            {
                SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@EmployeeID", m_EmployeeID),
                                    new SqlParameter("@FirstName", Server.HtmlEncode(txtFirstName.Text)),
                                    new SqlParameter("@LastName", Server.HtmlEncode(txtLastName.Text)),
                                    new SqlParameter("@MiddleInitial", Server.HtmlEncode(txtMiddleInitial.Text)),
                                    new SqlParameter("@Street", Server.HtmlEncode(txtStreet.Text)),
                                    new SqlParameter("@AptUnit", Server.HtmlEncode(txtAptUnit.Text)),
                                    new SqlParameter("@City", Server.HtmlEncode(txtCity.Text)),    
                                    new SqlParameter("@Country", country),
                                    new SqlParameter("@State", state),
                                    new SqlParameter("@PostalCode", Server.HtmlEncode(txtZip.Text)),
                                    new SqlParameter("@HomePhone", Server.HtmlEncode(txtHomePhone.Text)),
                                    new SqlParameter("@CellPhone", Server.HtmlEncode(txtCellPhone.Text)),
                                    new SqlParameter("@BusinessCardName", Server.HtmlEncode(txtBusinessCard.Text)),
                                    new SqlParameter("@PerEmailID", Server.HtmlEncode(txtPerEmailId.Text)),
                                    new SqlParameter("@CompanyEmailID", Server.HtmlEncode(txtCoEmailId.Text)),
                                    new SqlParameter("@ConFirstName", Server.HtmlEncode(txtRefFirstName.Text)),
                                    new SqlParameter("@ConLastName", Server.HtmlEncode(txtRefLastName.Text)),
                                    new SqlParameter("@ConMiddleInitial", Server.HtmlEncode(txtRefMiddleInitial.Text)),
                                    new SqlParameter("@ConStreet", Server.HtmlEncode(txtRefStreet.Text)),
                                    new SqlParameter("@ConAptUnit", Server.HtmlEncode(txtRefAptUnit.Text)),
                                    new SqlParameter("@ConCity", Server.HtmlEncode(txtRefCity.Text)),
                                    new SqlParameter("@ConCountry", refcountry),    
                                    new SqlParameter("@ConState", refState),
                                    new SqlParameter("@ConPostalCode", Server.HtmlEncode(txtRefZip.Text)),
                                    new SqlParameter("@ConPriPhone", Server.HtmlEncode(txtRefPriPhone.Text)),
                                    new SqlParameter("@ConAltPhone", Server.HtmlEncode(txtRefAltPhone.Text)),
                                    new SqlParameter("@Relationship", Server.HtmlEncode(txtRelationship.Text))};

                SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_UpdateCandidateDetails", sqlparam);
                LblMsg.Text = "Record was added successfully";
                MsgDiv.Visible = true;
                //Reset();
            }
            catch (Exception ex)
            {
                CommonClass.AddErrorTrail("employeedetail.aspx", "btnSave_Click", ex.Message);
                LblMsg.Text = "Oops! Server problem....try after some time";
                MsgDiv.Visible = true;
            }
            finally { con.Close(); }
            Session["update"] = Server.UrlEncode(System.DateTime.Now.ToString());
        }
        else
        {
            //Reset();
        }
    }

    private void PopulateDetails()
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetEmployeeDetails", sqlparam).Tables[0];
            if (odt.Rows.Count > 0)
            {
                txtLastName.Text = IfNullThenBlank(odt.Rows[0]["LastName"].ToString());
                txtFirstName.Text = IfNullThenBlank(odt.Rows[0]["FirstName"].ToString());
                txtMiddleInitial.Text = IfNullThenBlank(odt.Rows[0]["MiddleInitial"].ToString());
                txtStreet.Text = IfNullThenBlank(odt.Rows[0]["StreetAddress"].ToString());
                txtAptUnit.Text = IfNullThenBlank(odt.Rows[0]["AptUnit"].ToString());
                txtCity.Text = IfNullThenBlank(odt.Rows[0]["City"].ToString());

                ddlCountry.SelectedIndex = ddlCountry.Items.IndexOf(ddlCountry.Items.FindByText(odt.Rows[0]["Country"].ToString()));
                ddlState.SelectedIndex = ddlState.Items.IndexOf(ddlState.Items.FindByText(odt.Rows[0]["State"].ToString()));
                if (ddlState.SelectedIndex == 0 && odt.Rows[0]["State"].ToString() != "")
                {
                    ddlState.Items.Clear();
                    ddlState.Items.Insert(0, new ListItem("-- Select One --", "0"));
                    divState.Visible = true;
                    txtOtherState.Text = odt.Rows[0]["State"].ToString();
                }
                
                txtZip.Text = IfNullThenBlank(odt.Rows[0]["PostalCode"].ToString());
                txtHomePhone.Text = IfNullThenBlank(odt.Rows[0]["HomePhone"].ToString());
                txtCellPhone.Text = IfNullThenBlank(odt.Rows[0]["CellPhone"].ToString());
                txtBusinessCard.Text = IfNullThenBlank(odt.Rows[0]["BusinessCardName"].ToString());
                txtCoEmailId.Text = IfNullThenBlank(odt.Rows[0]["CompanyEmailID"].ToString());
                txtPerEmailId.Text = IfNullThenBlank(odt.Rows[0]["PerEmailID"].ToString());
                txtRefLastName.Text = IfNullThenBlank(odt.Rows[0]["ConFirstName"].ToString());
                txtRefFirstName.Text = IfNullThenBlank(odt.Rows[0]["ConLastName"].ToString());
                txtRefMiddleInitial.Text = IfNullThenBlank(odt.Rows[0]["ConMiddleInitials"].ToString());
                txtRefStreet.Text = IfNullThenBlank(odt.Rows[0]["ConStreetAddress"].ToString());
                txtRefAptUnit.Text = IfNullThenBlank(odt.Rows[0]["ConAptUnit"].ToString());
                txtRefCity.Text = IfNullThenBlank(odt.Rows[0]["ConCity"].ToString());

                ddlRefCountry.SelectedIndex = ddlRefCountry.Items.IndexOf(ddlRefCountry.Items.FindByText(odt.Rows[0]["ConCountry"].ToString()));
                ddlRefState.SelectedIndex = ddlRefState.Items.IndexOf(ddlRefState.Items.FindByText(odt.Rows[0]["ConState"].ToString()));
                if (ddlRefState.SelectedIndex == 0 && odt.Rows[0]["ConState"].ToString() != "")
                {
                    ddlRefState.Items.Clear();
                    ddlRefState.Items.Insert(0, new ListItem("-- Select One --", "0"));
                    divRefState.Visible = true;
                    txtRefOtherState.Text = odt.Rows[0]["ConState"].ToString();
                }
                
                txtRefZip.Text = IfNullThenBlank(odt.Rows[0]["ConZip"].ToString());
                txtRefPriPhone.Text = IfNullThenBlank(odt.Rows[0]["PrimaryPhone"].ToString());
                txtRefAltPhone.Text = IfNullThenBlank(odt.Rows[0]["AlternatePhone"].ToString());
                txtRelationship.Text = IfNullThenBlank(odt.Rows[0]["Relationship"].ToString());

                FixMode = (bool)odt.Rows[0]["FixMode"];
            }

        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("employeedetail.aspx", "PopulateDetails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    private string IfNullThenBlank(string value)
    {
        if (value == null)
        {
            return "";
        }
        else if (value == "")
        {
            return "";
        }
        else
        {
            return Server.HtmlDecode(value);
        }
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Reset();
    }

    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        string state = string.Empty;
        if (ddlCountry.SelectedIndex != 0)
        {
            if (ddlCountry.SelectedItem.ToString().ToUpper() == "USA")
            {
                if (ddlState.SelectedIndex != 0)
                {
                    state = ddlState.SelectedItem.ToString();
                }
                ddlState.DataSource = CC.USState();
                ddlState.DataTextField = "StateName";
                ddlState.DataValueField = "StateID";
                ddlState.DataBind();
                ddlState.Items.Insert(0, new ListItem("-- Select One --", "0"));
                if (state != string.Empty)
                {
                    ddlState.SelectedIndex = ddlState.Items.IndexOf(ddlState.Items.FindByText(state));
                }
                divState.Visible = false;
                txtOtherState.Text = "";
            }
            else
            {
                ddlState.Items.Clear();
                ddlState.Items.Insert(0, new ListItem("-- Select One --", "0"));
                divState.Visible = true;
            }
        }
        else
        {
            ddlState.SelectedIndex = 0;
            divState.Visible = false;
            txtOtherState.Text = "";
        }
    }

    protected void ddlRefCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        string state = string.Empty;
        if (ddlRefCountry.SelectedIndex != 0)
        {
            if (ddlRefCountry.SelectedItem.ToString().ToUpper() == "USA")
            {
                if (ddlRefState.SelectedIndex != 0)
                {
                    state = ddlRefState.SelectedItem.ToString();
                }
                ddlRefState.DataSource = CC.USState();
                ddlRefState.DataTextField = "StateName";
                ddlRefState.DataValueField = "StateID";
                ddlRefState.DataBind();
                ddlRefState.Items.Insert(0, new ListItem("-- Select One --", "0"));
                if (state != string.Empty)
                {
                    ddlRefState.SelectedIndex = ddlRefState.Items.IndexOf(ddlState.Items.FindByText(state));
                }
                divRefState.Visible = false;
                txtRefOtherState.Text = "";
            }
            else
            {
                ddlRefState.Items.Clear();
                ddlRefState.Items.Insert(0, new ListItem("-- Select One --", "0"));
                divRefState.Visible = true;
            }
        }
        else
        {
            ddlRefState.SelectedIndex = 0;
            divRefState.Visible = false;
            txtRefOtherState.Text = "";
        }
    }
}
