﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;
using System.Globalization;

public partial class performance : System.Web.UI.Page
{
    CommonClass CC = new CommonClass();
    private string m_Mode = string.Empty;
    private int m_EmployeeID;
    private bool FixMode = false;
    MailSender oMailSender = new MailSender();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        SetQueryStringValue();

        if (!IsPostBack)
        {
            FillSecurityDetails();
        }
        MsgDiv.Visible = false;
    }

    private void SetQueryStringValue()
    {
        try
        {
            if (Request.QueryString["EmployeeID"] != null)
            {
                m_EmployeeID = Convert.ToInt32(Request.QueryString["EmployeeID"]);
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("performance.aspx", "SetQueryStringValue", ex.Message);
            m_Mode = "Add";
            m_EmployeeID = 0;
        }
    }

    private void SetUserRole()
    {
        if (Session["UserRole"] != null)
        {
            if (m_EmployeeID > 0)
            { divSave.Visible = true; }
            else
            { divSave.Visible = false; }
        }
    }

    protected override void Render(HtmlTextWriter writer)
    {
        SetUserRole();
        base.Render(writer);
    }

    private void FillSecurityDetails()
    {
        PopulateDetails();
        if (FixMode == true)
        {
            EnableDisable(true);
            divSave.Visible = false;
        }
    }

    private void PopulateDetails()
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetPerformanceDetails", sqlparam).Tables[0];
            if (odt.Rows.Count > 0)
            {
                cbYesSkillsDBEntries.Checked = CC.IfNullThenZero(odt.Rows[0]["SkillsDBEntries"].ToString());
                cbYesCounselIntroEmail.Checked = CC.IfNullThenZero(odt.Rows[0]["CounselIntroEmail"].ToString());
                cbYesCuratorIntroEmail.Checked = CC.IfNullThenZero(odt.Rows[0]["CuratorIntroEmail"].ToString());
                cbYesCounselGroupChart.Checked = CC.IfNullThenZero(odt.Rows[0]["CounselGroupChart"].ToString());
                cbYesCuratorGroupChart.Checked = CC.IfNullThenZero(odt.Rows[0]["CuratorGroupChart"].ToString());
                //Add new field
                txtCounselDirect.Text = Server.HtmlEncode(IfNullThenBlank(odt.Rows[0]["CounselDirectRpt"].ToString()));
                txtPeerCoach.Text = Server.HtmlEncode(IfNullThenBlank(odt.Rows[0]["PeerCoach"].ToString()));
                txtCurator.Text = Server.HtmlEncode(IfNullThenBlank(odt.Rows[0]["Curator"].ToString()));
                cbPeerCoachEmail.Checked = CC.IfNullThenZero(odt.Rows[0]["PeerCoachEmail"].ToString());
                //Add new fields on 140814
                cbConfirmationForm.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmationForm"].ToString());
                cbAssessmentsOverview.Checked = CC.IfNullThenZero(odt.Rows[0]["AssessmentsOverview"].ToString());
                cbLearningDevTraining.Checked = CC.IfNullThenZero(odt.Rows[0]["LearningDevTraining"].ToString());
                cbPerformanceTraining.Checked = CC.IfNullThenZero(odt.Rows[0]["PerformanceTraining"].ToString());
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("performance.aspx", "PopulateDetails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    private string IfNullThenBlank(string value)
    {
        if (value == null)
        {
            return "";
        }
        else if (value == "")
        {
            return "";
        }
        else
        {
            return Server.HtmlDecode(value);
        }
    }

    private void Reset()
    {
        cbYesSkillsDBEntries.Checked = false;
        cbYesCounselIntroEmail.Checked = false;
        cbYesCuratorIntroEmail.Checked = false;
        cbYesCounselGroupChart.Checked = false;
        cbYesCuratorGroupChart.Checked = false;
        txtCounselDirect.Text = "";
        txtPeerCoach.Text = "";
        txtCurator.Text = "";
        cbPeerCoachEmail.Checked = false;
        cbConfirmationForm.Checked = false;
        cbAssessmentsOverview.Checked = false;
        cbLearningDevTraining.Checked = false;
        cbPerformanceTraining.Checked = false;
    }

    private void EnableDisable(bool boolValue)
    {

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@EmployeeID", m_EmployeeID),
                                    new SqlParameter("@SkillsDBEntries", CC.CheckBoxValue(cbYesSkillsDBEntries)),
                                    new SqlParameter("@CounselIntroEmail", CC.CheckBoxValue(cbYesCounselIntroEmail)),
                                    new SqlParameter("@CuratorIntroEmail", CC.CheckBoxValue(cbYesCuratorIntroEmail)),
                                    new SqlParameter("@CounselGroupChart", CC.CheckBoxValue(cbYesCounselGroupChart)),
                                    new SqlParameter("@CuratorGroupChart", CC.CheckBoxValue(cbYesCuratorGroupChart)),
                                    new SqlParameter("@CounselDirect", Server.HtmlEncode(txtCounselDirect.Text)),
                                    new SqlParameter("@PeerCoach", Server.HtmlEncode(txtPeerCoach.Text)),
                                    new SqlParameter("@Curator", Server.HtmlEncode(txtCurator.Text)),
                                    new SqlParameter("@PeerCoachEmail", CC.CheckBoxValue(cbPeerCoachEmail)),

                                    new SqlParameter("@ConfirmationForm", CC.CheckBoxValue(cbConfirmationForm)),
                                    new SqlParameter("@AssessmentsOverview", CC.CheckBoxValue(cbAssessmentsOverview)),
                                    new SqlParameter("@LearningDevTraining", CC.CheckBoxValue(cbLearningDevTraining)),
                                    new SqlParameter("@PerformanceTraining", CC.CheckBoxValue(cbPerformanceTraining)),

                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditPerformanceDetails", sqlparam);
            LblMsg.Text = "Record was updated successfully";
            MsgDiv.Visible = true;
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("performance.aspx", "btnSave_Click", ex.Message);
            LblMsg.Text = "Oops! Server problem....try after some time";
            MsgDiv.Visible = true;
        }
        finally { con.Close(); }
    }

    protected void btnSaveSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@EmployeeID", m_EmployeeID),
                                    new SqlParameter("@SkillsDBEntries", CC.CheckBoxValue(cbYesSkillsDBEntries)),
                                    new SqlParameter("@CounselIntroEmail", CC.CheckBoxValue(cbYesCounselIntroEmail)),
                                    new SqlParameter("@CuratorIntroEmail", CC.CheckBoxValue(cbYesCuratorIntroEmail)),
                                    new SqlParameter("@CounselGroupChart", CC.CheckBoxValue(cbYesCounselGroupChart)),
                                    new SqlParameter("@CuratorGroupChart", CC.CheckBoxValue(cbYesCuratorGroupChart)),
                                    new SqlParameter("@CounselDirect", Server.HtmlEncode(txtCounselDirect.Text)),
                                    new SqlParameter("@PeerCoach", Server.HtmlEncode(txtPeerCoach.Text)),
                                    new SqlParameter("@Curator", Server.HtmlEncode(txtCurator.Text)),
                                    new SqlParameter("@PeerCoachEmail", CC.CheckBoxValue(cbPeerCoachEmail)),

                                    new SqlParameter("@ConfirmationForm", CC.CheckBoxValue(cbConfirmationForm)),
                                    new SqlParameter("@AssessmentsOverview", CC.CheckBoxValue(cbAssessmentsOverview)),
                                    new SqlParameter("@LearningDevTraining", CC.CheckBoxValue(cbLearningDevTraining)),
                                    new SqlParameter("@PerformanceTraining", CC.CheckBoxValue(cbPerformanceTraining)),

                                    new SqlParameter("@FixMode", 1),
                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditPerformanceDetails", sqlparam);
            LblMsg.Text = "Record was updated successfully";
            MsgDiv.Visible = true;
            AlertMails();
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("performance.aspx", "btnSave_Click", ex.Message);
            LblMsg.Text = "Oops! Server problem....try after some time";
            MsgDiv.Visible = true;
        }
        finally { con.Close(); }
    }

    private void AlertMails()
    {
        string AbsoluteUri = string.Empty;
        string CurrentFilePath = string.Empty;
        string QueryString = string.Empty;
        string EmployeeName = string.Empty;
        //oMailSender
        DataTable odt = new DataTable();
        DataTable odt1 = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            AbsoluteUri = Request.Url.AbsoluteUri.ToString();
            CurrentFilePath = Request.AppRelativeCurrentExecutionFilePath.ToString();
            CurrentFilePath = CurrentFilePath.Remove(0, 2);
            QueryString = Request.QueryString.ToString();
            AbsoluteUri = AbsoluteUri.Replace(CurrentFilePath + "?" + QueryString, "");
            AbsoluteUri = AbsoluteUri + "loginpage.aspx?";

            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt1 = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetEmployeeDetails", sqlparam).Tables[0];
            if (odt1.Rows.Count > 0)
            {
                if (odt1.Rows[0]["Country"].ToString().ToLower() == "india")
                { return; }
                EmployeeName = odt1.Rows[0]["FirstName"].ToString() + " " + odt1.Rows[0]["LastName"].ToString();
            }
            else
            { return; }

            string query = string.Empty;
            query = "Select * from Users where Role = 'hr'";
            odt = SqlHelper.ExecuteDataset(con, CommandType.Text, query).Tables[0];

            if (odt.Rows.Count > 0)
            {
                for (int i = 0; i < odt.Rows.Count; i++)
                {
                    oMailSender.SendMailToHR(odt.Rows[i]["UserName"].ToString(), odt.Rows[i]["Role"].ToString(), AbsoluteUri, odt.Rows[i]["FirstName"].ToString() + " " + odt.Rows[i]["LastName"].ToString(), EmployeeName, "Performance Management");
                }
            }
            //CC.SendMailToHrIfAllSectionComplete(m_EmployeeID, EmployeeName);
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("performance.aspx", "AlertMails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Reset();
    }
}
