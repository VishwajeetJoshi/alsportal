﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;

public partial class offbdfinalhrprocess : System.Web.UI.Page
{
    CommonClass CC = new CommonClass();
    MailSender oMailSender = new MailSender();
    private string m_Mode = string.Empty;
    private int m_EmployeeID;
    private bool FixMode = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        SetQueryStringValue();
        if (!IsPostBack)
        {
            PopulateDetails();
        }
        MsgDiv.Visible = false;
    }

    private void SetQueryStringValue()
    {
        try
        {
            if (Request.QueryString["EmployeeID"] != null)
            {
                m_EmployeeID = Convert.ToInt32(Request.QueryString["EmployeeID"]);
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("offbdfinalhrprocess.aspx", "SetQueryStringValue", ex.Message);
            m_Mode = "Add";
            m_EmployeeID = 0;
        }
    }

    private void SetUserRole()
    {
        if (Session["UserRole"] != null)
        {
            if (Session["UserRole"].ToString().ToLower().Contains("system admin") || Session["UserRole"].ToString().ToLower().Contains("hr"))
            {
                if (m_EmployeeID > 0)
                { divSave.Visible = true; }
                else
                { divSave.Visible = false; }
            }
            else
            { divSave.Visible = false; } 
        }
    }

    protected override void Render(HtmlTextWriter writer)
    {
        SetUserRole();
        base.Render(writer);
    }

    private void PopulateDetails()
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetOffBoardingDetails", sqlparam).Tables[0];
            if (odt.Rows.Count > 0)
            {
                cbConfirmAll.Checked = CC.IfNullThenZero(odt.Rows[0]["FinalHRProcess"].ToString());
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("offbdfinalhrprocess.aspx", "PopulateDetails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    private void Reset()
    {
        cbConfirmAll.Checked = false;
    }


    protected void btnSaveSubmit_Click(object sender, EventArgs e)
    {
        if (saveEmployeeInformation() == 1)
        {
            //AlertMails();
        }
    }

    private int saveEmployeeInformation()
    {
        int returnValue;

        if (ValidateRecord() == false)
        {
            MsgDiv.Visible = true;
            returnValue = 0;
        }

        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] {                                         
                                        new SqlParameter("@EmployeeID", m_EmployeeID),
                                        new SqlParameter("@FinalHRProcess", CC.CheckBoxValue(cbConfirmAll)),
                                        new SqlParameter("@CreatedBy", Session["UserName"]),
                                        new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditOffbdFinalHRProcess", sqlparam);
            LblMsg.Text = "Record was updated successfully";
            MsgDiv.Visible = true;
            returnValue = 1;
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("offbdfinalhrprocess.aspx", "btnSave_Click", ex.Message);
            LblMsg.Text = "Oops! Server problem....try after some time";
            MsgDiv.Visible = true;
            returnValue = 0;
        }
        finally { con.Close(); }
        return returnValue;
    }

    private bool ValidateRecord()
    {
        return true;
    }

    private void AlertMails()
    {
        string AbsoluteUri = string.Empty;
        string CurrentFilePath = string.Empty;
        string QueryString = string.Empty;
        string EmployeeName = string.Empty;
        //oMailSender
        DataTable odt = new DataTable();
        DataTable odt1 = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            AbsoluteUri = Request.Url.AbsoluteUri.ToString();
            CurrentFilePath = Request.AppRelativeCurrentExecutionFilePath.ToString();
            CurrentFilePath = CurrentFilePath.Remove(0, 2);
            QueryString = Request.QueryString.ToString();
            AbsoluteUri = AbsoluteUri.Replace(CurrentFilePath + "?" + QueryString, "");
            AbsoluteUri = AbsoluteUri + "loginpage.aspx?";

            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt1 = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetEmployeeDetails", sqlparam).Tables[0];
            if (odt1.Rows.Count > 0)
            {
                EmployeeName = odt1.Rows[0]["FirstName"].ToString() + " " + odt1.Rows[0]["LastName"].ToString();
            }

            string query = string.Empty;
            query = "Select * from Users where Role = 'hr'";
            odt = SqlHelper.ExecuteDataset(con, CommandType.Text, query).Tables[0];

            if (odt.Rows.Count > 0)
            {
                for (int i = 0; i < odt.Rows.Count; i++)
                {
                    oMailSender.SendOffBdMailToHR(odt.Rows[i]["UserName"].ToString(), odt.Rows[i]["Role"].ToString(), AbsoluteUri, odt.Rows[i]["FirstName"].ToString() + " " + odt.Rows[i]["LastName"].ToString(), EmployeeName, "Admin");
                }
            }
            //CC.SendMailToHrIfAllSectionComplete(m_EmployeeID, EmployeeName);
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("offbdadmin.aspx", "AlertMails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Reset();
    }
}
