﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;

public partial class createdepartmentview : System.Web.UI.Page
{
    CommonClass CC = new CommonClass();
    private string m_Mode = string.Empty;
    private bool FixMode = false;
    PagedDataSource pgsource = new PagedDataSource();
    int findex, lindex;
    DataRow dr;
    private string m_DepartmentID = string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        if (Session["UserRole"] != null)
        {
            if (Session["UserRole"].ToString().ToLower().Contains("system admin") || Session["UserRole"].ToString().ToLower().Contains("hr"))
            { }
            else { Response.Redirect("~/loginpage.aspx?Mode=3"); }
        }
        SetQueryStringValue();
        lblNoData.Visible = false;
        if (!IsPostBack)
        {
            FillGridView();
            if (m_DepartmentID != string.Empty)
            {
                SetPageIndex();
            }
        }        
    }

    private void SetQueryStringValue()
    {
        try
        {
            if (Request.QueryString["departmentid"] != null)
            {
                m_DepartmentID = Request.QueryString["departmentid"];
            }           
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("createdepartmentview.aspx", "SetQueryStringValue", ex.Message);
            m_DepartmentID = string.Empty;
        }
    }

    private void SetPageIndex()
    {
        if (m_DepartmentID != string.Empty)
        {
            int rowcount, columncount;
            rowcount = ((System.Data.DataView)pgsource.DataSource).Table.Rows.Count;
            columncount = ((System.Data.DataView)pgsource.DataSource).Table.Columns.Count;
            for (int i = 0; i <= rowcount - 1; i++)
            {
                if (((System.Data.DataView)pgsource.DataSource).Table.Rows[i][0].ToString() == m_DepartmentID)
                {
                    int pagesize = 10;
                    if (i <= 10)
                        i = i + 1;
                    int a;
                    if (i <= pagesize)
                        a = 0;
                    else
                        a = i / pagesize;
                    CurrentPage = a;
                    FillGridView();
                    return;
                }
            }
        }
    }

    private void FillGridView()
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            string strQuery = string.Empty;
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetDepartmentViewDetails").Tables[0];
            if (odt.Rows.Count > 0)
            {
                pgsource.DataSource = odt.DefaultView;
                pgsource.AllowPaging = true;
                pgsource.PageSize = 10;

                //Store it Total pages value in View state
                ViewState["totpage"] = pgsource.PageCount;

                if (CurrentPage > Convert.ToInt32(ViewState["totpage"]) - 1)
                {
                    CurrentPage = Convert.ToInt32(ViewState["totpage"]) - 1;
                }

                pgsource.CurrentPageIndex = CurrentPage;

                //Enabled true Link button previous when current page is not equal first page 
                //Enabled false Link button previous when current page is first page
                lbPrev.Enabled = !pgsource.IsFirstPage;

                //Enabled true Link button Next when current page is not equal last page 
                //Enabled false Link button Next when current page is last page
                lbNext.Enabled = !pgsource.IsLastPage;

                //Bind resulted PageSource into the DataList
                gvDepartmentListing.DataSource = pgsource;
                gvDepartmentListing.DataBind();

                doPaging();
            }
            else
            {
                DataTable tempdt = new DataTable();
                tempdt.Columns.Add("DepartmentName");
                tempdt.Columns.Add("DepartmentID");
                tempdt.Columns.Add("Consulting_ESP");
                tempdt.Columns.Add("Consulting_PP");
                tempdt.Columns.Add("Consulting_Op");
                //tempdt.Columns.Add("Vendor_ESP");
                //tempdt.Columns.Add("Vendor_PP");
                //tempdt.Columns.Add("NSG_Op");
                tempdt.Columns.Add("HSG_Op");
                //tempdt.Columns.Add("US_UK_P");
                tempdt.Columns.Add("WIPReview");
                tempdt.Columns.Add("DealReview");
                tempdt.Columns.Add("MnthProbCall");
                tempdt.Columns.Add("WklEuropeUdt");
                tempdt.Columns.Add("WklVendorCal");
                tempdt.Columns.Add("WklHWSWCall");
                tempdt.Columns.Add("SDTeamMtg");
                tempdt.Columns.Add("SSTeamMtg");
                tempdt.Rows.Add("");
                gvDepartmentListing.DataSource = tempdt;
                gvDepartmentListing.DataBind();
                gvDepartmentListing.Rows[0].Visible = false;
                lblNoData.Visible = true;
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("createdepartmentview.aspx", "FillGridView", ex.Message);
            //LblMsg.Text = "Wrong User Name or Password";
            //MsgDiv.Visible = true;
        }
        finally
        {
            con.Close();
        }
    }

    private void doPaging()
    {
        DataTable dt = new DataTable();
        dt.Columns.Add("Index");

        findex = 1;
        lindex = Convert.ToInt32(ViewState["totpage"]);

        if (lindex > (CurrentPage + 1))
        {
            if (CurrentPage >= 4)
            {
                lindex = CurrentPage + 2;
            }
        }
        int i;
        if (CurrentPage >= 4)
        { i = lindex - 4; }
        else
        {
            i = 1;
        }
        while (i <= lindex)
        {
            DataRow dr = dt.NewRow();
            dr[0] = i;
            dt.Rows.Add(dr);
            i++;
        }

        if (dt.Rows.Count > 0)
        {
            rptPaging.DataSource = dt;
            rptPaging.DataBind();
        }

    }
    private int CurrentPage
    {
        get
        {   //Check view state is null if null then return current index value as "0" else return specific page viewstate value
            if (ViewState["CurrentPage"] == null)
            {
                return 0;
            }
            else
            {
                return ((int)ViewState["CurrentPage"]);
            }
        }
        set
        {
            ViewState["CurrentPage"] = value;
        }
    }

    protected override void Render(HtmlTextWriter writer)
    {
        //if (Convert.ToInt32(ViewState["totpage"]) <= 1)
        //{
        //    divPaging.Visible = false;
        //}
        base.Render(writer);
    }
    
    protected void rptPaging_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        LinkButton lbIndex = (LinkButton)e.Item.FindControl("lbIndexing");
        CurrentPage = Convert.ToInt32(lbIndex.Text) - 1;
        FillGridView();
    }
    protected void rptPaging_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            LinkButton lbIndex = (LinkButton)e.Item.FindControl("lbIndexing");
            if (Convert.ToInt32(lbIndex.Text) == (CurrentPage + 1))
            {
                lbIndex.CssClass = "activepagination";
            }
        }
    }
    protected void lbPrev_Click(object sender, EventArgs e)
    {
        CurrentPage -= 1;
        FillGridView();
    }
    protected void lbNext_Click(object sender, EventArgs e)
    {
        CurrentPage += 1;
        FillGridView();
    }
    protected void gvDepartmentListing_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            LinkButton id = (LinkButton)e.Row.FindControl("lbDelete");
            string cid = id.Text;
            id.Attributes.Add("onclick", "return alertuserfordelete();");
        }
    }

    protected void gvDepartmentListing_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.ToLower() == "editdetails")
        {
            string username = e.CommandArgument.ToString();
            Response.Redirect("createdepartment.aspx?mode=edit&departmentid=" + username);
        }
        if (e.CommandName.ToLower() == "delete")
        {
            DeleteDepartment(Convert.ToInt32(e.CommandArgument));
        }
    }

    protected void gvDepartmentListing_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        //Label id = (Label)gvDepartmentListing.Rows[e.RowIndex].FindControl("lblDepartmentID");
        //int depID = Convert.ToInt32(id.Text);
    }

    private void DeleteDepartment(int depID)
    {
        SqlConnection con = SqlHelper.GetConnection();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@departmentid", depID);
            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_DeleteDepartment", sqlparam);
            FillGridView();
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("createdepartmentview.aspx", "gvUserListing_RowDeleting", ex.Message);
            LblMsg.Text = "Error in deleting department: " + ex.Message;
            MsgDiv.Visible = true;
        }
        finally { con.Close(); }
    }
}
