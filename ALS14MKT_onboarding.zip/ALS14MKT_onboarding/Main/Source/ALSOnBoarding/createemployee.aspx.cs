﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;

public partial class createemployee : System.Web.UI.Page
{
    CommonClass CC = new CommonClass();
    private string m_Mode = string.Empty;
    private int m_EmployeeID;
    private bool FixMode = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        //SetQueryStringValue();

        if (!IsPostBack)
        {
            Session["update"] = Server.UrlEncode(System.DateTime.Now.ToString());
            FillDropDownList();
        }
        MsgDiv.Visible = false;
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        ViewState["update"] = Session["update"];
    }

    private void FillDropDownList()
    {
        //-------Fill Country
        ddlCountry.DataSource = CC.AllCountry();
        ddlCountry.DataTextField = "CountryName";
        ddlCountry.DataValueField = "CountryName";
        ddlCountry.DataBind();
        ddlCountry.Items.Insert(0, new ListItem("-- Select One --", "0"));

        //-------Fill RefCountry
        ddlRefCountry.DataSource = CC.AllCountry();
        ddlRefCountry.DataTextField = "CountryName";
        ddlRefCountry.DataValueField = "CountryName";
        ddlRefCountry.DataBind();
        ddlRefCountry.Items.Insert(0, new ListItem("-- Select One --", "0"));

        //-------Fill State
        ddlState.DataSource = CC.USState();
        ddlState.DataTextField = "StateName";
        ddlState.DataValueField = "StateID";
        ddlState.DataBind();
        ddlState.Items.Insert(0, new ListItem("-- Select One --", "0"));

        //-------Fill RefState
        ddlRefState.DataSource = CC.USState();
        ddlRefState.DataTextField = "StateName";
        ddlRefState.DataValueField = "StateID";
        ddlRefState.DataBind();
        ddlRefState.Items.Insert(0, new ListItem("-- Select One --", "0"));
    }

    private void Reset()
    {
        txtLastName.Text = "";
        txtFirstName.Text = "";
        txtMiddleInitial.Text = "";
        txtStreet.Text = "";
        txtAptUnit.Text = "";
        txtCity.Text = "";
        ddlCountry.SelectedIndex = 0;
        ddlState.SelectedIndex = 0;
        divState.Visible = false;
        txtZip.Text = "";
        txtHomePhone.Text = "";
        txtCellPhone.Text = "";
        txtBusinessCard.Text = "";
        txtCoEmailId.Text = "";
        txtPerEmailId.Text = "";
        txtRefLastName.Text = "";
        txtRefFirstName.Text = "";
        txtRefMiddleInitial.Text = "";
        txtRefStreet.Text = "";
        txtRefAptUnit.Text = "";
        txtRefCity.Text = "";
        ddlRefCountry.SelectedIndex = 0;
        ddlRefState.SelectedIndex = 0;
        divRefState.Visible = false;
        txtRefZip.Text = "";
        txtRefPriPhone.Text = "";
        txtRefAltPhone.Text = "";
        txtRelationship.Text = "";
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["update"].ToString() == ViewState["update"].ToString())
        {
            if (ValidateRecord() == false)
            {
                MsgDiv.Visible = true;
                return;
            }

            string state = string.Empty;
            string refState = string.Empty;
            string country = string.Empty;
            string refcountry = string.Empty;

            if (ddlCountry.SelectedIndex != 0)
            {
                country = ddlCountry.SelectedItem.ToString();
                if (ddlCountry.SelectedItem.ToString().ToUpper() == "USA")
                {
                    if (ddlState.SelectedIndex != 0)
                    {
                        state = ddlState.SelectedItem.ToString();
                    }
                }
                else
                {
                    if (txtOtherState.Text != "")
                    {
                        state = txtOtherState.Text;
                    }
                }
            }
            else
            {
                if (ddlState.SelectedIndex != 0)
                {
                    state = ddlState.SelectedItem.ToString();
                }
            }

            if (ddlRefCountry.SelectedIndex != 0)
            {
                refcountry = ddlRefCountry.SelectedItem.ToString();
                if (ddlRefCountry.SelectedItem.ToString().ToUpper() == "USA")
                {
                    if (ddlRefState.SelectedIndex != 0)
                    {
                        refState = ddlRefState.SelectedItem.ToString();
                    }
                }
                else
                {
                    if (txtRefOtherState.Text != "")
                    {
                        refState = txtRefOtherState.Text;
                    }
                }
            }
            else
            {
                if (ddlRefState.SelectedIndex != 0)
                {
                    refState = ddlRefState.SelectedItem.ToString();
                }
            }

            SqlConnection con = SqlHelper.GetConnection();
            con.Open();
            try
            {
                SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@Mode", "Add"),
                                    new SqlParameter("@EmployeeID", GetEmployeeID()),
                                    new SqlParameter("@FirstName", Server.HtmlEncode(txtFirstName.Text)),
                                    new SqlParameter("@LastName", Server.HtmlEncode(txtLastName.Text)),
                                    new SqlParameter("@MiddleInitial", Server.HtmlEncode(txtMiddleInitial.Text)),
                                    new SqlParameter("@Street", Server.HtmlEncode(txtStreet.Text)),
                                    new SqlParameter("@AptUnit", Server.HtmlEncode(txtAptUnit.Text)),
                                    new SqlParameter("@City", Server.HtmlEncode(txtCity.Text)),        
                                    new SqlParameter("@Country", country),
                                    new SqlParameter("@State", state),
                                    new SqlParameter("@PostalCode", Server.HtmlEncode(txtZip.Text)),
                                    new SqlParameter("@HomePhone", Server.HtmlEncode(txtHomePhone.Text)),
                                    new SqlParameter("@CellPhone", Server.HtmlEncode(txtCellPhone.Text)),
                                    new SqlParameter("@BusinessCardName", Server.HtmlEncode(txtBusinessCard.Text)),
                                    new SqlParameter("@PerEmailID", Server.HtmlEncode(txtPerEmailId.Text)),
                                    new SqlParameter("@CompanyEmailID", Server.HtmlEncode(txtCoEmailId.Text)),
                                    new SqlParameter("@ConFirstName", Server.HtmlEncode(txtRefFirstName.Text)),
                                    new SqlParameter("@ConLastName", Server.HtmlEncode(txtRefLastName.Text)),
                                    new SqlParameter("@ConMiddleInitial", Server.HtmlEncode(txtRefMiddleInitial.Text)),
                                    new SqlParameter("@ConStreet", Server.HtmlEncode(txtRefStreet.Text)),
                                    new SqlParameter("@ConAptUnit", Server.HtmlEncode(txtRefAptUnit.Text)),
                                    new SqlParameter("@ConCity", Server.HtmlEncode(txtRefCity.Text)),
                                    new SqlParameter("@ConCountry", refcountry), 
                                    new SqlParameter("@ConState", refState),
                                    new SqlParameter("@ConPostalCode", Server.HtmlEncode(txtRefZip.Text)),
                                    new SqlParameter("@ConPriPhone", Server.HtmlEncode(txtRefPriPhone.Text)),
                                    new SqlParameter("@ConAltPhone", Server.HtmlEncode(txtRefAltPhone.Text)),
                                    new SqlParameter("@Relationship", Server.HtmlEncode(txtRelationship.Text)),
                                    new SqlParameter("@FixMode", false),
                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

                SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEmployeeDetails", sqlparam);
                LblMsg.Text = "Record was added successfully";
                MsgDiv.Visible = true;
                Reset();
            }
            catch (Exception ex)
            {
                CommonClass.AddErrorTrail("employeedetail.aspx", "btnSave_Click", ex.Message);
                LblMsg.Text = "Oops! Server problem....try after some time";
                MsgDiv.Visible = true;
            }
            finally { con.Close(); }
            Session["update"] = Server.UrlEncode(System.DateTime.Now.ToString());
        }
        else
        {
            Reset();
        }
    }

    private bool ValidateRecord()
    {
        if (txtPerEmailId.Text != "")
        {
            SqlConnection sqlcon = SqlHelper.GetConnection();
            sqlcon.Open();
            try
            {
                DataTable odt = new DataTable();
                odt = SqlHelper.ExecuteDataset(sqlcon, CommandType.Text, "Select * from Employee.EmployeeDetails Where PerEmailID = '" + Server.HtmlEncode(txtPerEmailId.Text.Trim()) + "'").Tables[0];
                if (odt.Rows.Count > 0)
                {
                    LblMsg.Text = "This emailid already exist. You cannot enter duplicate emailid.";
                    return false;
                }
            }
            catch (Exception ex)
            { }
            finally { sqlcon.Close(); }
            return true;
        }
        else
        {
            return true;
        }
    }

    private int GetEmployeeID()
    {
        int empid;
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            empid = AddOne(Convert.ToString((SqlHelper.ExecuteScalar(con, CommandType.Text, "Select max(EmployeeID) from Employee.EmployeeDetails with (nolock)"))));
            m_EmployeeID = empid;
            return empid;
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("employeedetail.aspx", "GetEmployeeID", ex.Message);
            return 1;
        }
        finally
        { con.Close(); }
    }

    private int AddOne(string value)
    {
        if (value == null)
        {
            return 1;
        }
        else if (value == "")
        {
            return 1;
        }
        else
        {
            return Convert.ToInt32(value) + 1;
        }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        Reset();
    }

    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        string state = string.Empty;
        if (ddlCountry.SelectedIndex != 0)
        {
            if (ddlCountry.SelectedItem.ToString().ToUpper() == "USA")
            {
                if (ddlState.SelectedIndex != 0)
                {
                    state = ddlState.SelectedItem.ToString();
                }
                ddlState.DataSource = CC.USState();
                ddlState.DataTextField = "StateName";
                ddlState.DataValueField = "StateID";
                ddlState.DataBind();
                ddlState.Items.Insert(0, new ListItem("-- Select One --", "0"));
                if (state != string.Empty)
                {
                    ddlState.SelectedIndex = ddlState.Items.IndexOf(ddlState.Items.FindByText(state));
                }
                divState.Visible = false;
                txtOtherState.Text = "";
            }
            else
            {
                ddlState.Items.Clear();
                ddlState.Items.Insert(0, new ListItem("-- Select One --", "0"));
                divState.Visible = true;
            }
        }
        else
        {
            ddlState.SelectedIndex = 0;
            divState.Visible = false;
            txtOtherState.Text = "";
        }
    }

    protected void ddlRefCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        string state = string.Empty;
        if (ddlRefCountry.SelectedIndex != 0)
        {
            if (ddlRefCountry.SelectedItem.ToString().ToUpper() == "USA")
            {
                if (ddlRefState.SelectedIndex != 0)
                {
                    state = ddlRefState.SelectedItem.ToString();
                }
                ddlRefState.DataSource = CC.USState();
                ddlRefState.DataTextField = "StateName";
                ddlRefState.DataValueField = "StateID";
                ddlRefState.DataBind();
                ddlRefState.Items.Insert(0, new ListItem("-- Select One --", "0"));
                if (state != string.Empty)
                {
                    ddlRefState.SelectedIndex = ddlRefState.Items.IndexOf(ddlState.Items.FindByText(state));
                }
                divRefState.Visible = false;
                txtRefOtherState.Text = "";
            }
            else
            {
                ddlRefState.Items.Clear();
                ddlRefState.Items.Insert(0, new ListItem("-- Select One --", "0"));
                divRefState.Visible = true;
            }
        }
        else
        {
            ddlRefState.SelectedIndex = 0;
            divRefState.Visible = false;
            txtRefOtherState.Text = "";
        }
    }
}
