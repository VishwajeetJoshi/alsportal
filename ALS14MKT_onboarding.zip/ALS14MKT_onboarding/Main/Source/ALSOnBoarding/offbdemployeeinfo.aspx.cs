﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;
using System.Globalization;
using System.Configuration;

public partial class offbdemployeeinfo : System.Web.UI.Page
{
    CommonClass CC = new CommonClass();
    MailSender oMailSender = new MailSender();
    private string m_Mode = string.Empty;
    private int m_EmployeeID;
    private bool FixMode = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        SetQueryStringValue();
        if (!IsPostBack)
        {
            //FillDropDownList();
            PopulateDetails();
        }
        MsgDiv.Visible = false;
    }

    private void SetQueryStringValue()
    {
        try
        {
            if (Request.QueryString["EmployeeID"] != null)
            {
                m_EmployeeID = Convert.ToInt32(Request.QueryString["EmployeeID"]);
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("offbdemployeeinfo.aspx", "SetQueryStringValue", ex.Message);
            m_Mode = "Add";
            m_EmployeeID = 0;
        }
    }

    private void SetUserRole()
    {
        if (Session["UserRole"] != null)
        {
            if (Session["UserRole"].ToString().ToLower().Contains("system admin") || Session["UserRole"].ToString().ToLower().Contains("hr"))
            {
                if (m_EmployeeID > 0)
                { divSave.Visible = true; }
                else
                { divSave.Visible = false; }
            }
            else
            { divSave.Visible = false; }
        }
    }

    protected override void Render(HtmlTextWriter writer)
    {
        SetUserRole();
        base.Render(writer);
    }

    private void PopulateDetails()
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetOffBdEmpInfo", sqlparam).Tables[0];
            if (odt.Rows.Count > 0)
            {
                txtEmpAddress.Text = CC.IfNullThenBlank(odt.Rows[0]["EmpAddress"].ToString());
                txtEmpAddress.ToolTip = txtEmpAddress.Text;
                if (DBNull.Value != (odt.Rows[0]["LastDay"]))
                {
                    DateTime dt;
                    dt = Convert.ToDateTime(odt.Rows[0]["LastDay"].ToString());
                    txtLastDay.Text = CC.checkdate(dt);
                }
                if (DBNull.Value != (odt.Rows[0]["SeparationDate"]))
                {
                    DateTime dt;
                    dt = Convert.ToDateTime(odt.Rows[0]["SeparationDate"].ToString());
                    txtSeparationDate.Text = CC.checkdate(dt);
                }
                ddlDismissal.SelectedIndex = ddlDismissal.Items.IndexOf(ddlDismissal.Items.FindByText(odt.Rows[0]["ReasonDismissal"].ToString()));

                txtForwardEmailAddress.Text = CC.IfNullThenBlank(odt.Rows[0]["ForwardEmailAddress"].ToString());
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("offbdemployeeinfo.aspx", "PopulateDetails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    private void Reset()
    {
        txtLastDay.Text = "";
        txtSeparationDate.Text = "";
        ddlDismissal.SelectedIndex = 0;
        txtForwardEmailAddress.Text = "";
    }

    private void EnableDisable(bool boolValue)
    {
        //txtLastDay.ReadOnly = true;
        //txtSeparationDate.ReadOnly = true;
        //ddlDismissal.SelectedIndex = 0;
        //txtForwardEmailAddress.ReadOnly = true;  
    }

    private bool ValidateRecord()
    {
        return true;
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        saveEmployeeInformation();
    }

    private int saveEmployeeInformation()
    {
        int returnValue;
        string reasonDismissal = string.Empty;

        if (ValidateRecord() == false)
        {
            MsgDiv.Visible = true;
            returnValue = 0;
        }

        if (ddlDismissal.SelectedIndex != 0)
        {
            reasonDismissal = ddlDismissal.SelectedItem.ToString();
        }

        DateTime lastDate;
        if (txtLastDay.Text != "")
            lastDate = DateTime.ParseExact(txtLastDay.Text, "MM/dd/yyyy", CultureInfo.CurrentCulture);
        else
            lastDate = Convert.ToDateTime("01/01/1900");

        DateTime separationDate;
        if (txtSeparationDate.Text != "")
            separationDate = DateTime.ParseExact(txtSeparationDate.Text, "MM/dd/yyyy", CultureInfo.CurrentCulture);
        else
            separationDate = Convert.ToDateTime("01/01/1900");

        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] {                                         
                                        new SqlParameter("@EmployeeID", m_EmployeeID),
                                        new SqlParameter("@LastDay", lastDate),
                                        new SqlParameter("@SeparationDate", separationDate),
                                        new SqlParameter("@ReasonDismissal", reasonDismissal),
                                        new SqlParameter("@ForwardEmailAddress", Server.HtmlEncode(txtForwardEmailAddress.Text)),
                                        new SqlParameter("@CreatedBy", Session["UserName"]),
                                        new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditOffbdEmpInfo", sqlparam);
            LblMsg.Text = "Record was updated successfully";
            MsgDiv.Visible = true;
            returnValue = 1;
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("offbdemployeeinfo.aspx", "btnSave_Click", ex.Message);
            LblMsg.Text = "Oops! Server problem....try after some time";
            MsgDiv.Visible = true;
            returnValue = 0;
        }
        finally { con.Close(); }
        return returnValue;
    }

    protected void btnSaveSubmit_Click(object sender, EventArgs e)
    {
        if (saveEmployeeInformation() == 1)
        {
            AlertMails();
        }
    }

    private void AlertMails()
    {
        string AbsoluteUri = string.Empty;
        string CurrentFilePath = string.Empty;
        string QueryString = string.Empty;
        string EmployeeName = string.Empty;

        //oMailSender
        DataTable odt = new DataTable();
        DataTable odt1 = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            AbsoluteUri = Request.Url.AbsoluteUri.ToString();
            CurrentFilePath = Request.AppRelativeCurrentExecutionFilePath.ToString();
            CurrentFilePath = CurrentFilePath.Remove(0, 2);
            QueryString = Request.QueryString.ToString();
            AbsoluteUri = AbsoluteUri.Replace(CurrentFilePath + "?" + QueryString, "");
            AbsoluteUri = AbsoluteUri + "loginpage.aspx?";

            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt1 = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetEmployeeDetails", sqlparam).Tables[0];
            if (odt1.Rows.Count > 0)
            {
                EmployeeName = odt1.Rows[0]["FirstName"].ToString() + " " + odt1.Rows[0]["LastName"].ToString();//StartDate
            }

            string query = string.Empty;
            query = "Select * from Users where Role not in ('admin', 'hr')";
            odt = SqlHelper.ExecuteDataset(con, CommandType.Text, query).Tables[0];

            if (odt.Rows.Count > 0)
            {
                for (int i = 0; i < odt.Rows.Count; i++)
                {
                    SendMail(odt.Rows[i]["UserName"].ToString(), odt.Rows[i]["Role"].ToString(), AbsoluteUri, odt.Rows[i]["FirstName"].ToString() + " " + odt.Rows[i]["LastName"].ToString(), EmployeeName);
                }
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("offbdemployeeinfo.aspx", "AlertMails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    private void SendMail(string UserID, string Role, string URLPath, string name, string emplyeename)
    {
        string subject = string.Empty;
        string body = string.Empty;

        //subject = "<p style='font-size:10pt;font-family:Arial;'>New employee " + emplyeename + " OnBoarding</p>";
        subject = emplyeename + " OffBoarding";

        //body = name + ",<br />";
        body = "<p style='font-size:10pt;font-family:Arial;'>";
        body += name + ",<br />";

        body += "<br />";
        body += emplyeename + " is no longer with the company; please complete all offboarding items.<br />";
        body += "<br />";

        List<string> roleList = new List<string>();
        roleList = Role.Split(',').ToList();
        foreach (string _Role in roleList)
        {
            if (_Role.Trim().ToLower() == "hr")
            {
                //body += "URL: " + URLPath + "module=" + " <br />";
            }
            else if (_Role.Trim().ToLower() == "it")
            {
                body += "Click Here to get started: " + URLPath + "module=offbdit.aspx&EmployeeID=" + m_EmployeeID + " <br />";
            }
            else if (_Role.Trim().ToLower() == "administrative")
            {
                body += "Click Here to get started: " + URLPath + "module=offbdadmin.aspx&EmployeeID=" + m_EmployeeID + " <br />";
            }
            else if (Server.HtmlDecode(_Role.Trim().ToLower()) == "sales & marketing")
            {
                body += "Click Here to get started: " + URLPath + "module=offbdsalesmktg.aspx&EmployeeID=" + m_EmployeeID + " <br />";
            }
        }

        body += "<br />";
        body += "Thanks and Regards<br />";
        //body += "<br />";
        body += ConfigurationManager.AppSettings["HRName"].ToString() + "<br />";
        //body += "Director of Human Resources<br />";
        //body += "214-696-6410<br />";
        body += ConfigurationManager.AppSettings["HRContact"].ToString() + "<br />";
        body += "</p>";
        //oMailSender.SendMailMessage("from", "to", "bcc", "cc", "subject", "body");
        oMailSender.SendMailMessage(Session["UserName"].ToString(), UserID, "", "", subject, body);
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Reset();
    }
}
