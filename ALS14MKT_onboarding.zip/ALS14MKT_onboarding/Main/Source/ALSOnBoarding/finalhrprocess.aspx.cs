﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;
using System.Globalization;

public partial class finalhrprocess : System.Web.UI.Page
{
    CommonClass CC = new CommonClass();
    private string m_Mode = string.Empty;
    private int m_EmployeeID;
    private bool FixMode = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        SetQueryStringValue();

        if (!IsPostBack)
        {
            FillFinalHrProcess();
        }
        MsgDiv.Visible = false;
    }

    private void SetQueryStringValue()
    {
        try
        {
            if (Request.QueryString["EmployeeID"] != null)
            {
                m_EmployeeID = Convert.ToInt32(Request.QueryString["EmployeeID"]);
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("finalhrprocess.aspx", "SetQueryStringValue", ex.Message);
            m_Mode = "Add";
            m_EmployeeID = 0;
        }
    }

    private void SetUserRole()
    {
        if (Session["UserRole"] != null)
        {
            if (m_EmployeeID > 0)
            { divSave.Visible = true; }
            else
            { divSave.Visible = false; }
        }
    }

    protected override void Render(HtmlTextWriter writer)
    {
        SetUserRole();
        base.Render(writer);
    }

    private void FillFinalHrProcess()
    {
        PopulateDetails();
        if (FixMode == true)
        {
            EnableDisable(true);
            divSave.Visible = false;
        }
    }

    private void PopulateDetails()
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetHRFinalProcess", sqlparam).Tables[0];
            if (odt.Rows.Count > 0)
            {
                cbW4W9.Checked = CC.IfNullThenZero(odt.Rows[0]["WE_W4W9"].ToString());
                cbI9.Checked = CC.IfNullThenZero(odt.Rows[0]["WE_I9"].ToString());
                cbDDForm.Checked = CC.IfNullThenZero(odt.Rows[0]["WE_DDForm"].ToString());
                cbPolicySign.Checked = CC.IfNullThenZero(odt.Rows[0]["WE_PolicySign"].ToString());
                cbRuneverify.Checked = CC.IfNullThenZero(odt.Rows[0]["Run_e_verify"].ToString());
                cbBackgroundCheck.Checked = CC.IfNullThenZero(odt.Rows[0]["BackgoundCheck"].ToString());
                //cbAgreementExecuted.Checked = CC.IfNullThenZero(odt.Rows[0]["AgreementExecuted"].ToString());
                //cbDocumentsGathered.Checked = CC.IfNullThenZero(odt.Rows[0]["DocumentsGathered"].ToString());
                //cbCounselGroupLeadIntro.Checked = CC.IfNullThenZero(odt.Rows[0]["CounselGroupLeadIntroduction"].ToString());
                //cbPeerCoachingIntro.Checked = CC.IfNullThenZero(odt.Rows[0]["PeerCoachingIntroduction"].ToString());
                //cbBioUpdtdPtdWiki.Checked = CC.IfNullThenZero(odt.Rows[0]["BioUpdatedPostedOnWiki"].ToString());
                //cbContactMeetingSetReaghan.Checked = CC.IfNullThenZero(odt.Rows[0]["ContactsMeetingWithReaghan"].ToString());
                cbAddtoDir.Checked = CC.IfNullThenZero(odt.Rows[0]["AddToDirectory"].ToString());
                //cbCoDir.Checked = CC.IfNullThenZero(odt.Rows[0]["CompanyDirectoryProvided"].ToString());
                //cbVoicemailInst.Checked = CC.IfNullThenZero(odt.Rows[0]["VoicemailInstuctionSent"].ToString());
                //cbVcfCrUp.Checked = CC.IfNullThenZero(odt.Rows[0]["VcfCreatedUploaded"].ToString());
                //cbSkillDatabase.Checked = CC.IfNullThenZero(odt.Rows[0]["SkillDatabase"].ToString());
                cbLunchSecheduled.Checked = CC.IfNullThenZero(odt.Rows[0]["WelcomeLunchScheduled"].ToString());
                //cbBenefitVideo.Checked = CC.IfNullThenZero(odt.Rows[0]["BenefitVideoSent"].ToString());
                cbBenefitOverview.Checked = CC.IfNullThenZero(odt.Rows[0]["BenefitOverview"].ToString());
                //cbBenefitEnrollment.Checked = CC.IfNullThenZero(odt.Rows[0]["BenefitEnrollmentSent"].ToString());
                cbAdded401k.Checked = CC.IfNullThenZero(odt.Rows[0]["Added401k"].ToString());
                cbIndividualHeadshot.Checked = CC.IfNullThenZero(odt.Rows[0]["IndividualHeadshot"].ToString());
                //cbTrainingSalesSupport.Checked = CC.IfNullThenZero(odt.Rows[0]["TrainingSalesSupport"].ToString());
                //cbTrainingPBOC.Checked = CC.IfNullThenZero(odt.Rows[0]["TrainingPBOC"].ToString());
                cbTrainingReplicon.Checked = CC.IfNullThenZero(odt.Rows[0]["TrainingReplicon"].ToString());
                cbAlsbridgeOverview.Checked = CC.IfNullThenZero(odt.Rows[0]["AlsbridgeOverviewTraining"].ToString());

                //New added fields
                //cbNewHireTest.Checked = CC.IfNullThenZero(odt.Rows[0]["HireTest"].ToString());
                //cbLinkedinUpdate.Checked = CC.IfNullThenZero(odt.Rows[0]["LinkedinUpdate"].ToString());
                cbRepliconCounselProject.Checked = CC.IfNullThenZero(odt.Rows[0]["RepliconCounselProject"].ToString());
                cbADPPayroll.Checked = CC.IfNullThenZero(odt.Rows[0]["ADPPayroll"].ToString());
                cbAlsbridgeDebitCard.Checked = CC.IfNullThenZero(odt.Rows[0]["AlsBridgeDebitCard"].ToString());

                //New aaded fiels (14/02/2014)
                //cbReferences.Checked = CC.IfNullThenZero(odt.Rows[0]["Reference"].ToString());
                cbResume.Checked = CC.IfNullThenZero(odt.Rows[0]["Resume"].ToString());
                cbAssessments.Checked = CC.IfNullThenZero(odt.Rows[0]["Assessments"].ToString());

                //New added fields on 180814
                cbScheduleOnboarding.Checked = CC.IfNullThenZero(odt.Rows[0]["ScheduleOnboarding"].ToString());
                cbOnboardingAgenda.Checked = CC.IfNullThenZero(odt.Rows[0]["OnboardingAgenda"].ToString());
                cbOfferLetter.Checked = CC.IfNullThenZero(odt.Rows[0]["OfferLetter"].ToString());
                cbEmploymentAgreement.Checked = CC.IfNullThenZero(odt.Rows[0]["AgreementExecuted"].ToString());
                cbAddedToPayrollIndia.Checked = CC.IfNullThenZero(odt.Rows[0]["AddedToPayrollIndia"].ToString());
                cbNewHireKit.Checked = CC.IfNullThenZero(odt.Rows[0]["HireTest"].ToString());
                //cbBenefitOverview.Checked = CC.IfNullThenZero(odt.Rows[0]["BenefitOverview"].ToString());

            }// 
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("finalhrprocess.aspx", "PopulateDetails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    private string IfNullThenBlank(string value)
    {
        if (value == null)
        {
            return "";
        }
        else if (value == "")
        {
            return "";
        }
        else
        {
            return Server.HtmlDecode(value);
        }
    }

    private void Reset()
    {
        cbW4W9.Checked = false;
        cbI9.Checked = false;
        cbDDForm.Checked = false;
        cbPolicySign.Checked = false;
        cbRuneverify.Checked = false;
        cbBackgroundCheck.Checked = false;
        //cbAgreementExecuted.Checked = false;
        //cbDocumentsGathered.Checked = false;
        //cbCounselGroupLeadIntro.Checked = false;
        //cbPeerCoachingIntro.Checked = false;
        //cbBioUpdtdPtdWiki.Checked = false;
        //cbContactMeetingSetReaghan.Checked = false;
        cbAddtoDir.Checked = false;
        //cbCoDir.Checked = false;
        //cbVoicemailInst.Checked = false;
        //cbVcfCrUp.Checked = false;
        //cbSkillDatabase.Checked = false;
        cbLunchSecheduled.Checked = false;
        //cbBenefitVideo.Checked = false;
        cbBenefitOverview.Checked = false;
        //cbBenefitEnrollment.Checked = false;
        cbAdded401k.Checked = false;
        cbIndividualHeadshot.Checked = false;
        //cbTrainingSalesSupport.Checked = false;
        //cbTrainingPBOC.Checked = false;
        cbTrainingReplicon.Checked = false;
        cbAlsbridgeOverview.Checked = false;

        //New added fields
        //cbNewHireTest.Checked = false;
        //cbLinkedinUpdate.Checked = false;
        cbRepliconCounselProject.Checked = false;
        cbADPPayroll.Checked = false;
        cbAlsbridgeDebitCard.Checked = false;

        //cbReferences.Checked = false;
        cbResume.Checked = false;
        cbAssessments.Checked = false;

        //New added fields on 180814
        cbScheduleOnboarding.Checked = false;
        cbOnboardingAgenda.Checked = false;
        cbOfferLetter.Checked = false;
        cbEmploymentAgreement.Checked = false;
        cbAddedToPayrollIndia.Checked = false;
        cbNewHireKit.Checked = false;
        cbBenefitOverview.Checked = false;
    }

    private void EnableDisable(bool boolValue)
    {
        //dllAddtoDir.SelectedIndex = 0;
        //ddlVoicemailInst.SelectedIndex = 0;
        //ddlCoDir.SelectedIndex = 0;
        //ddlVcfCrUp.SelectedIndex = 0;
        //ddlWelcomeEmail.SelectedIndex = 0;
        //ddlBackgroundCheck.SelectedIndex = 0;
        //ddlRuneverify.SelectedIndex = 0;
        //ddlAgreementExecuted.SelectedIndex = 0;
        //ddlDocumentsGathered.SelectedIndex = 0;
        //ddlLunchSecheduled.SelectedIndex = 0;
        //ddlBenefitSite.SelectedIndex = 0;
        //ddlBenefitVideo.SelectedIndex = 0;
        //ddlBenefitOverview.SelectedIndex = 0;
        //ddlBenefitEnrollment.SelectedIndex = 0;
        //ddlAdded401k.SelectedIndex = 0;
        //ddlTrainingSalesSupport.SelectedIndex = 0;
        //ddlTrainingPBOC.SelectedIndex = 0;
        //ddlTrainingReplicon.SelectedIndex = 0;
        //ddlAlsbridgeOverview.SelectedIndex = 0;
        //ddlTeamIntro.SelectedIndex = 0;
        //ddlCounselGroupLeadIntro.SelectedIndex = 0;
        //ddlPeerCoachingIntro.SelectedIndex = 0;
        //ddlBioUpdtdPtdWiki.SelectedIndex = 0;
        //ddlSkillDatabase.SelectedIndex = 0;
        //ddlContactMeetingSetReaghan.SelectedIndex = 0;
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@EmployeeID", m_EmployeeID),
                                    new SqlParameter("@AddToDirectory", CC.CheckBoxValue(cbAddtoDir)),
                                    //new SqlParameter("@VoicemailInstuctionSent", CC.CheckBoxValue(cbVoicemailInst)),
                                    //new SqlParameter("@CompanyDirectoryProvided", CC.CheckBoxValue(cbCoDir)),
                                    //new SqlParameter("@VcfCreatedUploaded", CC.CheckBoxValue(cbVcfCrUp)),
                                    new SqlParameter("@BackgoundCheck", CC.CheckBoxValue(cbBackgroundCheck)),
                                    new SqlParameter("@Run_e_verify", CC.CheckBoxValue(cbRuneverify)),
                                    new SqlParameter("@AgreementExecuted", CC.CheckBoxValue(cbEmploymentAgreement)),
                                    //new SqlParameter("@DocumentsGathered", CC.CheckBoxValue(cbDocumentsGathered)),
                                    new SqlParameter("@WelcomeLunchScheduled", CC.CheckBoxValue(cbLunchSecheduled)),
                                    //new SqlParameter("@BenefitVideoSent", CC.CheckBoxValue(cbBenefitVideo)),
                                    new SqlParameter("@BenefitOverview", CC.CheckBoxValue(cbBenefitOverview)),
                                    //new SqlParameter("@BenefitEnrollmentSent", CC.CheckBoxValue(cbBenefitEnrollment)),       
                                    new SqlParameter("@Added401k", CC.CheckBoxValue(cbAdded401k)),
                                    //new SqlParameter("@TrainingSalesSupport", CC.CheckBoxValue(cbTrainingSalesSupport)),
                                    //new SqlParameter("@TrainingPBOC", CC.CheckBoxValue(cbTrainingPBOC)),
                                    new SqlParameter("@TrainingReplicon", CC.CheckBoxValue(cbTrainingReplicon)),
                                    new SqlParameter("@AlsbridgeOverviewTraining", CC.CheckBoxValue(cbAlsbridgeOverview)),
                                    //new SqlParameter("@CounselGroupLeadIntroduction", CC.CheckBoxValue(cbCounselGroupLeadIntro)),       
                                    //new SqlParameter("@PeerCoachingIntroduction", CC.CheckBoxValue(cbPeerCoachingIntro)),
                                    //new SqlParameter("@BioUpdatedPostedOnWiki", CC.CheckBoxValue(cbBioUpdtdPtdWiki)),
                                    //new SqlParameter("@SkillDatabase", CC.CheckBoxValue(cbSkillDatabase)),
                                    //new SqlParameter("@ContactsMeetingWithReaghan", CC.CheckBoxValue(cbContactMeetingSetReaghan)),
                                    new SqlParameter("@WE_W4W9", CC.CheckBoxValue(cbW4W9)),
                                    new SqlParameter("@WE_I9", CC.CheckBoxValue(cbI9)),       
                                    new SqlParameter("@WE_DDForm", CC.CheckBoxValue(cbDDForm)),                                                
                                    new SqlParameter("@WE_PolicySign", CC.CheckBoxValue(cbPolicySign)),
                                    
                                    //New Added Fields
                                    //new SqlParameter("@HireTest", CC.CheckBoxValue(cbNewHireTest)),                                                
                                    //new SqlParameter("@LinkedinUpdate", CC.CheckBoxValue(cbLinkedinUpdate)), 
                                    new SqlParameter("@RepliconCounselProject", CC.CheckBoxValue(cbRepliconCounselProject)), 
                                    new SqlParameter("@ADPPayroll", CC.CheckBoxValue(cbADPPayroll)), 
                                    new SqlParameter("@AlsBridgeDebitCard", CC.CheckBoxValue(cbAlsbridgeDebitCard)), 

                                    //New Added Fields (14/02/2014)
                                    //new SqlParameter("@Reference", CC.CheckBoxValue(cbReferences)),
                                    new SqlParameter("@Resume", CC.CheckBoxValue(cbResume)), 
                                    new SqlParameter("@Assessments", CC.CheckBoxValue(cbAssessments)),
                                    new SqlParameter("@IndividualHeadshot", CC.CheckBoxValue(cbIndividualHeadshot)),

                                    //New added fields 180814
                                    new SqlParameter("@ScheduleOnboarding", CC.CheckBoxValue(cbScheduleOnboarding)),
                                    new SqlParameter("@OnboardingAgenda", CC.CheckBoxValue(cbOnboardingAgenda)),
                                    new SqlParameter("@OfferLetter", CC.CheckBoxValue(cbOfferLetter)),                                     
                                    new SqlParameter("@AddedToPayrollIndia", CC.CheckBoxValue(cbAddedToPayrollIndia)), 
                                    new SqlParameter("@HireKit", CC.CheckBoxValue(cbNewHireKit)),
                                    
                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditHRFinalProcess", sqlparam);
            LblMsg.Text = "Record was updated successfully";
            MsgDiv.Visible = true;
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("finalhrprocess.aspx", "btnSave_Click", ex.Message);
            LblMsg.Text = "Oops! Server problem....try after some time";
            MsgDiv.Visible = true;
        }
        finally { con.Close(); }
    }
    protected void btnSaveSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@EmployeeID", m_EmployeeID),
                                    new SqlParameter("@AddToDirectory", CC.CheckBoxValue(cbAddtoDir)),
                                    //new SqlParameter("@VoicemailInstuctionSent", CC.CheckBoxValue(cbVoicemailInst)),
                                    //new SqlParameter("@CompanyDirectoryProvided", CC.CheckBoxValue(cbCoDir)),
                                    //new SqlParameter("@VcfCreatedUploaded", CC.CheckBoxValue(cbVcfCrUp)),
                                    new SqlParameter("@BackgoundCheck", CC.CheckBoxValue(cbBackgroundCheck)),
                                    new SqlParameter("@Run_e_verify", CC.CheckBoxValue(cbRuneverify)),
                                    new SqlParameter("@AgreementExecuted", CC.CheckBoxValue(cbEmploymentAgreement)),
                                    //new SqlParameter("@DocumentsGathered", CC.CheckBoxValue(cbDocumentsGathered)),
                                    new SqlParameter("@WelcomeLunchScheduled", CC.CheckBoxValue(cbLunchSecheduled)),
                                    //new SqlParameter("@BenefitVideoSent", CC.CheckBoxValue(cbBenefitVideo)),
                                    new SqlParameter("@BenefitOverview", CC.CheckBoxValue(cbBenefitOverview)),
                                    //new SqlParameter("@BenefitEnrollmentSent", CC.CheckBoxValue(cbBenefitEnrollment)),       
                                    new SqlParameter("@Added401k", CC.CheckBoxValue(cbAdded401k)),
                                    //new SqlParameter("@TrainingSalesSupport", CC.CheckBoxValue(cbTrainingSalesSupport)),
                                    //new SqlParameter("@TrainingPBOC", CC.CheckBoxValue(cbTrainingPBOC)),
                                    new SqlParameter("@TrainingReplicon", CC.CheckBoxValue(cbTrainingReplicon)),
                                    new SqlParameter("@AlsbridgeOverviewTraining", CC.CheckBoxValue(cbAlsbridgeOverview)),
                                    //new SqlParameter("@CounselGroupLeadIntroduction", CC.CheckBoxValue(cbCounselGroupLeadIntro)),       
                                    //new SqlParameter("@PeerCoachingIntroduction", CC.CheckBoxValue(cbPeerCoachingIntro)),
                                    //new SqlParameter("@BioUpdatedPostedOnWiki", CC.CheckBoxValue(cbBioUpdtdPtdWiki)),
                                    //new SqlParameter("@SkillDatabase", CC.CheckBoxValue(cbSkillDatabase)),
                                    //new SqlParameter("@ContactsMeetingWithReaghan", CC.CheckBoxValue(cbContactMeetingSetReaghan)),
                                    new SqlParameter("@WE_W4W9", CC.CheckBoxValue(cbW4W9)),
                                    new SqlParameter("@WE_I9", CC.CheckBoxValue(cbI9)),       
                                    new SqlParameter("@WE_DDForm", CC.CheckBoxValue(cbDDForm)),                                                
                                    new SqlParameter("@WE_PolicySign", CC.CheckBoxValue(cbPolicySign)),
                                    
                                    //New Added Fields
                                    //new SqlParameter("@HireTest", CC.CheckBoxValue(cbNewHireTest)),                                                
                                    //new SqlParameter("@LinkedinUpdate", CC.CheckBoxValue(cbLinkedinUpdate)), 
                                    new SqlParameter("@RepliconCounselProject", CC.CheckBoxValue(cbRepliconCounselProject)), 
                                    new SqlParameter("@ADPPayroll", CC.CheckBoxValue(cbADPPayroll)), 
                                    new SqlParameter("@AlsBridgeDebitCard", CC.CheckBoxValue(cbAlsbridgeDebitCard)), 

                                    //New Added Fields (14/02/2014)
                                    //new SqlParameter("@Reference", CC.CheckBoxValue(cbReferences)),
                                    new SqlParameter("@Resume", CC.CheckBoxValue(cbResume)), 
                                    new SqlParameter("@Assessments", CC.CheckBoxValue(cbAssessments)),
                                    new SqlParameter("@IndividualHeadshot", CC.CheckBoxValue(cbIndividualHeadshot)),

                                    //New added fields 180814
                                    new SqlParameter("@ScheduleOnboarding", CC.CheckBoxValue(cbScheduleOnboarding)),
                                    new SqlParameter("@OnboardingAgenda", CC.CheckBoxValue(cbOnboardingAgenda)),
                                    new SqlParameter("@OfferLetter", CC.CheckBoxValue(cbOfferLetter)),                                     
                                    new SqlParameter("@AddedToPayrollIndia", CC.CheckBoxValue(cbAddedToPayrollIndia)), 
                                    new SqlParameter("@HireKit", CC.CheckBoxValue(cbNewHireKit)),

                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditHRFinalProcess", sqlparam);
            LblMsg.Text = "Record was updated successfully";
            MsgDiv.Visible = true;
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("finalhrprocess.aspx", "btnSave_Click", ex.Message);
            LblMsg.Text = "Oops! Server problem....try after some time";
            MsgDiv.Visible = true;
        }
        finally { con.Close(); }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        Reset();
    }
}
