﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;
using System.Globalization;

public partial class administrative : System.Web.UI.Page
{
    MailSender ms = new MailSender();
    CommonClass CC = new CommonClass();
    private string m_Mode = string.Empty;
    private int m_EmployeeID;
    private bool FixMode = false;
    MailSender oMailSender = new MailSender();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        SetQueryStringValue();

        if (!IsPostBack)
        {
            FillAdministrativeDetails();
        }
        MsgDiv.Visible = false;
    }

    private void SetQueryStringValue()
    {
        try
        {
            if (Request.QueryString["EmployeeID"] != null)
            {
                m_EmployeeID = Convert.ToInt32(Request.QueryString["EmployeeID"]);
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("administrative.aspx", "SetQueryStringValue", ex.Message);
            m_Mode = "Add";
            m_EmployeeID = 0;
        }
    }

    private void SetUserRole()
    {
        if (Session["UserRole"] != null)
        {
            if (m_EmployeeID > 0)
            { divSave.Visible = true; }
            else
            { divSave.Visible = false; }
        }
    }

    protected override void Render(HtmlTextWriter writer)
    {
        SetUserRole();
        base.Render(writer);
    }

    private void FillAdministrativeDetails()
    {
        PopulateDetails();
        if (FixMode == true)
        {
            EnableDisable(true);
            divSave.Visible = false;
        }
    }

    private void PopulateDetails()
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetAdministrativeDetails", sqlparam).Tables[0];
            if (odt.Rows.Count > 0)
            {
                //cbYesBCards.Checked = CC.IfNullThenZero(odt.Rows[0]["YesBusinessCard"].ToString());
                //cbConfirmBCards.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmBusinessCard"].ToString());

                cbYesBCardOrdered.Checked = CC.IfNullThenZero(odt.Rows[0]["YesBusinessCardOrder"].ToString());
                cbConfirmBCardOrdered.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmBusinessCardOrder"].ToString());

                cbYesBCQty.Checked = CC.IfNullThenZero(odt.Rows[0]["YesBCQty"].ToString());
                ddlConfirmBCQty.SelectedIndex = ddlConfirmBCQty.Items.IndexOf(ddlConfirmBCQty.Items.FindByText(odt.Rows[0]["BCQty"].ToString()));

                //cbYesBCconfirmedByHR.Checked = CC.IfNullThenZero(odt.Rows[0]["YesBusinessCardConfirmHR"].ToString());
                //cbConfirmBCconfirmedByHR.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmBusinessCardConfirmHR"].ToString());

                cbYesOrbitz.Checked = CC.IfNullThenZero(odt.Rows[0]["YesOrbitzAccountActivation"].ToString());
                cbConfirmOrbitz.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmOrbitzAccountActivation"].ToString());

                cbYesFedEx.Checked = CC.IfNullThenZero(odt.Rows[0]["YesFedExDiscountCard"].ToString());
                cbConfirmFedEx.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmFedExDiscountCard"].ToString());

                cbYesOutsourcingLeadership.Checked = CC.IfNullThenZero(odt.Rows[0]["YesOSLeadershipLogin"].ToString());
                cbConfirmOutsourcingLeadership.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmOSLeadershipLogin"].ToString());

                //New Added
                //cbYesOutsourcingCenter.Checked = CC.IfNullThenZero(odt.Rows[0]["YesOSCenterLogin"].ToString());
                //cbConfirmOutsourcingCenter.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmOSCenterLogin"].ToString());
                //

                //cbYesNING.Checked = CC.IfNullThenZero(odt.Rows[0]["YesNINGSocialInvite"].ToString());
                //cbConfirmNING.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmNINGSocialInvite"].ToString());

                cbYesAdministrationEmail.Checked = CC.IfNullThenZero(odt.Rows[0]["YesAdministrationEmail"].ToString());
                cbConfirmAdministrationEmail.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmAdministrationEmail"].ToString());

                cbYesOffSpaceAllocation.Checked = CC.IfNullThenZero(odt.Rows[0]["YesOfficeSpaceAllocation"].ToString());
                cbConfirmOffSpaceAllocation.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmOfficeSpaceAllocation"].ToString());

                //FixMode = (bool)odt.Rows[0]["FixMode"];

                //New fields added on 250814
                cbYesIndiaLaptopPhonePro.Checked = CC.IfNullThenZero(odt.Rows[0]["YesIndiaLaptopPhonePro"].ToString());
                cbConfirmIndiaLaptopPhonePro.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmIndiaLaptopPhonePro"].ToString());

                cbYesIndiaIDCard.Checked = CC.IfNullThenZero(odt.Rows[0]["YesIndiaIDCard"].ToString());
                cbConfirmIndiaIDCard.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmIndiaIDCard"].ToString());

                cbYesIndiaJoiningKit.Checked = CC.IfNullThenZero(odt.Rows[0]["YesIndiaJoiningKit"].ToString());
                cbConfirmIndiaJoiningKit.Checked = CC.IfNullThenZero(odt.Rows[0]["ConfirmIndiaJoiningKit"].ToString());
            }

        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("administrative.aspx", "PopulateDetails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }



    private string IfNullThenBlank(string value)
    {
        if (value == null)
        {
            return "";
        }
        else if (value == "")
        {
            return "";
        }
        else
        {
            return Server.HtmlDecode(value);
        }
    }

    private void Reset()
    {
        //cbYesBCards.Checked = false;
        //cbConfirmBCards.Checked = false;

        cbYesBCardOrdered.Checked = false;
        cbConfirmBCardOrdered.Checked = false;

        cbYesBCQty.Checked = false;
        ddlConfirmBCQty.SelectedIndex = 0;

        //cbYesBCconfirmedByHR.Checked = false;
        //cbConfirmBCconfirmedByHR.Checked = false;

        cbYesOrbitz.Checked = false;
        cbConfirmOrbitz.Checked = false;

        cbYesFedEx.Checked = false;
        cbConfirmFedEx.Checked = false;

        cbYesOutsourcingLeadership.Checked = false;
        cbConfirmOutsourcingLeadership.Checked = false;

        //New Added
        //cbYesOutsourcingCenter.Checked = false;
        //cbConfirmOutsourcingCenter.Checked = false;

        //cbYesNING.Checked = false;
        //cbConfirmNING.Checked = false;

        cbYesAdministrationEmail.Checked = false;
        cbConfirmAdministrationEmail.Checked = false;

        cbYesOffSpaceAllocation.Checked = false;
        cbConfirmOffSpaceAllocation.Checked = false;

        //New fields added on 250814
        cbYesIndiaLaptopPhonePro.Checked = false;
        cbConfirmIndiaLaptopPhonePro.Checked = false;

        cbYesIndiaIDCard.Checked = false;
        cbConfirmIndiaIDCard.Checked = false;

        cbYesIndiaJoiningKit.Checked = false;
        cbConfirmIndiaJoiningKit.Checked = false;
    }

    private void EnableDisable(bool boolValue)
    {
        //cbBCconfirmedByHR.Enabled = boolValue;
        //cbOrbitz.Enabled = boolValue;
        //cbFedEx.Enabled = boolValue;
        //cbOutsourcingLeadership.Enabled = boolValue;
        ////cbOutsourcingCenter.Enabled = boolValue;
        //cbNING.Enabled = boolValue;
        //cbAdministrationEmail.Enabled = boolValue;
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        int BCQty;
        if (ddlConfirmBCQty.SelectedIndex != 0)
        {
            BCQty = Convert.ToInt32(ddlConfirmBCQty.SelectedItem.ToString());
        }
        else
            BCQty = 0;

        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@EmployeeID", m_EmployeeID),                                    
                                    //new SqlParameter("@YesBusinessCard", CC.CheckBoxValue(cbYesBCards)),
                                    //new SqlParameter("@ConfirmBusinessCard", CC.CheckBoxValue(cbConfirmBCards)),
                                    new SqlParameter("@YesBusinessCardOrder", CC.CheckBoxValue(cbYesBCardOrdered)),
                                    new SqlParameter("@ConfirmBusinessCardOrder", CC.CheckBoxValue(cbConfirmBCardOrdered)),
                                    //new SqlParameter("@YesBusinessCardConfirmHR", CC.CheckBoxValue(cbYesBCconfirmedByHR)),
                                    //new SqlParameter("@ConfirmBusinessCardConfirmHR", CC.CheckBoxValue(cbConfirmBCconfirmedByHR)),                                    
                                    new SqlParameter("@YesBCQty", CC.CheckBoxValue(cbYesBCQty)),                                   
                                    new SqlParameter("@BCQty", BCQty),          
                                    new SqlParameter("@YesOrbitzAccountActivation", CC.CheckBoxValue(cbYesOrbitz)),
                                    new SqlParameter("@ConfirmOrbitzAccountActivation", CC.CheckBoxValue(cbConfirmOrbitz)),
                                    new SqlParameter("@YesFedExDiscountCard", CC.CheckBoxValue(cbYesFedEx)),
                                    new SqlParameter("@ConfirmFedExDiscountCard", CC.CheckBoxValue(cbConfirmFedEx)),
                                    new SqlParameter("@YesOSLeadershipLogin", CC.CheckBoxValue(cbYesOutsourcingLeadership)),
                                    new SqlParameter("@ConfirmOSLeadershipLogin", CC.CheckBoxValue(cbConfirmOutsourcingLeadership)),
                                    //new SqlParameter("@YesOSCenterLogin", CC.CheckBoxValue(cbYesOutsourcingCenter)),
                                    //new SqlParameter("@ConfirmOSCenterLogin", CC.CheckBoxValue(cbConfirmOutsourcingCenter)),
                                    //new SqlParameter("@YesNINGSocialInvite", CC.CheckBoxValue(cbYesNING)),
                                    //new SqlParameter("@ConfirmNINGSocialInvite", CC.CheckBoxValue(cbConfirmNING)),
                                    new SqlParameter("@YesAdministrationEmail", CC.CheckBoxValue(cbYesAdministrationEmail)),
                                    new SqlParameter("@ConfirmAdministrationEmail", CC.CheckBoxValue(cbConfirmAdministrationEmail)),
                                    new SqlParameter("@YesOffSpaceAllocation", CC.CheckBoxValue(cbYesOffSpaceAllocation)),
                                    new SqlParameter("@ConfirmOffSpaceAllocation", CC.CheckBoxValue(cbConfirmOffSpaceAllocation)),

                                    //New fields added on 250814
                                    new SqlParameter("@YesIndiaLaptopPhonePro", CC.CheckBoxValue(cbYesIndiaLaptopPhonePro)),
                                    new SqlParameter("@ConfirmIndiaLaptopPhonePro", CC.CheckBoxValue(cbConfirmIndiaLaptopPhonePro)),
                                    new SqlParameter("@YesIndiaIDCard", CC.CheckBoxValue(cbYesIndiaIDCard)),
                                    new SqlParameter("@ConfirmIndiaIDCard", CC.CheckBoxValue(cbConfirmIndiaIDCard)),
                                    new SqlParameter("@YesIndiaJoiningKit", CC.CheckBoxValue(cbYesIndiaJoiningKit)),
                                    new SqlParameter("@ConfirmIndiaJoiningKit", CC.CheckBoxValue(cbConfirmIndiaJoiningKit)),

                                    //new SqlParameter("@FixMode", false),
                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditAdministrativeDetails", sqlparam);
            LblMsg.Text = "Record was updated successfully";
            MsgDiv.Visible = true;
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("administrative.aspx", "btnSave_Click", ex.Message);
            LblMsg.Text = "Oops! Server problem....try after some time";
            MsgDiv.Visible = true;
        }
        finally { con.Close(); }
    }

    protected void btnSaveSubmit_Click(object sender, EventArgs e)
    {
        int BCQty;
        if (ddlConfirmBCQty.SelectedIndex != 0)
        {
            BCQty = Convert.ToInt32(ddlConfirmBCQty.SelectedItem.ToString());
        }
        else
            BCQty = 0;

        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@EmployeeID", m_EmployeeID),                                    
                                    //new SqlParameter("@YesBusinessCard", CC.CheckBoxValue(cbYesBCards)),
                                    //new SqlParameter("@ConfirmBusinessCard", CC.CheckBoxValue(cbConfirmBCards)),
                                    new SqlParameter("@YesBusinessCardOrder", CC.CheckBoxValue(cbYesBCardOrdered)),
                                    new SqlParameter("@ConfirmBusinessCardOrder", CC.CheckBoxValue(cbConfirmBCardOrdered)),
                                    //new SqlParameter("@YesBusinessCardConfirmHR", CC.CheckBoxValue(cbYesBCconfirmedByHR)),
                                    //new SqlParameter("@ConfirmBusinessCardConfirmHR", CC.CheckBoxValue(cbConfirmBCconfirmedByHR)),                                    
                                    new SqlParameter("@YesBCQty", CC.CheckBoxValue(cbYesBCQty)),                                   
                                    new SqlParameter("@BCQty", BCQty),          
                                    new SqlParameter("@YesOrbitzAccountActivation", CC.CheckBoxValue(cbYesOrbitz)),
                                    new SqlParameter("@ConfirmOrbitzAccountActivation", CC.CheckBoxValue(cbConfirmOrbitz)),
                                    new SqlParameter("@YesFedExDiscountCard", CC.CheckBoxValue(cbYesFedEx)),
                                    new SqlParameter("@ConfirmFedExDiscountCard", CC.CheckBoxValue(cbConfirmFedEx)),
                                    new SqlParameter("@YesOSLeadershipLogin", CC.CheckBoxValue(cbYesOutsourcingLeadership)),
                                    new SqlParameter("@ConfirmOSLeadershipLogin", CC.CheckBoxValue(cbConfirmOutsourcingLeadership)),
                                    //new SqlParameter("@YesOSCenterLogin", CC.CheckBoxValue(cbYesOutsourcingCenter)),
                                    //new SqlParameter("@ConfirmOSCenterLogin", CC.CheckBoxValue(cbConfirmOutsourcingCenter)),
                                    //new SqlParameter("@YesNINGSocialInvite", CC.CheckBoxValue(cbYesNING)),
                                    //new SqlParameter("@ConfirmNINGSocialInvite", CC.CheckBoxValue(cbConfirmNING)),
                                    new SqlParameter("@YesAdministrationEmail", CC.CheckBoxValue(cbYesAdministrationEmail)),
                                    new SqlParameter("@ConfirmAdministrationEmail", CC.CheckBoxValue(cbConfirmAdministrationEmail)),
                                    new SqlParameter("@YesOffSpaceAllocation", CC.CheckBoxValue(cbYesOffSpaceAllocation)),
                                    new SqlParameter("@ConfirmOffSpaceAllocation", CC.CheckBoxValue(cbConfirmOffSpaceAllocation)),

                                     //New fields added on 250814
                                    new SqlParameter("@YesIndiaLaptopPhonePro", CC.CheckBoxValue(cbYesIndiaLaptopPhonePro)),
                                    new SqlParameter("@ConfirmIndiaLaptopPhonePro", CC.CheckBoxValue(cbConfirmIndiaLaptopPhonePro)),
                                    new SqlParameter("@YesIndiaIDCard", CC.CheckBoxValue(cbYesIndiaIDCard)),
                                    new SqlParameter("@ConfirmIndiaIDCard", CC.CheckBoxValue(cbConfirmIndiaIDCard)),
                                    new SqlParameter("@YesIndiaJoiningKit", CC.CheckBoxValue(cbYesIndiaJoiningKit)),
                                    new SqlParameter("@ConfirmIndiaJoiningKit", CC.CheckBoxValue(cbConfirmIndiaJoiningKit)),

                                    new SqlParameter("@FixMode", 1),
                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditAdministrativeDetails", sqlparam);
            LblMsg.Text = "Record was updated successfully";
            MsgDiv.Visible = true;
            AlertMails();
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("administrative.aspx", "btnSave_Click", ex.Message);
            LblMsg.Text = "Oops! Server problem....try after some time";
            MsgDiv.Visible = true;
        }
        finally { con.Close(); }
    }

    private void AlertMails()
    {
        string AbsoluteUri = string.Empty;
        string CurrentFilePath = string.Empty;
        string QueryString = string.Empty;
        string EmployeeName = string.Empty;
        //oMailSender
        DataTable odt = new DataTable();
        DataTable odt1 = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            AbsoluteUri = Request.Url.AbsoluteUri.ToString();
            CurrentFilePath = Request.AppRelativeCurrentExecutionFilePath.ToString();
            CurrentFilePath = CurrentFilePath.Remove(0, 2);
            QueryString = Request.QueryString.ToString();
            AbsoluteUri = AbsoluteUri.Replace(CurrentFilePath + "?" + QueryString, "");
            AbsoluteUri = AbsoluteUri + "loginpage.aspx?";

            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt1 = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetEmployeeDetails", sqlparam).Tables[0];
            if (odt1.Rows.Count > 0)
            {
                if (odt1.Rows[0]["Country"].ToString().ToLower() == "india")
                { return; }
                EmployeeName = odt1.Rows[0]["FirstName"].ToString() + " " + odt1.Rows[0]["LastName"].ToString();
            }
            else
            { return; }

            string query = string.Empty;
            query = "Select * from Users where Role = 'hr'";
            odt = SqlHelper.ExecuteDataset(con, CommandType.Text, query).Tables[0];

            if (odt.Rows.Count > 0)
            {
                for (int i = 0; i < odt.Rows.Count; i++)
                {
                    oMailSender.SendMailToHR(odt.Rows[i]["UserName"].ToString(), odt.Rows[i]["Role"].ToString(), AbsoluteUri, odt.Rows[i]["FirstName"].ToString() + " " + odt.Rows[i]["LastName"].ToString(), EmployeeName, "Administrative");
                }
            }
            //CC.SendMailToHrIfAllSectionComplete(m_EmployeeID, EmployeeName);
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("administrative.aspx", "AlertMails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Reset();
    }
}
