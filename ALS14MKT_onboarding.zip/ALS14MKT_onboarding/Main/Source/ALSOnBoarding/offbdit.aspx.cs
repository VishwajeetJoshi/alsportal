﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;

public partial class offbdit : System.Web.UI.Page
{
    CommonClass CC = new CommonClass();
    MailSender oMailSender = new MailSender();
    private string m_Mode = string.Empty;
    private int m_EmployeeID;
    private bool FixMode = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        SetQueryStringValue();
        if (!IsPostBack)
        {
            PopulateDetails();
        }
        MsgDiv.Visible = false;
    }

    private void SetQueryStringValue()
    {
        try
        {
            if (Request.QueryString["EmployeeID"] != null)
            {
                m_EmployeeID = Convert.ToInt32(Request.QueryString["EmployeeID"]);
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("offbdit.aspx", "SetQueryStringValue", ex.Message);
            m_Mode = "Add";
            m_EmployeeID = 0;
        }
    }

    private void SetUserRole()
    {
        if (Session["UserRole"] != null)
        {
            if (m_EmployeeID > 0)
            { divSave.Visible = true; }
            else
            { divSave.Visible = false; }
        }
    }

    protected override void Render(HtmlTextWriter writer)
    {
        SetUserRole();
        base.Render(writer);
    }

    private void PopulateDetails()
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetOffBoardingDetails", sqlparam).Tables[0];
            if (odt.Rows.Count > 0)
            {
                cbPwdChange.Checked = CC.IfNullThenZero(odt.Rows[0]["EmailPwdChange"].ToString());
                cbEmailForwarded.Checked = CC.IfNullThenZero(odt.Rows[0]["EmailForwarded"].ToString());
                cbEmailArchived.Checked = CC.IfNullThenZero(odt.Rows[0]["EmailArchived"].ToString());
                //cbWikiAccessRemoved.Checked = CC.IfNullThenZero(odt.Rows[0]["WikiAccessRemoved"].ToString());
                cbL3WebConnectAc.Checked = CC.IfNullThenZero(odt.Rows[0]["GomeetingConference"].ToString());
                cbSalesforceDisabled.Checked = CC.IfNullThenZero(odt.Rows[0]["SalesforceLogin"].ToString());
                //cbPrinterRemoved.Checked = CC.IfNullThenZero(odt.Rows[0]["RemovedPrinter"].ToString());
                cbVPNDisabled.Checked = CC.IfNullThenZero(odt.Rows[0]["VPNdisabled"].ToString());
                txtAdditionalAccess.Text = CC.IfNullThenBlank(odt.Rows[0]["AdditionalAccessRemoved"].ToString());

                if (CC.IfNullThenBlank(odt.Rows[0]["ForwardEmailAddress"].ToString()) != "")
                {
                    lblForwardedEmailID.InnerHtml = "(" + CC.IfNullThenBlank(odt.Rows[0]["ForwardEmailAddress"].ToString()) + ")";
                }
                //new changes
                cbRemoveEmailGroup.Checked = CC.IfNullThenZero(odt.Rows[0]["RemoveEmailGroups"].ToString());
                cbSendboxRecoverLaptop.Checked = CC.IfNullThenZero(odt.Rows[0]["SendboxRecoverLaptop"].ToString());
                cbLaptopHardwareRecovered.Checked = CC.IfNullThenZero(odt.Rows[0]["LaptopHardwareRecovered"].ToString());
                cbBackupConducted.Checked = CC.IfNullThenZero(odt.Rows[0]["BackupConducted"].ToString());
                //
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("offbdit.aspx", "PopulateDetails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    private void Reset()
    {
        cbPwdChange.Checked = false;
        cbEmailForwarded.Checked = false;
        cbEmailArchived.Checked = false;
        //cbWikiAccessRemoved.Checked = false;
        cbL3WebConnectAc.Checked = false;
        cbSalesforceDisabled.Checked = false;
        //cbPrinterRemoved.Checked = false;
        cbVPNDisabled.Checked = false;
        txtAdditionalAccess.Text = "";
        cbRemoveEmailGroup.Checked = false;
        cbSendboxRecoverLaptop.Checked = false;
        cbLaptopHardwareRecovered.Checked = false;
        cbBackupConducted.Checked = false;
    }

    //SP_AddEditOffbdit

    protected void btnSave_Click(object sender, EventArgs e)
    {
        saveEmployeeInformation();
    }
    protected void btnSaveSubmit_Click(object sender, EventArgs e)
    {
        if (saveEmployeeInformation() == 1)
        {
            AlertMails();
        }
    }

    private int saveEmployeeInformation()
    {
        int returnValue;

        if (ValidateRecord() == false)
        {
            MsgDiv.Visible = true;
            returnValue = 0;
        }

        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter[] sqlparam = new SqlParameter[] {                                         
                                        new SqlParameter("@EmployeeID", m_EmployeeID),
                                        new SqlParameter("@EmailPwdChange", CC.CheckBoxValue(cbPwdChange)),
                                        new SqlParameter("@EmailForwarded", CC.CheckBoxValue(cbEmailForwarded)),
                                        new SqlParameter("@EmailArchived", CC.CheckBoxValue(cbEmailArchived)),
                                        //new SqlParameter("@WikiAccessRemoved", CC.CheckBoxValue(cbWikiAccessRemoved)),
                                        new SqlParameter("@GomeetingConference", CC.CheckBoxValue(cbL3WebConnectAc)),
                                        new SqlParameter("@SalesforceLogin", CC.CheckBoxValue(cbSalesforceDisabled)),
                                        //new SqlParameter("@RemovedPrinter", CC.CheckBoxValue(cbPrinterRemoved)),
                                        new SqlParameter("@VPNdisabled", CC.CheckBoxValue(cbVPNDisabled)),
                                        new SqlParameter("@AdditionalAccessRemoved", Server.HtmlEncode(txtAdditionalAccess.Text)),
                                        //new changes
                                        new SqlParameter("@RemoveEmailGroups", CC.CheckBoxValue(cbRemoveEmailGroup)),
                                        new SqlParameter("@SendboxRecoverLaptop", CC.CheckBoxValue(cbSendboxRecoverLaptop)),
                                        new SqlParameter("@LaptopHardwareRecovered", CC.CheckBoxValue(cbLaptopHardwareRecovered)),
                                        new SqlParameter("@BackupConducted", CC.CheckBoxValue(cbBackupConducted)),
                                        ////
                                        new SqlParameter("@CreatedBy", Session["UserName"]),
                                        new SqlParameter("@ModifiedBy", Session["UserName"])};

            SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditOffbdit", sqlparam);
            LblMsg.Text = "Record was updated successfully";
            MsgDiv.Visible = true;
            returnValue = 1;
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("offbdit.aspx", "btnSave_Click", ex.Message);
            LblMsg.Text = "Oops! Server problem....try after some time";
            MsgDiv.Visible = true;
            returnValue = 0;
        }
        finally { con.Close(); }
        return returnValue;
    }

    private bool ValidateRecord()
    {
        return true;
    }

    private void AlertMails()
    {
        string AbsoluteUri = string.Empty;
        string CurrentFilePath = string.Empty;
        string QueryString = string.Empty;
        string EmployeeName = string.Empty;
        //oMailSender
        DataTable odt = new DataTable();
        DataTable odt1 = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            AbsoluteUri = Request.Url.AbsoluteUri.ToString();
            CurrentFilePath = Request.AppRelativeCurrentExecutionFilePath.ToString();
            CurrentFilePath = CurrentFilePath.Remove(0, 2);
            QueryString = Request.QueryString.ToString();
            AbsoluteUri = AbsoluteUri.Replace(CurrentFilePath + "?" + QueryString, "");
            AbsoluteUri = AbsoluteUri + "loginpage.aspx?";

            SqlParameter sqlparam = new SqlParameter("@EmployeeID", m_EmployeeID);
            odt1 = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetEmployeeDetails", sqlparam).Tables[0];
            if (odt1.Rows.Count > 0)
            {
                EmployeeName = odt1.Rows[0]["FirstName"].ToString() + " " + odt1.Rows[0]["LastName"].ToString();
            }

            string query = string.Empty;
            query = "Select * from Users where Role = 'hr'";
            odt = SqlHelper.ExecuteDataset(con, CommandType.Text, query).Tables[0];

            if (odt.Rows.Count > 0)
            {
                for (int i = 0; i < odt.Rows.Count; i++)
                {
                    oMailSender.SendOffBdMailToHR(odt.Rows[i]["UserName"].ToString(), odt.Rows[i]["Role"].ToString(), AbsoluteUri, odt.Rows[i]["FirstName"].ToString() + " " + odt.Rows[i]["LastName"].ToString(), EmployeeName, "IT");
                }
            }
            //CC.SendMailToHrIfAllSectionComplete(m_EmployeeID, EmployeeName);
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("offbdit.aspx", "AlertMails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Reset();
    }
}
