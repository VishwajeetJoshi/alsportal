﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MyDataAccess;
using CommonFunction;

public partial class createuser : System.Web.UI.Page
{
    CommonClass CC = new CommonClass();
    private string m_Mode = string.Empty;
    private string m_UserName = string.Empty;
    private bool FixMode = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (CC.AuthenticateUser() == false)
        {
            Response.Redirect("~/loginpage.aspx?Mode=2");
        }
        if (Session["UserRole"] != null)
        {
            if (Session["UserRole"].ToString().ToLower().Contains("system admin") || Session["UserRole"].ToString().ToLower().Contains("hr"))
            { }
            else { Response.Redirect("~/loginpage.aspx?Mode=3"); }
        }

        SetQueryStringValue();

        if (!IsPostBack)
        {
            FillDropDownList();
            Session["update"] = Server.UrlEncode(System.DateTime.Now.ToString());
            if (m_Mode == "edit")
            {
                PopulateDetails();
                trPwd.Visible = false;
                trConfirmPwd.Visible = false;
                txtUserName.ReadOnly = true;
                lblHeaderText.InnerText = "Edit";
            }
            else if (m_Mode == "editpwd")
            {
                PopulateDetails();
                trLastName.Visible = false;
                trFirstName.Visible = false;
                trRole.Visible = false;
                cvConfirmPwd.Enabled = false;
                cvUserdetails.Visible = false;
                hPageHeader.InnerText = "Internal User";
                ltitle.InnerText = "Reset Password";
                sbtnClear.Visible = false;
                txtUserName.ReadOnly = true;
                trCountry.Visible = false;
            }
            else
            {
                lblHeaderText.InnerText = "Add";
            }
        }
        MsgDiv.Visible = false;
    }

    private void FillDropDownList()
    {
        //-------Fill Country
        ddlCountry.DataSource = CC.AllCountry();
        ddlCountry.DataTextField = "CountryName";
        ddlCountry.DataValueField = "CountryName";
        ddlCountry.DataBind();
        ddlCountry.Items.Insert(0, new ListItem("-- Select One --", "0"));
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        ViewState["update"] = Session["update"];
    }

    private void PopulateDetails()
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@UserName", Server.HtmlEncode(m_UserName));
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetUserDetails", sqlparam).Tables[0];
            if (odt.Rows.Count > 0)
            {
                txtLastName.Text = IfNullThenBlank(odt.Rows[0]["FirstName"].ToString());
                txtFirstName.Text = IfNullThenBlank(odt.Rows[0]["LastName"].ToString());
                txtUserName.Text = IfNullThenBlank(odt.Rows[0]["UserName"].ToString());
                //ddlRole.SelectedIndex = ddlRole.Items.IndexOf(ddlRole.Items.FindByText(odt.Rows[0]["Role"].ToString()));
                setRole(odt.Rows[0]["Role"].ToString());

                if (!string.IsNullOrEmpty(Convert.ToString(odt.Rows[0]["Country"])))
                {
                    ListItem selectedListItem = ddlCountry.Items.FindByText(odt.Rows[0]["Country"].ToString());
                    if (selectedListItem != null)
                    {
                        selectedListItem.Selected = true;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("createuser.aspx", "PopulateDetails", ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    private string IfNullThenBlank(string value)
    {
        if (value == null)
        {
            return "";
        }
        else if (value == "")
        {
            return "";
        }
        else
        {
            return Server.HtmlDecode(value);
        }
    }

    private void SetQueryStringValue()
    {
        try
        {
            if (Request.QueryString["username"] != null)
            {
                m_UserName = Request.QueryString["username"];
            }
            if (Request.QueryString["mode"] != null)
            {
                m_Mode = Request.QueryString["mode"];
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("createuser.aspx", "SetQueryStringValue", ex.Message);
            m_Mode = "Add";
        }
    }

    private void Reset()
    {
        txtLastName.Text = "";
        txtFirstName.Text = "";
        if (m_Mode != "edit")
        {
            txtUserName.Text = "";
        }
        txtPwd.Text = "";
        txtConfirmPwd.Text = "";

        cbSystemAdmin.Checked = false;
        cbAdministrative.Checked = false;
        cbIT.Checked = false;
        cbHR.Checked = false;
        //cbPayroll.Checked = false;
        cbSecurity.Checked = false;
        cbMarketing.Checked = false;
        cbPerformanceMgt.Checked = false;
        cbMeeting.Checked = false;

        ddlCountry.SelectedIndex = 0;
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Session["update"].ToString() == ViewState["update"].ToString())
        {
            string role = string.Empty;
            role = getRole();
            if (m_Mode == "edit")
            {
                string userCountry = string.Empty;
                if (ddlCountry.SelectedIndex != 0)
                {
                    userCountry = ddlCountry.SelectedValue;
                }

                SqlConnection con = SqlHelper.GetConnection();
                con.Open();
                try
                {
                    SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@Mode", "edit"),
                                    new SqlParameter("@UserName", Server.HtmlEncode(txtUserName.Text)),
                                    new SqlParameter("@FirstName", Server.HtmlEncode(txtFirstName.Text)),
                                    new SqlParameter("@LastName", Server.HtmlEncode(txtLastName.Text)),
                                    new SqlParameter("@Password", CommonClass.Encrypt(Server.HtmlEncode(txtPwd.Text))),
                                    new SqlParameter("@Role", role),
                                    new SqlParameter("@Country", userCountry),
                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

                    SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditUserDetails", sqlparam);
                    Response.Redirect("createuserview.aspx?username=" + m_UserName, false);
                    //LblMsg.Text = "Record was updated successfully";
                    //MsgDiv.Visible = true;
                }
                catch (Exception ex)
                {
                    CommonClass.AddErrorTrail("createuser.aspx", "btnSave_Click", ex.Message);
                    LblMsg.Text = "Oops! Server problem....try after some time";
                    MsgDiv.Visible = true;
                }
                finally { con.Close(); }
            }
            else if (m_Mode == "editpwd")
            {
                SqlConnection con = SqlHelper.GetConnection();
                con.Open();
                try
                {
                    string pwd = CommonClass.Encrypt(txtPwd.Text.Trim());
                    SqlParameter[] sqlparam = new SqlParameter[]{
                                        new SqlParameter("@NewPassword", pwd),
                                        new SqlParameter("@ModifiedBy", m_UserName)};
                    SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_UpdatePassword", sqlparam);
                    Response.Redirect("createuserview.aspx?username=" + m_UserName, false);
                }
                catch (Exception ex)
                {
                    CommonClass.AddErrorTrail("createuser.aspx", "btnSave_Click", ex.Message);
                    LblMsg.Text = "Oops! Server problem....try after some time";
                    MsgDiv.Visible = true;
                }
                finally
                {
                    con.Close();
                }
            }
            else
            {
                if (ValidateDetails() == false)
                {
                    MsgDiv.Visible = true;
                    return;
                }

                string userCountry = string.Empty;
                if (ddlCountry.SelectedIndex != 0)
                {
                    userCountry = ddlCountry.SelectedValue;
                }

                SqlConnection con = SqlHelper.GetConnection();
                con.Open();
                try
                {
                    SqlParameter[] sqlparam = new SqlParameter[] { 
                                    new SqlParameter("@Mode", "Add"),
                                    new SqlParameter("@UserName", Server.HtmlEncode(txtUserName.Text)),
                                    new SqlParameter("@FirstName", Server.HtmlEncode(txtFirstName.Text)),
                                    new SqlParameter("@LastName", Server.HtmlEncode(txtLastName.Text)),
                                    new SqlParameter("@Password", CommonClass.Encrypt(Server.HtmlEncode(txtPwd.Text))),
                                    new SqlParameter("@Role", role),
                                    new SqlParameter("@Country", userCountry),
                                    new SqlParameter("@CreatedBy", Session["UserName"]),
                                    new SqlParameter("@ModifiedBy", Session["UserName"])};

                    SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "SP_AddEditUserDetails", sqlparam);
                    LblMsg.Text = "Record was added successfully";
                    MsgDiv.Visible = true;
                    Reset();
                }
                catch (Exception ex)
                {
                    CommonClass.AddErrorTrail("createuser.aspx", "btnSave_Click", ex.Message);
                    LblMsg.Text = "Oops! Server problem....try after some time";
                    MsgDiv.Visible = true;
                }
                finally { con.Close(); }
            }
            Session["update"] = Server.UrlEncode(System.DateTime.Now.ToString());
        }
        else
        {
            Reset();
        }
    }

    private bool ValidateDetails()
    {
        DataTable odt = new DataTable();
        SqlConnection con = SqlHelper.GetConnection();
        con.Open();
        try
        {
            SqlParameter sqlparam = new SqlParameter("@UserName", Server.HtmlEncode(txtUserName.Text));
            odt = SqlHelper.ExecuteDataset(con, CommandType.StoredProcedure, "SP_GetUserDetails", sqlparam).Tables[0];
            if (odt.Rows.Count > 0)
            {
                LblMsg.Text = "User already exits with the same email id. Record can't be saved.";
                return false;
            }
            else
            {
                return true;
            }
        }
        catch (Exception ex)
        {
            CommonClass.AddErrorTrail("createuser.aspx", "btnSave_Click", ex.Message);
            return false;
        }
        finally
        { con.Close(); }
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Reset();
    }

    protected void btnBack_Click(object sender, EventArgs e)
    {
        if (m_Mode == "edit" || m_Mode == "editpwd")
        {
            Response.Redirect("createuserview.aspx?username=" + m_UserName);
        }
        else
        {
            Response.Redirect("createuserview.aspx");
        }
    }

    private string getRole()
    {
        string role = string.Empty;
        if (cbSystemAdmin.Checked == true)
        {
            if (role == string.Empty)
                role = cbSystemAdmin.Text.Trim();
            else
                role += ", " + cbSystemAdmin.Text.Trim();
        }
        if (cbAdministrative.Checked == true)
        {
            if (role == string.Empty)
                role = cbAdministrative.Text.Trim();
            else
                role += ", " + cbAdministrative.Text.Trim();
        }
        if (cbIT.Checked == true)
        {
            if (role == string.Empty)
                role = cbIT.Text.Trim();
            else
                role += ", " + cbIT.Text.Trim();
        }
        if (cbHR.Checked == true)
        {
            if (role == string.Empty)
                role = cbHR.Text.Trim();
            else
                role += ", " + cbHR.Text.Trim();
        }
        //if (cbPayroll.Checked == true)
        //{
        //    if (role == string.Empty)
        //        role = cbPayroll.Text.Trim();
        //    else
        //        role += ", " + cbPayroll.Text.Trim();
        //}
        if (cbSecurity.Checked == true)
        {
            if (role == string.Empty)
                role = cbSecurity.Text.Trim();
            else
                role += ", " + cbSecurity.Text.Trim();
        }
        if (cbMeeting.Checked == true)
        {
            if (role == string.Empty)
                role = cbMeeting.Text.Trim();
            else
                role += ", " + cbMeeting.Text.Trim();
        }
        if (cbMarketing.Checked == true)
        {
            if (role == string.Empty)
                role = cbMarketing.Text.Trim();
            else
                role += ", " + cbMarketing.Text.Trim();
        }
        if (cbPerformanceMgt.Checked == true)
        {
            if (role == string.Empty)
                role = cbPerformanceMgt.Text.Trim();
            else
                role += ", " + cbPerformanceMgt.Text.Trim();
        }
        return role;
    }

    private void setRole(string strRole)
    {
        List<string> roleList = strRole.Split(',').ToList();
        foreach (string item in roleList)
        {
            if (item.ToLower().Trim() == "system admin")
            {
                cbSystemAdmin.Checked = true;
            }
            if (item.ToLower().Trim() == "administrative")
            {
                cbAdministrative.Checked = true;
            }
            if (item.ToLower().Trim() == "it")
            {
                cbIT.Checked = true;
            }
            if (item.ToLower().Trim() == "hr")
            {
                cbHR.Checked = true;
            }
            //if (item.ToLower().Trim() == "payroll")
            //{
            //   cbPayroll.Checked = true;
            //}
            if (item.ToLower().Trim() == "security")
            {
                cbSecurity.Checked = true;
            }
            if (item.ToLower().Trim() == "meeting")
            {
                cbMeeting.Checked = true;
            }
            if (item.ToLower().Trim() == "sales & marketing")
            {
                cbMarketing.Checked = true;
            }
            if (item.ToLower().Trim() == "performance management")
            {
                cbPerformanceMgt.Checked = true;
            }
        }
    }
}
